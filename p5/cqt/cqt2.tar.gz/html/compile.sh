make -f Makefile.emscripten
node parse.js > tmp.js
cat t1.js tmp.js t2.js > showcqtbar.js
rm -f tmp.js
