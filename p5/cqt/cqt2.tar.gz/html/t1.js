/*
 * Copyright (c) 2017 Muhammad Faiz <mfcc64@gmail.com>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
 */

/* Audio visualization based on showcqtbar mpv/ffmpeg audio visualization */
/* See https://github.com/FFmpeg/FFmpeg/blob/master/libavfilter/avf_showcqt.c */
/* See common.js for usage example */

function ShowCQTBar(rate, width, height, bar_v, sono_v, supersampling) {
    this.rate = rate;
    this.width = width;
    this.height = height;
    this.buffer = new ArrayBuffer(2048*1024);
    this.asm = this.emscripten(window, null, this.buffer);
    this.fft_size = this.asm._init(rate, width, height, bar_v, sono_v, supersampling);
    if (!this.fft_size)
        throw ("Error initializing asm module");
    /* idx=0 : left, idx=1 : right */
    this.get_input_array = function(idx) {
        return new Float32Array(this.buffer, this.asm._get_input_array(idx), this.fft_size);
    }
    this.get_output_array = function() {
        return new Uint8ClampedArray(this.buffer, this.asm._get_output_array(), this.width*4);
    }
    /* calculate cqt from input_array */
    this.calc = function() { this.asm._calc(); }
    /* render showcqtbar at line y to output_array */
    this.render_line = function(y, alpha) {
        if (alpha == undefined)
            alpha = 255;
        this.asm._render_line(y, alpha);
    }
    /* set volume at runtime */
    this.set_volume = function(bar_v, sono_v) { this.asm._set_volume(bar_v, sono_v); }
    /* set height at runtime */
    this.set_height = function(height) { this.asm._set_height(height); }
}


ShowCQTBar.prototype.emscripten = function(global, env, buffer) {
'use asm';


  var HEAP8 = new global.Int8Array(buffer);
  var HEAP16 = new global.Int16Array(buffer);
  var HEAP32 = new global.Int32Array(buffer);
  var HEAPU8 = new global.Uint8Array(buffer);
  var HEAPU16 = new global.Uint16Array(buffer);
  var HEAPU32 = new global.Uint32Array(buffer);
  var HEAPF32 = new global.Float32Array(buffer);
  var HEAPF64 = new global.Float64Array(buffer);

  var __THREW__ = 0;
  var threwValue = 0;
  var setjmpId = 0;
  var undef = 0;
  var nan = global.NaN, inf = global.Infinity;
  var tempInt = 0, tempBigInt = 0, tempBigIntS = 0, tempValue = 0, tempDouble = 0.0;
  var tempRet0 = 0;

  var Math_floor=global.Math.floor;
  var Math_abs=global.Math.abs;
  var Math_sqrt=global.Math.sqrt;
  var Math_pow=global.Math.pow;
  var Math_cos=global.Math.cos;
  var Math_sin=global.Math.sin;
  var Math_tan=global.Math.tan;
  var Math_acos=global.Math.acos;
  var Math_asin=global.Math.asin;
  var Math_atan=global.Math.atan;
  var Math_atan2=global.Math.atan2;
  var Math_exp=global.Math.exp;
  var Math_log=global.Math.log;
  var Math_ceil=global.Math.ceil;
  var Math_imul=global.Math.imul;
  var Math_min=global.Math.min;
  var Math_max=global.Math.max;
  var Math_clz32=global.Math.clz32;
  var Math_fround=global.Math.fround;
  var tempFloat = Math_fround(0);
  const f0 = Math_fround(0);

// EMSCRIPTEN_START_FUNCS


