
// EMSCRIPTEN_END_FUNCS
  return { _render_line: _render_line, _init: _init, _get_input_array: _get_input_array, _calc: _calc, _get_output_array: _get_output_array, _set_height: _set_height, _set_volume: _set_volume };
}
