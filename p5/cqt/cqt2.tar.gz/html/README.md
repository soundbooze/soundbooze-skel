# html5-showcqtbar

ShowCQTBar javascript version from ffmpeg/mpv audio visualizer.

## Example
Go to [html5-showcqtbar](https://mfcc64.github.io/html5-showcqtbar/).
