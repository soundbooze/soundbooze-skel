var readline = require('readline');
var fs = require('fs');

var myInterface = readline.createInterface({
  input: fs.createReadStream('showcqtbar-out.js')
});

var write = 0;
myInterface.on('line', function (line) {

  if (line === '// EMSCRIPTEN_START_FUNCS') {
    write = 1;
  }

  if (line === '// EMSCRIPTEN_END_FUNCS') {
    write = 0;
  }

  if (write)
    console.log(line);
});
