/*
 * Copyright (c) 2017 Muhammad Faiz <mfcc64@gmail.com>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
 */

/* Audio visualization based on showcqtbar mpv/ffmpeg audio visualization */
/* See https://github.com/FFmpeg/FFmpeg/blob/master/libavfilter/avf_showcqt.c */
/* See common.js for usage example */

function ShowCQTBar(rate, width, height, bar_v, sono_v, supersampling) {
    this.rate = rate;
    this.width = width;
    this.height = height;
    this.buffer = new ArrayBuffer(2048*1024);
    this.asm = this.emscripten(window, null, this.buffer);
    this.fft_size = this.asm._init(rate, width, height, bar_v, sono_v, supersampling);
    if (!this.fft_size)
        throw ("Error initializing asm module");
    /* idx=0 : left, idx=1 : right */
    this.get_input_array = function(idx) {
        return new Float32Array(this.buffer, this.asm._get_input_array(idx), this.fft_size);
    }
    this.get_output_array = function() {
        return new Uint8ClampedArray(this.buffer, this.asm._get_output_array(), this.width*4);
    }
    /* calculate cqt from input_array */
    this.calc = function() { this.asm._calc(); }
    /* render showcqtbar at line y to output_array */
    this.render_line = function(y, alpha) {
        if (alpha == undefined)
            alpha = 255;
        this.asm._render_line(y, alpha);
    }
    /* set volume at runtime */
    this.set_volume = function(bar_v, sono_v) { this.asm._set_volume(bar_v, sono_v); }
    /* set height at runtime */
    this.set_height = function(height) { this.asm._set_height(height); }
}


ShowCQTBar.prototype.emscripten = function(global, env, buffer) {
'use asm';


  var HEAP8 = new global.Int8Array(buffer);
  var HEAP16 = new global.Int16Array(buffer);
  var HEAP32 = new global.Int32Array(buffer);
  var HEAPU8 = new global.Uint8Array(buffer);
  var HEAPU16 = new global.Uint16Array(buffer);
  var HEAPU32 = new global.Uint32Array(buffer);
  var HEAPF32 = new global.Float32Array(buffer);
  var HEAPF64 = new global.Float64Array(buffer);

  var __THREW__ = 0;
  var threwValue = 0;
  var setjmpId = 0;
  var undef = 0;
  var nan = global.NaN, inf = global.Infinity;
  var tempInt = 0, tempBigInt = 0, tempBigIntS = 0, tempValue = 0, tempDouble = 0.0;
  var tempRet0 = 0;

  var Math_floor=global.Math.floor;
  var Math_abs=global.Math.abs;
  var Math_sqrt=global.Math.sqrt;
  var Math_pow=global.Math.pow;
  var Math_cos=global.Math.cos;
  var Math_sin=global.Math.sin;
  var Math_tan=global.Math.tan;
  var Math_acos=global.Math.acos;
  var Math_asin=global.Math.asin;
  var Math_atan=global.Math.atan;
  var Math_atan2=global.Math.atan2;
  var Math_exp=global.Math.exp;
  var Math_log=global.Math.log;
  var Math_ceil=global.Math.ceil;
  var Math_imul=global.Math.imul;
  var Math_min=global.Math.min;
  var Math_max=global.Math.max;
  var Math_clz32=global.Math.clz32;
  var Math_fround=global.Math.fround;
  var tempFloat = Math_fround(0);
  const f0 = Math_fround(0);

// EMSCRIPTEN_START_FUNCS


// EMSCRIPTEN_START_FUNCS

function _malloc(i1) {
 i1 = i1 | 0;
 var i2 = 0, i3 = 0, i4 = 0, i5 = 0, i6 = 0, i7 = 0, i8 = 0, i9 = 0, i10 = 0, i11 = 0, i12 = 0, i13 = 0, i14 = 0, i15 = 0;
 i15 = STACKTOP;
 STACKTOP = STACKTOP + 16 | 0;
 i13 = i15;
 do if (i1 >>> 0 < 245) {
  i10 = i1 >>> 0 < 11 ? 16 : i1 + 11 & -8;
  i1 = i10 >>> 3;
  i12 = HEAP32[440704] | 0;
  i2 = i12 >>> i1;
  if (i2 & 3 | 0) {
   i1 = (i2 & 1 ^ 1) + i1 | 0;
   i2 = 1762856 + (i1 << 1 << 2) | 0;
   i3 = i2 + 8 | 0;
   i4 = HEAP32[i3 >> 2] | 0;
   i5 = i4 + 8 | 0;
   i6 = HEAP32[i5 >> 2] | 0;
   if ((i6 | 0) == (i2 | 0)) HEAP32[440704] = i12 & ~(1 << i1); else {
    HEAP32[i6 + 12 >> 2] = i2;
    HEAP32[i3 >> 2] = i6;
   }
   i14 = i1 << 3;
   HEAP32[i4 + 4 >> 2] = i14 | 3;
   i14 = i4 + i14 + 4 | 0;
   HEAP32[i14 >> 2] = HEAP32[i14 >> 2] | 1;
   i14 = i5;
   STACKTOP = i15;
   return i14 | 0;
  }
  i11 = HEAP32[440706] | 0;
  if (i10 >>> 0 > i11 >>> 0) {
   if (i2 | 0) {
    i8 = 2 << i1;
    i1 = i2 << i1 & (i8 | 0 - i8);
    i1 = (i1 & 0 - i1) + -1 | 0;
    i8 = i1 >>> 12 & 16;
    i1 = i1 >>> i8;
    i3 = i1 >>> 5 & 8;
    i1 = i1 >>> i3;
    i6 = i1 >>> 2 & 4;
    i1 = i1 >>> i6;
    i2 = i1 >>> 1 & 2;
    i1 = i1 >>> i2;
    i4 = i1 >>> 1 & 1;
    i4 = (i3 | i8 | i6 | i2 | i4) + (i1 >>> i4) | 0;
    i1 = 1762856 + (i4 << 1 << 2) | 0;
    i2 = i1 + 8 | 0;
    i6 = HEAP32[i2 >> 2] | 0;
    i8 = i6 + 8 | 0;
    i3 = HEAP32[i8 >> 2] | 0;
    if ((i3 | 0) == (i1 | 0)) {
     i2 = i12 & ~(1 << i4);
     HEAP32[440704] = i2;
    } else {
     HEAP32[i3 + 12 >> 2] = i1;
     HEAP32[i2 >> 2] = i3;
     i2 = i12;
    }
    i14 = i4 << 3;
    i7 = i14 - i10 | 0;
    HEAP32[i6 + 4 >> 2] = i10 | 3;
    i5 = i6 + i10 | 0;
    HEAP32[i5 + 4 >> 2] = i7 | 1;
    HEAP32[i6 + i14 >> 2] = i7;
    if (i11 | 0) {
     i4 = HEAP32[440709] | 0;
     i1 = i11 >>> 3;
     i3 = 1762856 + (i1 << 1 << 2) | 0;
     i1 = 1 << i1;
     if (!(i2 & i1)) {
      HEAP32[440704] = i2 | i1;
      i1 = i3;
      i2 = i3 + 8 | 0;
     } else {
      i2 = i3 + 8 | 0;
      i1 = HEAP32[i2 >> 2] | 0;
     }
     HEAP32[i2 >> 2] = i4;
     HEAP32[i1 + 12 >> 2] = i4;
     HEAP32[i4 + 8 >> 2] = i1;
     HEAP32[i4 + 12 >> 2] = i3;
    }
    HEAP32[440706] = i7;
    HEAP32[440709] = i5;
    i14 = i8;
    STACKTOP = i15;
    return i14 | 0;
   }
   i6 = HEAP32[440705] | 0;
   if (i6) {
    i2 = (i6 & 0 - i6) + -1 | 0;
    i5 = i2 >>> 12 & 16;
    i2 = i2 >>> i5;
    i4 = i2 >>> 5 & 8;
    i2 = i2 >>> i4;
    i7 = i2 >>> 2 & 4;
    i2 = i2 >>> i7;
    i8 = i2 >>> 1 & 2;
    i2 = i2 >>> i8;
    i9 = i2 >>> 1 & 1;
    i9 = HEAP32[1763120 + ((i4 | i5 | i7 | i8 | i9) + (i2 >>> i9) << 2) >> 2] | 0;
    i2 = i9;
    i8 = i9;
    i9 = (HEAP32[i9 + 4 >> 2] & -8) - i10 | 0;
    while (1) {
     i1 = HEAP32[i2 + 16 >> 2] | 0;
     if (!i1) {
      i1 = HEAP32[i2 + 20 >> 2] | 0;
      if (!i1) break;
     }
     i7 = (HEAP32[i1 + 4 >> 2] & -8) - i10 | 0;
     i5 = i7 >>> 0 < i9 >>> 0;
     i2 = i1;
     i8 = i5 ? i1 : i8;
     i9 = i5 ? i7 : i9;
    }
    i7 = i8 + i10 | 0;
    if (i7 >>> 0 > i8 >>> 0) {
     i5 = HEAP32[i8 + 24 >> 2] | 0;
     i1 = HEAP32[i8 + 12 >> 2] | 0;
     do if ((i1 | 0) == (i8 | 0)) {
      i2 = i8 + 20 | 0;
      i1 = HEAP32[i2 >> 2] | 0;
      if (!i1) {
       i2 = i8 + 16 | 0;
       i1 = HEAP32[i2 >> 2] | 0;
       if (!i1) {
        i3 = 0;
        break;
       }
      }
      while (1) {
       i4 = i1 + 20 | 0;
       i3 = HEAP32[i4 >> 2] | 0;
       if (!i3) {
        i4 = i1 + 16 | 0;
        i3 = HEAP32[i4 >> 2] | 0;
        if (!i3) break; else {
         i1 = i3;
         i2 = i4;
        }
       } else {
        i1 = i3;
        i2 = i4;
       }
      }
      HEAP32[i2 >> 2] = 0;
      i3 = i1;
     } else {
      i3 = HEAP32[i8 + 8 >> 2] | 0;
      HEAP32[i3 + 12 >> 2] = i1;
      HEAP32[i1 + 8 >> 2] = i3;
      i3 = i1;
     } while (0);
     do if (i5 | 0) {
      i1 = HEAP32[i8 + 28 >> 2] | 0;
      i2 = 1763120 + (i1 << 2) | 0;
      if ((i8 | 0) == (HEAP32[i2 >> 2] | 0)) {
       HEAP32[i2 >> 2] = i3;
       if (!i3) {
        HEAP32[440705] = i6 & ~(1 << i1);
        break;
       }
      } else {
       i14 = i5 + 16 | 0;
       HEAP32[((HEAP32[i14 >> 2] | 0) == (i8 | 0) ? i14 : i5 + 20 | 0) >> 2] = i3;
       if (!i3) break;
      }
      HEAP32[i3 + 24 >> 2] = i5;
      i1 = HEAP32[i8 + 16 >> 2] | 0;
      if (i1 | 0) {
       HEAP32[i3 + 16 >> 2] = i1;
       HEAP32[i1 + 24 >> 2] = i3;
      }
      i1 = HEAP32[i8 + 20 >> 2] | 0;
      if (i1 | 0) {
       HEAP32[i3 + 20 >> 2] = i1;
       HEAP32[i1 + 24 >> 2] = i3;
      }
     } while (0);
     if (i9 >>> 0 < 16) {
      i14 = i9 + i10 | 0;
      HEAP32[i8 + 4 >> 2] = i14 | 3;
      i14 = i8 + i14 + 4 | 0;
      HEAP32[i14 >> 2] = HEAP32[i14 >> 2] | 1;
     } else {
      HEAP32[i8 + 4 >> 2] = i10 | 3;
      HEAP32[i7 + 4 >> 2] = i9 | 1;
      HEAP32[i7 + i9 >> 2] = i9;
      if (i11 | 0) {
       i4 = HEAP32[440709] | 0;
       i1 = i11 >>> 3;
       i3 = 1762856 + (i1 << 1 << 2) | 0;
       i1 = 1 << i1;
       if (!(i1 & i12)) {
        HEAP32[440704] = i1 | i12;
        i1 = i3;
        i2 = i3 + 8 | 0;
       } else {
        i2 = i3 + 8 | 0;
        i1 = HEAP32[i2 >> 2] | 0;
       }
       HEAP32[i2 >> 2] = i4;
       HEAP32[i1 + 12 >> 2] = i4;
       HEAP32[i4 + 8 >> 2] = i1;
       HEAP32[i4 + 12 >> 2] = i3;
      }
      HEAP32[440706] = i9;
      HEAP32[440709] = i7;
     }
     i14 = i8 + 8 | 0;
     STACKTOP = i15;
     return i14 | 0;
    }
   }
  }
 } else if (i1 >>> 0 > 4294967231) i10 = -1; else {
  i1 = i1 + 11 | 0;
  i10 = i1 & -8;
  i9 = HEAP32[440705] | 0;
  if (i9) {
   i3 = 0 - i10 | 0;
   i1 = i1 >>> 8;
   if (!i1) i7 = 0; else if (i10 >>> 0 > 16777215) i7 = 31; else {
    i12 = (i1 + 1048320 | 0) >>> 16 & 8;
    i14 = i1 << i12;
    i11 = (i14 + 520192 | 0) >>> 16 & 4;
    i14 = i14 << i11;
    i7 = (i14 + 245760 | 0) >>> 16 & 2;
    i7 = 14 - (i11 | i12 | i7) + (i14 << i7 >>> 15) | 0;
    i7 = i10 >>> (i7 + 7 | 0) & 1 | i7 << 1;
   }
   i2 = HEAP32[1763120 + (i7 << 2) >> 2] | 0;
   L79 : do if (!i2) {
    i2 = 0;
    i1 = 0;
    i14 = 61;
   } else {
    i1 = 0;
    i6 = i10 << ((i7 | 0) == 31 ? 0 : 25 - (i7 >>> 1) | 0);
    i4 = 0;
    while (1) {
     i5 = (HEAP32[i2 + 4 >> 2] & -8) - i10 | 0;
     if (i5 >>> 0 < i3 >>> 0) if (!i5) {
      i1 = i2;
      i3 = 0;
      i14 = 65;
      break L79;
     } else {
      i1 = i2;
      i3 = i5;
     }
     i14 = HEAP32[i2 + 20 >> 2] | 0;
     i2 = HEAP32[i2 + 16 + (i6 >>> 31 << 2) >> 2] | 0;
     i4 = (i14 | 0) == 0 | (i14 | 0) == (i2 | 0) ? i4 : i14;
     if (!i2) {
      i2 = i4;
      i14 = 61;
      break;
     } else i6 = i6 << 1;
    }
   } while (0);
   if ((i14 | 0) == 61) {
    if ((i2 | 0) == 0 & (i1 | 0) == 0) {
     i1 = 2 << i7;
     i1 = (i1 | 0 - i1) & i9;
     if (!i1) break;
     i12 = (i1 & 0 - i1) + -1 | 0;
     i7 = i12 >>> 12 & 16;
     i12 = i12 >>> i7;
     i6 = i12 >>> 5 & 8;
     i12 = i12 >>> i6;
     i8 = i12 >>> 2 & 4;
     i12 = i12 >>> i8;
     i11 = i12 >>> 1 & 2;
     i12 = i12 >>> i11;
     i2 = i12 >>> 1 & 1;
     i1 = 0;
     i2 = HEAP32[1763120 + ((i6 | i7 | i8 | i11 | i2) + (i12 >>> i2) << 2) >> 2] | 0;
    }
    if (!i2) {
     i8 = i1;
     i6 = i3;
    } else i14 = 65;
   }
   if ((i14 | 0) == 65) {
    i4 = i2;
    while (1) {
     i12 = (HEAP32[i4 + 4 >> 2] & -8) - i10 | 0;
     i2 = i12 >>> 0 < i3 >>> 0;
     i3 = i2 ? i12 : i3;
     i1 = i2 ? i4 : i1;
     i2 = HEAP32[i4 + 16 >> 2] | 0;
     if (!i2) i2 = HEAP32[i4 + 20 >> 2] | 0;
     if (!i2) {
      i8 = i1;
      i6 = i3;
      break;
     } else i4 = i2;
    }
   }
   if (i8) if (i6 >>> 0 < ((HEAP32[440706] | 0) - i10 | 0) >>> 0) {
    i7 = i8 + i10 | 0;
    if (i7 >>> 0 > i8 >>> 0) {
     i5 = HEAP32[i8 + 24 >> 2] | 0;
     i1 = HEAP32[i8 + 12 >> 2] | 0;
     do if ((i1 | 0) == (i8 | 0)) {
      i2 = i8 + 20 | 0;
      i1 = HEAP32[i2 >> 2] | 0;
      if (!i1) {
       i2 = i8 + 16 | 0;
       i1 = HEAP32[i2 >> 2] | 0;
       if (!i1) {
        i1 = 0;
        break;
       }
      }
      while (1) {
       i4 = i1 + 20 | 0;
       i3 = HEAP32[i4 >> 2] | 0;
       if (!i3) {
        i4 = i1 + 16 | 0;
        i3 = HEAP32[i4 >> 2] | 0;
        if (!i3) break; else {
         i1 = i3;
         i2 = i4;
        }
       } else {
        i1 = i3;
        i2 = i4;
       }
      }
      HEAP32[i2 >> 2] = 0;
     } else {
      i14 = HEAP32[i8 + 8 >> 2] | 0;
      HEAP32[i14 + 12 >> 2] = i1;
      HEAP32[i1 + 8 >> 2] = i14;
     } while (0);
     do if (!i5) i4 = i9; else {
      i2 = HEAP32[i8 + 28 >> 2] | 0;
      i3 = 1763120 + (i2 << 2) | 0;
      if ((i8 | 0) == (HEAP32[i3 >> 2] | 0)) {
       HEAP32[i3 >> 2] = i1;
       if (!i1) {
        i4 = i9 & ~(1 << i2);
        HEAP32[440705] = i4;
        break;
       }
      } else {
       i14 = i5 + 16 | 0;
       HEAP32[((HEAP32[i14 >> 2] | 0) == (i8 | 0) ? i14 : i5 + 20 | 0) >> 2] = i1;
       if (!i1) {
        i4 = i9;
        break;
       }
      }
      HEAP32[i1 + 24 >> 2] = i5;
      i2 = HEAP32[i8 + 16 >> 2] | 0;
      if (i2 | 0) {
       HEAP32[i1 + 16 >> 2] = i2;
       HEAP32[i2 + 24 >> 2] = i1;
      }
      i2 = HEAP32[i8 + 20 >> 2] | 0;
      if (!i2) i4 = i9; else {
       HEAP32[i1 + 20 >> 2] = i2;
       HEAP32[i2 + 24 >> 2] = i1;
       i4 = i9;
      }
     } while (0);
     L128 : do if (i6 >>> 0 < 16) {
      i14 = i6 + i10 | 0;
      HEAP32[i8 + 4 >> 2] = i14 | 3;
      i14 = i8 + i14 + 4 | 0;
      HEAP32[i14 >> 2] = HEAP32[i14 >> 2] | 1;
     } else {
      HEAP32[i8 + 4 >> 2] = i10 | 3;
      HEAP32[i7 + 4 >> 2] = i6 | 1;
      HEAP32[i7 + i6 >> 2] = i6;
      i1 = i6 >>> 3;
      if (i6 >>> 0 < 256) {
       i3 = 1762856 + (i1 << 1 << 2) | 0;
       i2 = HEAP32[440704] | 0;
       i1 = 1 << i1;
       if (!(i2 & i1)) {
        HEAP32[440704] = i2 | i1;
        i1 = i3;
        i2 = i3 + 8 | 0;
       } else {
        i2 = i3 + 8 | 0;
        i1 = HEAP32[i2 >> 2] | 0;
       }
       HEAP32[i2 >> 2] = i7;
       HEAP32[i1 + 12 >> 2] = i7;
       HEAP32[i7 + 8 >> 2] = i1;
       HEAP32[i7 + 12 >> 2] = i3;
       break;
      }
      i1 = i6 >>> 8;
      if (!i1) i3 = 0; else if (i6 >>> 0 > 16777215) i3 = 31; else {
       i13 = (i1 + 1048320 | 0) >>> 16 & 8;
       i14 = i1 << i13;
       i12 = (i14 + 520192 | 0) >>> 16 & 4;
       i14 = i14 << i12;
       i3 = (i14 + 245760 | 0) >>> 16 & 2;
       i3 = 14 - (i12 | i13 | i3) + (i14 << i3 >>> 15) | 0;
       i3 = i6 >>> (i3 + 7 | 0) & 1 | i3 << 1;
      }
      i1 = 1763120 + (i3 << 2) | 0;
      HEAP32[i7 + 28 >> 2] = i3;
      i2 = i7 + 16 | 0;
      HEAP32[i2 + 4 >> 2] = 0;
      HEAP32[i2 >> 2] = 0;
      i2 = 1 << i3;
      if (!(i4 & i2)) {
       HEAP32[440705] = i4 | i2;
       HEAP32[i1 >> 2] = i7;
       HEAP32[i7 + 24 >> 2] = i1;
       HEAP32[i7 + 12 >> 2] = i7;
       HEAP32[i7 + 8 >> 2] = i7;
       break;
      }
      i1 = HEAP32[i1 >> 2] | 0;
      L145 : do if ((HEAP32[i1 + 4 >> 2] & -8 | 0) != (i6 | 0)) {
       i4 = i6 << ((i3 | 0) == 31 ? 0 : 25 - (i3 >>> 1) | 0);
       while (1) {
        i3 = i1 + 16 + (i4 >>> 31 << 2) | 0;
        i2 = HEAP32[i3 >> 2] | 0;
        if (!i2) break;
        if ((HEAP32[i2 + 4 >> 2] & -8 | 0) == (i6 | 0)) {
         i1 = i2;
         break L145;
        } else {
         i4 = i4 << 1;
         i1 = i2;
        }
       }
       HEAP32[i3 >> 2] = i7;
       HEAP32[i7 + 24 >> 2] = i1;
       HEAP32[i7 + 12 >> 2] = i7;
       HEAP32[i7 + 8 >> 2] = i7;
       break L128;
      } while (0);
      i13 = i1 + 8 | 0;
      i14 = HEAP32[i13 >> 2] | 0;
      HEAP32[i14 + 12 >> 2] = i7;
      HEAP32[i13 >> 2] = i7;
      HEAP32[i7 + 8 >> 2] = i14;
      HEAP32[i7 + 12 >> 2] = i1;
      HEAP32[i7 + 24 >> 2] = 0;
     } while (0);
     i14 = i8 + 8 | 0;
     STACKTOP = i15;
     return i14 | 0;
    }
   }
  }
 } while (0);
 i3 = HEAP32[440706] | 0;
 if (i3 >>> 0 >= i10 >>> 0) {
  i1 = i3 - i10 | 0;
  i2 = HEAP32[440709] | 0;
  if (i1 >>> 0 > 15) {
   i14 = i2 + i10 | 0;
   HEAP32[440709] = i14;
   HEAP32[440706] = i1;
   HEAP32[i14 + 4 >> 2] = i1 | 1;
   HEAP32[i2 + i3 >> 2] = i1;
   HEAP32[i2 + 4 >> 2] = i10 | 3;
  } else {
   HEAP32[440706] = 0;
   HEAP32[440709] = 0;
   HEAP32[i2 + 4 >> 2] = i3 | 3;
   i14 = i2 + i3 + 4 | 0;
   HEAP32[i14 >> 2] = HEAP32[i14 >> 2] | 1;
  }
  i14 = i2 + 8 | 0;
  STACKTOP = i15;
  return i14 | 0;
 }
 i6 = HEAP32[440707] | 0;
 if (i6 >>> 0 > i10 >>> 0) {
  i12 = i6 - i10 | 0;
  HEAP32[440707] = i12;
  i14 = HEAP32[440710] | 0;
  i13 = i14 + i10 | 0;
  HEAP32[440710] = i13;
  HEAP32[i13 + 4 >> 2] = i12 | 1;
  HEAP32[i14 + 4 >> 2] = i10 | 3;
  i14 = i14 + 8 | 0;
  STACKTOP = i15;
  return i14 | 0;
 }
 if (!(HEAP32[440822] | 0)) {
  HEAP32[440824] = 4096;
  HEAP32[440823] = 4096;
  HEAP32[440825] = -1;
  HEAP32[440826] = -1;
  HEAP32[440827] = 0;
  HEAP32[440815] = 0;
  HEAP32[440822] = i13 & -16 ^ 1431655768;
  i1 = 4096;
 } else i1 = HEAP32[440824] | 0;
 i7 = i10 + 48 | 0;
 i8 = i10 + 47 | 0;
 i5 = i1 + i8 | 0;
 i4 = 0 - i1 | 0;
 i9 = i5 & i4;
 if (i9 >>> 0 <= i10 >>> 0) {
  i14 = 0;
  STACKTOP = i15;
  return i14 | 0;
 }
 i1 = HEAP32[440814] | 0;
 if (i1 | 0) {
  i12 = HEAP32[440812] | 0;
  i13 = i12 + i9 | 0;
  if (i13 >>> 0 <= i12 >>> 0 | i13 >>> 0 > i1 >>> 0) {
   i14 = 0;
   STACKTOP = i15;
   return i14 | 0;
  }
 }
 L178 : do if (!(HEAP32[440815] & 4)) {
  i2 = HEAP32[440710] | 0;
  L180 : do if (!i2) i14 = 128; else {
   i3 = 1763264;
   while (1) {
    i1 = HEAP32[i3 >> 2] | 0;
    if (i1 >>> 0 <= i2 >>> 0) if ((i1 + (HEAP32[i3 + 4 >> 2] | 0) | 0) >>> 0 > i2 >>> 0) break;
    i1 = HEAP32[i3 + 8 >> 2] | 0;
    if (!i1) {
     i14 = 128;
     break L180;
    } else i3 = i1;
   }
   i1 = i5 - i6 & i4;
   if (i1 >>> 0 < 2147483647) {
    i4 = _sbrk(i1 | 0) | 0;
    if ((i4 | 0) == ((HEAP32[i3 >> 2] | 0) + (HEAP32[i3 + 4 >> 2] | 0) | 0)) {
     if ((i4 | 0) != (-1 | 0)) {
      i14 = 145;
      break L178;
     }
    } else i14 = 136;
   } else i1 = 0;
  } while (0);
  do if ((i14 | 0) == 128) {
   i4 = _sbrk(0) | 0;
   if ((i4 | 0) == (-1 | 0)) i1 = 0; else {
    i1 = i4;
    i2 = HEAP32[440823] | 0;
    i3 = i2 + -1 | 0;
    i1 = ((i3 & i1 | 0) == 0 ? 0 : (i3 + i1 & 0 - i2) - i1 | 0) + i9 | 0;
    i2 = HEAP32[440812] | 0;
    i3 = i1 + i2 | 0;
    if (i1 >>> 0 > i10 >>> 0 & i1 >>> 0 < 2147483647) {
     i5 = HEAP32[440814] | 0;
     if (i5 | 0) if (i3 >>> 0 <= i2 >>> 0 | i3 >>> 0 > i5 >>> 0) {
      i1 = 0;
      break;
     }
     i2 = _sbrk(i1 | 0) | 0;
     if ((i2 | 0) == (i4 | 0)) {
      i14 = 145;
      break L178;
     } else {
      i4 = i2;
      i14 = 136;
     }
    } else i1 = 0;
   }
  } while (0);
  do if ((i14 | 0) == 136) {
   i3 = 0 - i1 | 0;
   if (!(i7 >>> 0 > i1 >>> 0 & (i1 >>> 0 < 2147483647 & (i4 | 0) != (-1 | 0)))) if ((i4 | 0) == (-1 | 0)) {
    i1 = 0;
    break;
   } else {
    i14 = 145;
    break L178;
   }
   i2 = HEAP32[440824] | 0;
   i2 = i8 - i1 + i2 & 0 - i2;
   if (i2 >>> 0 >= 2147483647) {
    i14 = 145;
    break L178;
   }
   if ((_sbrk(i2 | 0) | 0) == (-1 | 0)) {
    _sbrk(i3 | 0) | 0;
    i1 = 0;
    break;
   } else {
    i1 = i2 + i1 | 0;
    i14 = 145;
    break L178;
   }
  } while (0);
  HEAP32[440815] = HEAP32[440815] | 4;
  i14 = 143;
 } else {
  i1 = 0;
  i14 = 143;
 } while (0);
 if ((i14 | 0) == 143) if (i9 >>> 0 < 2147483647) {
  i4 = _sbrk(i9 | 0) | 0;
  i13 = _sbrk(0) | 0;
  i2 = i13 - i4 | 0;
  i3 = i2 >>> 0 > (i10 + 40 | 0) >>> 0;
  if (!((i4 | 0) == (-1 | 0) | i3 ^ 1 | i4 >>> 0 < i13 >>> 0 & ((i4 | 0) != (-1 | 0) & (i13 | 0) != (-1 | 0)) ^ 1)) {
   i1 = i3 ? i2 : i1;
   i14 = 145;
  }
 }
 if ((i14 | 0) == 145) {
  i2 = (HEAP32[440812] | 0) + i1 | 0;
  HEAP32[440812] = i2;
  if (i2 >>> 0 > (HEAP32[440813] | 0) >>> 0) HEAP32[440813] = i2;
  i9 = HEAP32[440710] | 0;
  L215 : do if (!i9) {
   i14 = HEAP32[440708] | 0;
   if ((i14 | 0) == 0 | i4 >>> 0 < i14 >>> 0) HEAP32[440708] = i4;
   HEAP32[440816] = i4;
   HEAP32[440817] = i1;
   HEAP32[440819] = 0;
   HEAP32[440713] = HEAP32[440822];
   HEAP32[440712] = -1;
   HEAP32[440717] = 1762856;
   HEAP32[440716] = 1762856;
   HEAP32[440719] = 1762864;
   HEAP32[440718] = 1762864;
   HEAP32[440721] = 1762872;
   HEAP32[440720] = 1762872;
   HEAP32[440723] = 1762880;
   HEAP32[440722] = 1762880;
   HEAP32[440725] = 1762888;
   HEAP32[440724] = 1762888;
   HEAP32[440727] = 1762896;
   HEAP32[440726] = 1762896;
   HEAP32[440729] = 1762904;
   HEAP32[440728] = 1762904;
   HEAP32[440731] = 1762912;
   HEAP32[440730] = 1762912;
   HEAP32[440733] = 1762920;
   HEAP32[440732] = 1762920;
   HEAP32[440735] = 1762928;
   HEAP32[440734] = 1762928;
   HEAP32[440737] = 1762936;
   HEAP32[440736] = 1762936;
   HEAP32[440739] = 1762944;
   HEAP32[440738] = 1762944;
   HEAP32[440741] = 1762952;
   HEAP32[440740] = 1762952;
   HEAP32[440743] = 1762960;
   HEAP32[440742] = 1762960;
   HEAP32[440745] = 1762968;
   HEAP32[440744] = 1762968;
   HEAP32[440747] = 1762976;
   HEAP32[440746] = 1762976;
   HEAP32[440749] = 1762984;
   HEAP32[440748] = 1762984;
   HEAP32[440751] = 1762992;
   HEAP32[440750] = 1762992;
   HEAP32[440753] = 1763e3;
   HEAP32[440752] = 1763e3;
   HEAP32[440755] = 1763008;
   HEAP32[440754] = 1763008;
   HEAP32[440757] = 1763016;
   HEAP32[440756] = 1763016;
   HEAP32[440759] = 1763024;
   HEAP32[440758] = 1763024;
   HEAP32[440761] = 1763032;
   HEAP32[440760] = 1763032;
   HEAP32[440763] = 1763040;
   HEAP32[440762] = 1763040;
   HEAP32[440765] = 1763048;
   HEAP32[440764] = 1763048;
   HEAP32[440767] = 1763056;
   HEAP32[440766] = 1763056;
   HEAP32[440769] = 1763064;
   HEAP32[440768] = 1763064;
   HEAP32[440771] = 1763072;
   HEAP32[440770] = 1763072;
   HEAP32[440773] = 1763080;
   HEAP32[440772] = 1763080;
   HEAP32[440775] = 1763088;
   HEAP32[440774] = 1763088;
   HEAP32[440777] = 1763096;
   HEAP32[440776] = 1763096;
   HEAP32[440779] = 1763104;
   HEAP32[440778] = 1763104;
   i14 = i1 + -40 | 0;
   i12 = i4 + 8 | 0;
   i12 = (i12 & 7 | 0) == 0 ? 0 : 0 - i12 & 7;
   i13 = i4 + i12 | 0;
   i12 = i14 - i12 | 0;
   HEAP32[440710] = i13;
   HEAP32[440707] = i12;
   HEAP32[i13 + 4 >> 2] = i12 | 1;
   HEAP32[i4 + i14 + 4 >> 2] = 40;
   HEAP32[440711] = HEAP32[440826];
  } else {
   i2 = 1763264;
   do {
    i3 = HEAP32[i2 >> 2] | 0;
    i5 = HEAP32[i2 + 4 >> 2] | 0;
    if ((i4 | 0) == (i3 + i5 | 0)) {
     i14 = 154;
     break;
    }
    i2 = HEAP32[i2 + 8 >> 2] | 0;
   } while ((i2 | 0) != 0);
   if ((i14 | 0) == 154) {
    i6 = i2 + 4 | 0;
    if (!(HEAP32[i2 + 12 >> 2] & 8)) if (i4 >>> 0 > i9 >>> 0 & i3 >>> 0 <= i9 >>> 0) {
     HEAP32[i6 >> 2] = i5 + i1;
     i14 = (HEAP32[440707] | 0) + i1 | 0;
     i12 = i9 + 8 | 0;
     i12 = (i12 & 7 | 0) == 0 ? 0 : 0 - i12 & 7;
     i13 = i9 + i12 | 0;
     i12 = i14 - i12 | 0;
     HEAP32[440710] = i13;
     HEAP32[440707] = i12;
     HEAP32[i13 + 4 >> 2] = i12 | 1;
     HEAP32[i9 + i14 + 4 >> 2] = 40;
     HEAP32[440711] = HEAP32[440826];
     break;
    }
   }
   if (i4 >>> 0 < (HEAP32[440708] | 0) >>> 0) HEAP32[440708] = i4;
   i3 = i4 + i1 | 0;
   i2 = 1763264;
   do {
    if ((HEAP32[i2 >> 2] | 0) == (i3 | 0)) {
     i14 = 162;
     break;
    }
    i2 = HEAP32[i2 + 8 >> 2] | 0;
   } while ((i2 | 0) != 0);
   if ((i14 | 0) == 162) if (!(HEAP32[i2 + 12 >> 2] & 8)) {
    HEAP32[i2 >> 2] = i4;
    i12 = i2 + 4 | 0;
    HEAP32[i12 >> 2] = (HEAP32[i12 >> 2] | 0) + i1;
    i12 = i4 + 8 | 0;
    i12 = i4 + ((i12 & 7 | 0) == 0 ? 0 : 0 - i12 & 7) | 0;
    i1 = i3 + 8 | 0;
    i1 = i3 + ((i1 & 7 | 0) == 0 ? 0 : 0 - i1 & 7) | 0;
    i11 = i12 + i10 | 0;
    i8 = i1 - i12 - i10 | 0;
    HEAP32[i12 + 4 >> 2] = i10 | 3;
    L238 : do if ((i9 | 0) == (i1 | 0)) {
     i14 = (HEAP32[440707] | 0) + i8 | 0;
     HEAP32[440707] = i14;
     HEAP32[440710] = i11;
     HEAP32[i11 + 4 >> 2] = i14 | 1;
    } else {
     if ((HEAP32[440709] | 0) == (i1 | 0)) {
      i14 = (HEAP32[440706] | 0) + i8 | 0;
      HEAP32[440706] = i14;
      HEAP32[440709] = i11;
      HEAP32[i11 + 4 >> 2] = i14 | 1;
      HEAP32[i11 + i14 >> 2] = i14;
      break;
     }
     i2 = HEAP32[i1 + 4 >> 2] | 0;
     if ((i2 & 3 | 0) == 1) {
      i7 = i2 & -8;
      i4 = i2 >>> 3;
      L246 : do if (i2 >>> 0 < 256) {
       i2 = HEAP32[i1 + 8 >> 2] | 0;
       i3 = HEAP32[i1 + 12 >> 2] | 0;
       if ((i3 | 0) == (i2 | 0)) {
        HEAP32[440704] = HEAP32[440704] & ~(1 << i4);
        break;
       } else {
        HEAP32[i2 + 12 >> 2] = i3;
        HEAP32[i3 + 8 >> 2] = i2;
        break;
       }
      } else {
       i6 = HEAP32[i1 + 24 >> 2] | 0;
       i2 = HEAP32[i1 + 12 >> 2] | 0;
       do if ((i2 | 0) == (i1 | 0)) {
        i3 = i1 + 16 | 0;
        i4 = i3 + 4 | 0;
        i2 = HEAP32[i4 >> 2] | 0;
        if (!i2) {
         i2 = HEAP32[i3 >> 2] | 0;
         if (!i2) {
          i2 = 0;
          break;
         }
        } else i3 = i4;
        while (1) {
         i5 = i2 + 20 | 0;
         i4 = HEAP32[i5 >> 2] | 0;
         if (!i4) {
          i5 = i2 + 16 | 0;
          i4 = HEAP32[i5 >> 2] | 0;
          if (!i4) break; else {
           i2 = i4;
           i3 = i5;
          }
         } else {
          i2 = i4;
          i3 = i5;
         }
        }
        HEAP32[i3 >> 2] = 0;
       } else {
        i14 = HEAP32[i1 + 8 >> 2] | 0;
        HEAP32[i14 + 12 >> 2] = i2;
        HEAP32[i2 + 8 >> 2] = i14;
       } while (0);
       if (!i6) break;
       i3 = HEAP32[i1 + 28 >> 2] | 0;
       i4 = 1763120 + (i3 << 2) | 0;
       do if ((HEAP32[i4 >> 2] | 0) == (i1 | 0)) {
        HEAP32[i4 >> 2] = i2;
        if (i2 | 0) break;
        HEAP32[440705] = HEAP32[440705] & ~(1 << i3);
        break L246;
       } else {
        i14 = i6 + 16 | 0;
        HEAP32[((HEAP32[i14 >> 2] | 0) == (i1 | 0) ? i14 : i6 + 20 | 0) >> 2] = i2;
        if (!i2) break L246;
       } while (0);
       HEAP32[i2 + 24 >> 2] = i6;
       i3 = i1 + 16 | 0;
       i4 = HEAP32[i3 >> 2] | 0;
       if (i4 | 0) {
        HEAP32[i2 + 16 >> 2] = i4;
        HEAP32[i4 + 24 >> 2] = i2;
       }
       i3 = HEAP32[i3 + 4 >> 2] | 0;
       if (!i3) break;
       HEAP32[i2 + 20 >> 2] = i3;
       HEAP32[i3 + 24 >> 2] = i2;
      } while (0);
      i1 = i1 + i7 | 0;
      i5 = i7 + i8 | 0;
     } else i5 = i8;
     i1 = i1 + 4 | 0;
     HEAP32[i1 >> 2] = HEAP32[i1 >> 2] & -2;
     HEAP32[i11 + 4 >> 2] = i5 | 1;
     HEAP32[i11 + i5 >> 2] = i5;
     i1 = i5 >>> 3;
     if (i5 >>> 0 < 256) {
      i3 = 1762856 + (i1 << 1 << 2) | 0;
      i2 = HEAP32[440704] | 0;
      i1 = 1 << i1;
      if (!(i2 & i1)) {
       HEAP32[440704] = i2 | i1;
       i1 = i3;
       i2 = i3 + 8 | 0;
      } else {
       i2 = i3 + 8 | 0;
       i1 = HEAP32[i2 >> 2] | 0;
      }
      HEAP32[i2 >> 2] = i11;
      HEAP32[i1 + 12 >> 2] = i11;
      HEAP32[i11 + 8 >> 2] = i1;
      HEAP32[i11 + 12 >> 2] = i3;
      break;
     }
     i1 = i5 >>> 8;
     do if (!i1) i4 = 0; else {
      if (i5 >>> 0 > 16777215) {
       i4 = 31;
       break;
      }
      i13 = (i1 + 1048320 | 0) >>> 16 & 8;
      i14 = i1 << i13;
      i10 = (i14 + 520192 | 0) >>> 16 & 4;
      i14 = i14 << i10;
      i4 = (i14 + 245760 | 0) >>> 16 & 2;
      i4 = 14 - (i10 | i13 | i4) + (i14 << i4 >>> 15) | 0;
      i4 = i5 >>> (i4 + 7 | 0) & 1 | i4 << 1;
     } while (0);
     i1 = 1763120 + (i4 << 2) | 0;
     HEAP32[i11 + 28 >> 2] = i4;
     i2 = i11 + 16 | 0;
     HEAP32[i2 + 4 >> 2] = 0;
     HEAP32[i2 >> 2] = 0;
     i2 = HEAP32[440705] | 0;
     i3 = 1 << i4;
     if (!(i2 & i3)) {
      HEAP32[440705] = i2 | i3;
      HEAP32[i1 >> 2] = i11;
      HEAP32[i11 + 24 >> 2] = i1;
      HEAP32[i11 + 12 >> 2] = i11;
      HEAP32[i11 + 8 >> 2] = i11;
      break;
     }
     i1 = HEAP32[i1 >> 2] | 0;
     L291 : do if ((HEAP32[i1 + 4 >> 2] & -8 | 0) != (i5 | 0)) {
      i4 = i5 << ((i4 | 0) == 31 ? 0 : 25 - (i4 >>> 1) | 0);
      while (1) {
       i3 = i1 + 16 + (i4 >>> 31 << 2) | 0;
       i2 = HEAP32[i3 >> 2] | 0;
       if (!i2) break;
       if ((HEAP32[i2 + 4 >> 2] & -8 | 0) == (i5 | 0)) {
        i1 = i2;
        break L291;
       } else {
        i4 = i4 << 1;
        i1 = i2;
       }
      }
      HEAP32[i3 >> 2] = i11;
      HEAP32[i11 + 24 >> 2] = i1;
      HEAP32[i11 + 12 >> 2] = i11;
      HEAP32[i11 + 8 >> 2] = i11;
      break L238;
     } while (0);
     i13 = i1 + 8 | 0;
     i14 = HEAP32[i13 >> 2] | 0;
     HEAP32[i14 + 12 >> 2] = i11;
     HEAP32[i13 >> 2] = i11;
     HEAP32[i11 + 8 >> 2] = i14;
     HEAP32[i11 + 12 >> 2] = i1;
     HEAP32[i11 + 24 >> 2] = 0;
    } while (0);
    i14 = i12 + 8 | 0;
    STACKTOP = i15;
    return i14 | 0;
   }
   i3 = 1763264;
   while (1) {
    i2 = HEAP32[i3 >> 2] | 0;
    if (i2 >>> 0 <= i9 >>> 0) {
     i2 = i2 + (HEAP32[i3 + 4 >> 2] | 0) | 0;
     if (i2 >>> 0 > i9 >>> 0) break;
    }
    i3 = HEAP32[i3 + 8 >> 2] | 0;
   }
   i6 = i2 + -47 | 0;
   i3 = i6 + 8 | 0;
   i3 = i6 + ((i3 & 7 | 0) == 0 ? 0 : 0 - i3 & 7) | 0;
   i6 = i9 + 16 | 0;
   i3 = i3 >>> 0 < i6 >>> 0 ? i9 : i3;
   i14 = i3 + 8 | 0;
   i5 = i1 + -40 | 0;
   i12 = i4 + 8 | 0;
   i12 = (i12 & 7 | 0) == 0 ? 0 : 0 - i12 & 7;
   i13 = i4 + i12 | 0;
   i12 = i5 - i12 | 0;
   HEAP32[440710] = i13;
   HEAP32[440707] = i12;
   HEAP32[i13 + 4 >> 2] = i12 | 1;
   HEAP32[i4 + i5 + 4 >> 2] = 40;
   HEAP32[440711] = HEAP32[440826];
   i5 = i3 + 4 | 0;
   HEAP32[i5 >> 2] = 27;
   HEAP32[i14 >> 2] = HEAP32[440816];
   HEAP32[i14 + 4 >> 2] = HEAP32[440817];
   HEAP32[i14 + 8 >> 2] = HEAP32[440818];
   HEAP32[i14 + 12 >> 2] = HEAP32[440819];
   HEAP32[440816] = i4;
   HEAP32[440817] = i1;
   HEAP32[440819] = 0;
   HEAP32[440818] = i14;
   i1 = i3 + 24 | 0;
   do {
    i14 = i1;
    i1 = i1 + 4 | 0;
    HEAP32[i1 >> 2] = 7;
   } while ((i14 + 8 | 0) >>> 0 < i2 >>> 0);
   if ((i3 | 0) != (i9 | 0)) {
    i7 = i3 - i9 | 0;
    HEAP32[i5 >> 2] = HEAP32[i5 >> 2] & -2;
    HEAP32[i9 + 4 >> 2] = i7 | 1;
    HEAP32[i3 >> 2] = i7;
    i1 = i7 >>> 3;
    if (i7 >>> 0 < 256) {
     i3 = 1762856 + (i1 << 1 << 2) | 0;
     i2 = HEAP32[440704] | 0;
     i1 = 1 << i1;
     if (!(i2 & i1)) {
      HEAP32[440704] = i2 | i1;
      i1 = i3;
      i2 = i3 + 8 | 0;
     } else {
      i2 = i3 + 8 | 0;
      i1 = HEAP32[i2 >> 2] | 0;
     }
     HEAP32[i2 >> 2] = i9;
     HEAP32[i1 + 12 >> 2] = i9;
     HEAP32[i9 + 8 >> 2] = i1;
     HEAP32[i9 + 12 >> 2] = i3;
     break;
    }
    i1 = i7 >>> 8;
    if (!i1) i4 = 0; else if (i7 >>> 0 > 16777215) i4 = 31; else {
     i13 = (i1 + 1048320 | 0) >>> 16 & 8;
     i14 = i1 << i13;
     i12 = (i14 + 520192 | 0) >>> 16 & 4;
     i14 = i14 << i12;
     i4 = (i14 + 245760 | 0) >>> 16 & 2;
     i4 = 14 - (i12 | i13 | i4) + (i14 << i4 >>> 15) | 0;
     i4 = i7 >>> (i4 + 7 | 0) & 1 | i4 << 1;
    }
    i3 = 1763120 + (i4 << 2) | 0;
    HEAP32[i9 + 28 >> 2] = i4;
    HEAP32[i9 + 20 >> 2] = 0;
    HEAP32[i6 >> 2] = 0;
    i1 = HEAP32[440705] | 0;
    i2 = 1 << i4;
    if (!(i1 & i2)) {
     HEAP32[440705] = i1 | i2;
     HEAP32[i3 >> 2] = i9;
     HEAP32[i9 + 24 >> 2] = i3;
     HEAP32[i9 + 12 >> 2] = i9;
     HEAP32[i9 + 8 >> 2] = i9;
     break;
    }
    i1 = HEAP32[i3 >> 2] | 0;
    L325 : do if ((HEAP32[i1 + 4 >> 2] & -8 | 0) != (i7 | 0)) {
     i4 = i7 << ((i4 | 0) == 31 ? 0 : 25 - (i4 >>> 1) | 0);
     while (1) {
      i3 = i1 + 16 + (i4 >>> 31 << 2) | 0;
      i2 = HEAP32[i3 >> 2] | 0;
      if (!i2) break;
      if ((HEAP32[i2 + 4 >> 2] & -8 | 0) == (i7 | 0)) {
       i1 = i2;
       break L325;
      } else {
       i4 = i4 << 1;
       i1 = i2;
      }
     }
     HEAP32[i3 >> 2] = i9;
     HEAP32[i9 + 24 >> 2] = i1;
     HEAP32[i9 + 12 >> 2] = i9;
     HEAP32[i9 + 8 >> 2] = i9;
     break L215;
    } while (0);
    i13 = i1 + 8 | 0;
    i14 = HEAP32[i13 >> 2] | 0;
    HEAP32[i14 + 12 >> 2] = i9;
    HEAP32[i13 >> 2] = i9;
    HEAP32[i9 + 8 >> 2] = i14;
    HEAP32[i9 + 12 >> 2] = i1;
    HEAP32[i9 + 24 >> 2] = 0;
   }
  } while (0);
  i1 = HEAP32[440707] | 0;
  if (i1 >>> 0 > i10 >>> 0) {
   i12 = i1 - i10 | 0;
   HEAP32[440707] = i12;
   i14 = HEAP32[440710] | 0;
   i13 = i14 + i10 | 0;
   HEAP32[440710] = i13;
   HEAP32[i13 + 4 >> 2] = i12 | 1;
   HEAP32[i14 + 4 >> 2] = i10 | 3;
   i14 = i14 + 8 | 0;
   STACKTOP = i15;
   return i14 | 0;
  }
 }
 HEAP32[(___errno_location() | 0) >> 2] = 12;
 i14 = 0;
 STACKTOP = i15;
 return i14 | 0;
}

function _calc() {
 var i1 = 0, i2 = 0, i3 = 0, i4 = 0, f5 = f0, f6 = f0, f7 = f0, i8 = 0, i9 = 0, f10 = f0, i11 = 0, i12 = 0, i13 = 0, i14 = 0, f15 = f0, f16 = f0, f17 = f0, f18 = f0, f19 = f0, f20 = f0, f21 = f0;
 i1 = HEAP32[240674] | 0;
 i4 = i1 >> 1;
 i8 = i1 >> 2;
 i2 = HEAP32[240676] | 0;
 i9 = i4 - i2 | 0;
 if ((i2 | 0) > 0) {
  i3 = 0;
  do {
   i2 = HEAP16[597632 + (i3 << 1) >> 1] << 2;
   i13 = i3 + i9 | 0;
   i14 = HEAP32[131200 + (i13 << 2) >> 2] | 0;
   HEAP32[631424 + (i2 << 3) >> 2] = HEAP32[128 + (i13 << 2) >> 2];
   HEAP32[631424 + (i2 << 3) + 4 >> 2] = i14;
   i14 = 614016 + (i3 << 2) | 0;
   f10 = Math_fround(HEAPF32[i14 >> 2]);
   i12 = i13 + i4 | 0;
   i11 = i2 | 1;
   HEAPF32[631424 + (i11 << 3) >> 2] = Math_fround(f10 * Math_fround(HEAPF32[128 + (i12 << 2) >> 2]));
   f10 = Math_fround(HEAPF32[i14 >> 2]);
   HEAPF32[631424 + (i11 << 3) + 4 >> 2] = Math_fround(f10 * Math_fround(HEAPF32[131200 + (i12 << 2) >> 2]));
   i11 = i2 | 2;
   i13 = i13 + i8 | 0;
   i12 = HEAP32[131200 + (i13 << 2) >> 2] | 0;
   HEAP32[631424 + (i11 << 3) >> 2] = HEAP32[128 + (i13 << 2) >> 2];
   HEAP32[631424 + (i11 << 3) + 4 >> 2] = i12;
   i2 = i2 | 3;
   HEAPF32[631424 + (i2 << 3) >> 2] = Math_fround(0.0);
   HEAPF32[631424 + (i2 << 3) + 4 >> 2] = Math_fround(0.0);
   i3 = i3 + 1 | 0;
   i2 = HEAP32[240676] | 0;
  } while ((i3 | 0) < (i2 | 0));
 }
 if ((i2 | 0) < (i8 | 0)) {
  i3 = i9 + i8 | 0;
  i1 = i2;
  do {
   i14 = HEAP16[597632 + (i1 << 1) >> 1] << 2;
   i11 = i1 + i9 | 0;
   i13 = HEAP32[131200 + (i11 << 2) >> 2] | 0;
   HEAP32[631424 + (i14 << 3) >> 2] = HEAP32[128 + (i11 << 2) >> 2];
   HEAP32[631424 + (i14 << 3) + 4 >> 2] = i13;
   i13 = i14 | 1;
   HEAPF32[631424 + (i13 << 3) >> 2] = Math_fround(0.0);
   HEAPF32[631424 + (i13 << 3) + 4 >> 2] = Math_fround(0.0);
   i13 = i14 | 2;
   i11 = i3 + i1 | 0;
   i12 = HEAP32[131200 + (i11 << 2) >> 2] | 0;
   HEAP32[631424 + (i13 << 3) >> 2] = HEAP32[128 + (i11 << 2) >> 2];
   HEAP32[631424 + (i13 << 3) + 4 >> 2] = i12;
   i14 = i14 | 3;
   HEAPF32[631424 + (i14 << 3) >> 2] = Math_fround(0.0);
   HEAPF32[631424 + (i14 << 3) + 4 >> 2] = Math_fround(0.0);
   i1 = i1 + 1 | 0;
  } while ((i1 | 0) != (i8 | 0));
  i1 = HEAP32[240674] | 0;
 }
 L12 : do if ((i1 | 0) < 8192) switch (i1 | 0) {
 case 1024:
  {
   _fft_calc_1024(631424);
   break L12;
  }
 case 2048:
  {
   _fft_calc_2048(631424);
   break L12;
  }
 case 4096:
  {
   _fft_calc_4096(631424);
   break L12;
  }
 default:
  break L12;
 } else {
  if ((i1 | 0) < 16384) {
   switch (i1 | 0) {
   case 8192:
    break;
   default:
    break L12;
   }
   _fft_calc_8192(631424);
   break;
  }
  if ((i1 | 0) < 32768) {
   switch (i1 | 0) {
   case 16384:
    break;
   default:
    break L12;
   }
   _fft_calc_4096(631424);
   _fft_calc_4096(664192);
   _fft_calc_4096(696960);
   _fft_calc_4096(729728);
   f15 = Math_fround(HEAPF32[157856]);
   f16 = Math_fround(HEAPF32[157857]);
   f6 = Math_fround(HEAPF32[166048]);
   f5 = Math_fround(HEAPF32[166049]);
   f20 = Math_fround(HEAPF32[174240]);
   f19 = Math_fround(HEAPF32[174241]);
   f10 = Math_fround(HEAPF32[182432]);
   f7 = Math_fround(HEAPF32[182433]);
   f17 = Math_fround(f15 + f6);
   f18 = Math_fround(f16 + f5);
   f6 = Math_fround(f15 - f6);
   f5 = Math_fround(f16 - f5);
   f16 = Math_fround(f20 + f10);
   f15 = Math_fround(f19 + f7);
   f10 = Math_fround(f20 - f10);
   f7 = Math_fround(f19 - f7);
   f19 = Math_fround(f18 + f15);
   HEAPF32[157856] = Math_fround(f17 + f16);
   HEAPF32[157857] = f19;
   f19 = Math_fround(f5 - f10);
   HEAPF32[166048] = Math_fround(f6 + f7);
   HEAPF32[166049] = f19;
   f15 = Math_fround(f18 - f15);
   HEAPF32[174240] = Math_fround(f17 - f16);
   HEAPF32[174241] = f15;
   f10 = Math_fround(f5 + f10);
   HEAPF32[182432] = Math_fround(f6 - f7);
   HEAPF32[182433] = f10;
   i1 = 1;
   do {
    i3 = 631424 + (i1 << 3) | 0;
    f16 = Math_fround(HEAPF32[i3 >> 2]);
    i4 = 631424 + (i1 << 3) + 4 | 0;
    f15 = Math_fround(HEAPF32[i4 >> 2]);
    f10 = Math_fround(HEAPF32[335488 + (i1 << 3) >> 2]);
    i9 = i1 + 4096 | 0;
    i8 = 631424 + (i9 << 3) | 0;
    f5 = Math_fround(HEAPF32[i8 >> 2]);
    f18 = Math_fround(f10 * f5);
    f20 = Math_fround(HEAPF32[335488 + (i1 << 3) + 4 >> 2]);
    i9 = 631424 + (i9 << 3) + 4 | 0;
    f17 = Math_fround(HEAPF32[i9 >> 2]);
    f18 = Math_fround(f18 - Math_fround(f20 * f17));
    f17 = Math_fround(Math_fround(f5 * f20) + Math_fround(f10 * f17));
    f10 = Math_fround(HEAPF32[401024 + (i1 << 3) >> 2]);
    i12 = i1 + 8192 | 0;
    i11 = 631424 + (i12 << 3) | 0;
    f20 = Math_fround(HEAPF32[i11 >> 2]);
    f5 = Math_fround(f10 * f20);
    f21 = Math_fround(HEAPF32[401024 + (i1 << 3) + 4 >> 2]);
    i12 = 631424 + (i12 << 3) + 4 | 0;
    f6 = Math_fround(HEAPF32[i12 >> 2]);
    f5 = Math_fround(f5 - Math_fround(f21 * f6));
    f6 = Math_fround(Math_fround(f20 * f21) + Math_fround(f10 * f6));
    f10 = Math_fround(HEAPF32[368256 + (i1 << 3) >> 2]);
    i14 = i1 + 12288 | 0;
    i13 = 631424 + (i14 << 3) | 0;
    f21 = Math_fround(HEAPF32[i13 >> 2]);
    f20 = Math_fround(f10 * f21);
    f7 = Math_fround(HEAPF32[368256 + (i1 << 3) + 4 >> 2]);
    i14 = 631424 + (i14 << 3) + 4 | 0;
    f19 = Math_fround(HEAPF32[i14 >> 2]);
    f20 = Math_fround(f20 - Math_fround(f7 * f19));
    f19 = Math_fround(Math_fround(f21 * f7) + Math_fround(f10 * f19));
    f10 = Math_fround(f16 + f18);
    f7 = Math_fround(f15 + f17);
    f18 = Math_fround(f16 - f18);
    f17 = Math_fround(f15 - f17);
    f15 = Math_fround(f5 + f20);
    f16 = Math_fround(f6 + f19);
    f20 = Math_fround(f5 - f20);
    f19 = Math_fround(f6 - f19);
    f6 = Math_fround(f7 + f16);
    HEAPF32[i3 >> 2] = Math_fround(f10 + f15);
    HEAPF32[i4 >> 2] = f6;
    f6 = Math_fround(f17 - f20);
    HEAPF32[i8 >> 2] = Math_fround(f18 + f19);
    HEAPF32[i9 >> 2] = f6;
    f16 = Math_fround(f7 - f16);
    HEAPF32[i11 >> 2] = Math_fround(f10 - f15);
    HEAPF32[i12 >> 2] = f16;
    f20 = Math_fround(f17 + f20);
    HEAPF32[i13 >> 2] = Math_fround(f18 - f19);
    HEAPF32[i14 >> 2] = f20;
    i1 = i1 + 1 | 0;
   } while ((i1 | 0) != 4096);
  } else {
   switch (i1 | 0) {
   case 32768:
    break;
   default:
    break L12;
   }
   _fft_calc_8192(631424);
   _fft_calc_8192(696960);
   _fft_calc_8192(762496);
   _fft_calc_8192(828032);
   f17 = Math_fround(HEAPF32[157856]);
   f16 = Math_fround(HEAPF32[157857]);
   f19 = Math_fround(HEAPF32[174240]);
   f18 = Math_fround(HEAPF32[174241]);
   f6 = Math_fround(HEAPF32[190624]);
   f7 = Math_fround(HEAPF32[190625]);
   f21 = Math_fround(HEAPF32[207008]);
   f20 = Math_fround(HEAPF32[207009]);
   f15 = Math_fround(f17 + f19);
   f10 = Math_fround(f16 + f18);
   f19 = Math_fround(f17 - f19);
   f18 = Math_fround(f16 - f18);
   f16 = Math_fround(f6 + f21);
   f17 = Math_fround(f7 + f20);
   f21 = Math_fround(f6 - f21);
   f20 = Math_fround(f7 - f20);
   f7 = Math_fround(f10 + f17);
   HEAPF32[157856] = Math_fround(f15 + f16);
   HEAPF32[157857] = f7;
   f7 = Math_fround(f18 - f21);
   HEAPF32[174240] = Math_fround(f19 + f20);
   HEAPF32[174241] = f7;
   f17 = Math_fround(f10 - f17);
   HEAPF32[190624] = Math_fround(f15 - f16);
   HEAPF32[190625] = f17;
   f21 = Math_fround(f18 + f21);
   HEAPF32[207008] = Math_fround(f19 - f20);
   HEAPF32[207009] = f21;
   i1 = 1;
   do {
    i3 = 631424 + (i1 << 3) | 0;
    f17 = Math_fround(HEAPF32[i3 >> 2]);
    i4 = 631424 + (i1 << 3) + 4 | 0;
    f16 = Math_fround(HEAPF32[i4 >> 2]);
    f15 = Math_fround(HEAPF32[401024 + (i1 << 3) >> 2]);
    i9 = i1 + 8192 | 0;
    i8 = 631424 + (i9 << 3) | 0;
    f6 = Math_fround(HEAPF32[i8 >> 2]);
    f19 = Math_fround(f15 * f6);
    f21 = Math_fround(HEAPF32[401024 + (i1 << 3) + 4 >> 2]);
    i9 = 631424 + (i9 << 3) + 4 | 0;
    f18 = Math_fround(HEAPF32[i9 >> 2]);
    f19 = Math_fround(f19 - Math_fround(f21 * f18));
    f18 = Math_fround(Math_fround(f6 * f21) + Math_fround(f15 * f18));
    f15 = Math_fround(HEAPF32[532096 + (i1 << 3) >> 2]);
    i12 = i1 + 16384 | 0;
    i11 = 631424 + (i12 << 3) | 0;
    f21 = Math_fround(HEAPF32[i11 >> 2]);
    f6 = Math_fround(f15 * f21);
    f5 = Math_fround(HEAPF32[532096 + (i1 << 3) + 4 >> 2]);
    i12 = 631424 + (i12 << 3) + 4 | 0;
    f7 = Math_fround(HEAPF32[i12 >> 2]);
    f6 = Math_fround(f6 - Math_fround(f5 * f7));
    f7 = Math_fround(Math_fround(f21 * f5) + Math_fround(f15 * f7));
    f15 = Math_fround(HEAPF32[466560 + (i1 << 3) >> 2]);
    i14 = i1 + 24576 | 0;
    i13 = 631424 + (i14 << 3) | 0;
    f5 = Math_fround(HEAPF32[i13 >> 2]);
    f21 = Math_fround(f15 * f5);
    f10 = Math_fround(HEAPF32[466560 + (i1 << 3) + 4 >> 2]);
    i14 = 631424 + (i14 << 3) + 4 | 0;
    f20 = Math_fround(HEAPF32[i14 >> 2]);
    f21 = Math_fround(f21 - Math_fround(f10 * f20));
    f20 = Math_fround(Math_fround(f5 * f10) + Math_fround(f15 * f20));
    f15 = Math_fround(f17 + f19);
    f10 = Math_fround(f16 + f18);
    f19 = Math_fround(f17 - f19);
    f18 = Math_fround(f16 - f18);
    f16 = Math_fround(f6 + f21);
    f17 = Math_fround(f7 + f20);
    f21 = Math_fround(f6 - f21);
    f20 = Math_fround(f7 - f20);
    f7 = Math_fround(f10 + f17);
    HEAPF32[i3 >> 2] = Math_fround(f15 + f16);
    HEAPF32[i4 >> 2] = f7;
    f7 = Math_fround(f18 - f21);
    HEAPF32[i8 >> 2] = Math_fround(f19 + f20);
    HEAPF32[i9 >> 2] = f7;
    f17 = Math_fround(f10 - f17);
    HEAPF32[i11 >> 2] = Math_fround(f15 - f16);
    HEAPF32[i12 >> 2] = f17;
    f21 = Math_fround(f18 + f21);
    HEAPF32[i13 >> 2] = Math_fround(f19 - f20);
    HEAPF32[i14 >> 2] = f21;
    i1 = i1 + 1 | 0;
   } while ((i1 | 0) != 8192);
  }
 } while (0);
 i1 = HEAP32[240675] | 0;
 if ((i1 | 0) > 0) {
  i11 = 0;
  i2 = 0;
  do {
   i9 = HEAP32[962716 + (i2 << 2) >> 2] | 0;
   i4 = HEAP32[962716 + (i2 + 1 << 2) >> 2] | 0;
   if (!i9) {
    i1 = 893568 + (i11 << 4) | 0;
    HEAP32[i1 >> 2] = 0;
    HEAP32[i1 + 4 >> 2] = 0;
    HEAP32[i1 + 8 >> 2] = 0;
    HEAP32[i1 + 12 >> 2] = 0;
    i1 = HEAP32[240675] | 0;
   } else {
    if ((i9 | 0) > 0) {
     i8 = HEAP32[240674] | 0;
     i2 = i2 + 2 | 0;
     i3 = 0;
     f10 = Math_fround(0.0);
     f7 = Math_fround(0.0);
     f6 = Math_fround(0.0);
     f5 = Math_fround(0.0);
     do {
      i13 = i3 + i4 | 0;
      i14 = i8 - i13 | 0;
      f21 = Math_fround(HEAPF32[962716 + (i2 + i3 << 2) >> 2]);
      f7 = Math_fround(f7 + Math_fround(f21 * Math_fround(HEAPF32[631424 + (i13 << 3) >> 2])));
      f5 = Math_fround(f5 + Math_fround(f21 * Math_fround(HEAPF32[631424 + (i13 << 3) + 4 >> 2])));
      f10 = Math_fround(f10 + Math_fround(f21 * Math_fround(HEAPF32[631424 + (i14 << 3) >> 2])));
      f6 = Math_fround(f6 + Math_fround(f21 * Math_fround(HEAPF32[631424 + (i14 << 3) + 4 >> 2])));
      i3 = i3 + 1 | 0;
     } while ((i3 | 0) != (i9 | 0));
    } else {
     i2 = i2 + 2 | 0;
     f10 = Math_fround(0.0);
     f7 = Math_fround(0.0);
     f6 = Math_fround(0.0);
     f5 = Math_fround(0.0);
    }
    f18 = Math_fround(f10 + f7);
    f21 = Math_fround(f5 - f6);
    f19 = Math_fround(f6 + f5);
    f20 = Math_fround(f10 - f7);
    f21 = Math_fround(Math_fround(f18 * f18) + Math_fround(f21 * f21));
    f19 = Math_fround(Math_fround(f20 * f20) + Math_fround(f19 * f19));
    f20 = Math_fround(HEAPF32[240677]);
    f18 = Math_fround(Math_fround(Math_sqrt(Math_fround(Math_fround(Math_sqrt(Math_fround(f21))) * f20))) * Math_fround(0.0));
    i14 = f18 < Math_fround(255.0);
    HEAPF32[893568 + (i11 << 4) >> 2] = i14 ? f18 : Math_fround(255.0);
    f21 = Math_fround(Math_sqrt(Math_fround(Math_fround(f21 + f19) * Math_fround(.5))));
    f18 = Math_fround(Math_fround(Math_sqrt(Math_fround(f21 * f20))) * Math_fround(0.0));
    i14 = f18 < Math_fround(255.0);
    HEAPF32[893568 + (i11 << 4) + 4 >> 2] = i14 ? f18 : Math_fround(255.0);
    f20 = Math_fround(Math_fround(Math_sqrt(Math_fround(Math_fround(Math_sqrt(Math_fround(f19))) * f20))) * Math_fround(255.0));
    i14 = f20 < Math_fround(255.0);
    HEAPF32[893568 + (i11 << 4) + 8 >> 2] = i14 ? f20 : Math_fround(255.0);
    HEAPF32[893568 + (i11 << 4) + 12 >> 2] = Math_fround(f21 * Math_fround(HEAPF32[240678]));
    i2 = i2 + i9 | 0;
   }
   i11 = i11 + 1 | 0;
  } while ((i11 | 0) < (i1 | 0));
 }
 i2 = HEAP32[240672] | 0;
 if (!((i1 | 0) != (i2 | 0) & (i2 | 0) > 0)) return;
 i1 = 0;
 do {
  i13 = i1 << 1;
  f21 = Math_fround(HEAPF32[893568 + (i13 << 4) >> 2]);
  i14 = i13 | 1;
  HEAPF32[893568 + (i1 << 4) >> 2] = Math_fround(Math_fround(f21 + Math_fround(HEAPF32[893568 + (i14 << 4) >> 2])) * Math_fround(.5));
  f21 = Math_fround(HEAPF32[893568 + (i13 << 4) + 4 >> 2]);
  HEAPF32[893568 + (i1 << 4) + 4 >> 2] = Math_fround(Math_fround(f21 + Math_fround(HEAPF32[893568 + (i14 << 4) + 4 >> 2])) * Math_fround(.5));
  f21 = Math_fround(HEAPF32[893568 + (i13 << 4) + 8 >> 2]);
  HEAPF32[893568 + (i1 << 4) + 8 >> 2] = Math_fround(Math_fround(f21 + Math_fround(HEAPF32[893568 + (i14 << 4) + 8 >> 2])) * Math_fround(.5));
  f21 = Math_fround(HEAPF32[893568 + (i13 << 4) + 12 >> 2]);
  HEAPF32[893568 + (i1 << 4) + 12 >> 2] = Math_fround(Math_fround(f21 + Math_fround(HEAPF32[893568 + (i14 << 4) + 12 >> 2])) * Math_fround(.5));
  i1 = i1 + 1 | 0;
 } while ((i1 | 0) != (i2 | 0));
 return;
}

function _fft_calc_16(i1) {
 i1 = i1 | 0;
 var i2 = 0, f3 = f0, i4 = 0, f5 = f0, f6 = f0, f7 = f0, i8 = 0, f9 = f0, i10 = 0, f11 = f0, f12 = f0, f13 = f0, i14 = 0, f15 = f0, i16 = 0, i17 = 0, i18 = 0, f19 = f0, f20 = f0, i21 = 0, i22 = 0, i23 = 0, i24 = 0, i25 = 0, i26 = 0, i27 = 0, i28 = 0, i29 = 0, i30 = 0, i31 = 0, i32 = 0, i33 = 0, i34 = 0, i35 = 0, i36 = 0, i37 = 0, i38 = 0, i39 = 0, i40 = 0, f41 = f0, i42 = 0, f43 = f0, i44 = 0, i45 = 0, f46 = f0, f47 = f0, f48 = f0, f49 = f0, f50 = f0, f51 = f0, f52 = f0;
 f6 = Math_fround(HEAPF32[i1 >> 2]);
 i45 = i1 + 4 | 0;
 f19 = Math_fround(HEAPF32[i45 >> 2]);
 i36 = i1 + 8 | 0;
 f47 = Math_fround(HEAPF32[i36 >> 2]);
 i35 = i1 + 12 | 0;
 f48 = Math_fround(HEAPF32[i35 >> 2]);
 i28 = i1 + 16 | 0;
 f20 = Math_fround(HEAPF32[i28 >> 2]);
 i27 = i1 + 20 | 0;
 f7 = Math_fround(HEAPF32[i27 >> 2]);
 i18 = i1 + 24 | 0;
 f43 = Math_fround(HEAPF32[i18 >> 2]);
 i17 = i1 + 28 | 0;
 f46 = Math_fround(HEAPF32[i17 >> 2]);
 f9 = Math_fround(f6 + f47);
 f12 = Math_fround(f19 + f48);
 f47 = Math_fround(f6 - f47);
 f48 = Math_fround(f19 - f48);
 f19 = Math_fround(f20 + f43);
 f6 = Math_fround(f7 + f46);
 f43 = Math_fround(f20 - f43);
 f46 = Math_fround(f7 - f46);
 f7 = Math_fround(f9 + f19);
 f20 = Math_fround(f12 + f6);
 HEAPF32[i1 >> 2] = f7;
 HEAPF32[i45 >> 2] = f20;
 f49 = Math_fround(f48 - f43);
 HEAPF32[i36 >> 2] = Math_fround(f47 + f46);
 HEAPF32[i35 >> 2] = f49;
 f6 = Math_fround(f12 - f6);
 HEAPF32[i28 >> 2] = Math_fround(f9 - f19);
 HEAPF32[i27 >> 2] = f6;
 f43 = Math_fround(f48 + f43);
 HEAPF32[i18 >> 2] = Math_fround(f47 - f46);
 HEAPF32[i17 >> 2] = f43;
 i44 = i1 + 32 | 0;
 f43 = Math_fround(HEAPF32[i44 >> 2]);
 i42 = i1 + 36 | 0;
 f46 = Math_fround(HEAPF32[i42 >> 2]);
 i34 = i1 + 40 | 0;
 f47 = Math_fround(HEAPF32[i34 >> 2]);
 i33 = i1 + 44 | 0;
 f48 = Math_fround(HEAPF32[i33 >> 2]);
 i26 = i1 + 48 | 0;
 f6 = Math_fround(HEAPF32[i26 >> 2]);
 i25 = i1 + 52 | 0;
 f19 = Math_fround(HEAPF32[i25 >> 2]);
 i16 = i1 + 56 | 0;
 f9 = Math_fround(HEAPF32[i16 >> 2]);
 i14 = i1 + 60 | 0;
 f12 = Math_fround(HEAPF32[i14 >> 2]);
 f49 = Math_fround(f43 + f47);
 f50 = Math_fround(f46 + f48);
 f47 = Math_fround(f43 - f47);
 f48 = Math_fround(f46 - f48);
 f46 = Math_fround(f6 + f9);
 f43 = Math_fround(f19 + f12);
 f9 = Math_fround(f6 - f9);
 f12 = Math_fround(f19 - f12);
 f19 = Math_fround(f49 + f46);
 f6 = Math_fround(f50 + f43);
 HEAPF32[i44 >> 2] = f19;
 HEAPF32[i42 >> 2] = f6;
 f13 = Math_fround(f48 - f9);
 HEAPF32[i34 >> 2] = Math_fround(f47 + f12);
 HEAPF32[i33 >> 2] = f13;
 f43 = Math_fround(f50 - f43);
 HEAPF32[i26 >> 2] = Math_fround(f49 - f46);
 HEAPF32[i25 >> 2] = f43;
 f9 = Math_fround(f48 + f9);
 HEAPF32[i16 >> 2] = Math_fround(f47 - f12);
 HEAPF32[i14 >> 2] = f9;
 i40 = i1 + 64 | 0;
 f9 = Math_fround(HEAPF32[i40 >> 2]);
 i39 = i1 + 68 | 0;
 f12 = Math_fround(HEAPF32[i39 >> 2]);
 i32 = i1 + 72 | 0;
 f47 = Math_fround(HEAPF32[i32 >> 2]);
 i31 = i1 + 76 | 0;
 f48 = Math_fround(HEAPF32[i31 >> 2]);
 i24 = i1 + 80 | 0;
 f43 = Math_fround(HEAPF32[i24 >> 2]);
 i23 = i1 + 84 | 0;
 f46 = Math_fround(HEAPF32[i23 >> 2]);
 i10 = i1 + 88 | 0;
 f49 = Math_fround(HEAPF32[i10 >> 2]);
 i8 = i1 + 92 | 0;
 f50 = Math_fround(HEAPF32[i8 >> 2]);
 f13 = Math_fround(f9 + f47);
 f41 = Math_fround(f12 + f48);
 f47 = Math_fround(f9 - f47);
 f48 = Math_fround(f12 - f48);
 f12 = Math_fround(f43 + f49);
 f9 = Math_fround(f46 + f50);
 f49 = Math_fround(f43 - f49);
 f50 = Math_fround(f46 - f50);
 f46 = Math_fround(f13 + f12);
 f43 = Math_fround(f41 + f9);
 f5 = Math_fround(f47 + f50);
 f15 = Math_fround(f48 - f49);
 HEAPF32[i32 >> 2] = f5;
 HEAPF32[i31 >> 2] = f15;
 f9 = Math_fround(f41 - f9);
 HEAPF32[i24 >> 2] = Math_fround(f13 - f12);
 HEAPF32[i23 >> 2] = f9;
 f49 = Math_fround(f48 + f49);
 HEAPF32[i10 >> 2] = Math_fround(f47 - f50);
 HEAPF32[i8 >> 2] = f49;
 i38 = i1 + 96 | 0;
 f49 = Math_fround(HEAPF32[i38 >> 2]);
 i37 = i1 + 100 | 0;
 f50 = Math_fround(HEAPF32[i37 >> 2]);
 i30 = i1 + 104 | 0;
 f47 = Math_fround(HEAPF32[i30 >> 2]);
 i29 = i1 + 108 | 0;
 f48 = Math_fround(HEAPF32[i29 >> 2]);
 i22 = i1 + 112 | 0;
 f9 = Math_fround(HEAPF32[i22 >> 2]);
 i21 = i1 + 116 | 0;
 f12 = Math_fround(HEAPF32[i21 >> 2]);
 i4 = i1 + 120 | 0;
 f13 = Math_fround(HEAPF32[i4 >> 2]);
 i2 = i1 + 124 | 0;
 f41 = Math_fround(HEAPF32[i2 >> 2]);
 f51 = Math_fround(f49 + f47);
 f52 = Math_fround(f50 + f48);
 f47 = Math_fround(f49 - f47);
 f48 = Math_fround(f50 - f48);
 f50 = Math_fround(f9 + f13);
 f49 = Math_fround(f12 + f41);
 f13 = Math_fround(f9 - f13);
 f41 = Math_fround(f12 - f41);
 f12 = Math_fround(f51 + f50);
 f9 = Math_fround(f52 + f49);
 f11 = Math_fround(f47 + f41);
 f3 = Math_fround(f48 - f13);
 f49 = Math_fround(f52 - f49);
 HEAPF32[i22 >> 2] = Math_fround(f51 - f50);
 HEAPF32[i21 >> 2] = f49;
 f13 = Math_fround(f48 + f13);
 HEAPF32[i4 >> 2] = Math_fround(f47 - f41);
 HEAPF32[i2 >> 2] = f13;
 f13 = Math_fround(f7 + f19);
 f41 = Math_fround(f20 + f6);
 f19 = Math_fround(f7 - f19);
 f6 = Math_fround(f20 - f6);
 f20 = Math_fround(f46 + f12);
 f7 = Math_fround(f43 + f9);
 f12 = Math_fround(f46 - f12);
 f9 = Math_fround(f43 - f9);
 f43 = Math_fround(f41 + f7);
 HEAPF32[i1 >> 2] = Math_fround(f13 + f20);
 HEAPF32[i45 >> 2] = f43;
 f43 = Math_fround(f6 - f12);
 HEAPF32[i44 >> 2] = Math_fround(f19 + f9);
 HEAPF32[i42 >> 2] = f43;
 f7 = Math_fround(f41 - f7);
 HEAPF32[i40 >> 2] = Math_fround(f13 - f20);
 HEAPF32[i39 >> 2] = f7;
 f12 = Math_fround(f6 + f12);
 HEAPF32[i38 >> 2] = Math_fround(f19 - f9);
 HEAPF32[i37 >> 2] = f12;
 f12 = Math_fround(HEAPF32[i36 >> 2]);
 f9 = Math_fround(HEAPF32[i35 >> 2]);
 f19 = Math_fround(HEAPF32[67506]);
 f6 = Math_fround(HEAPF32[i34 >> 2]);
 f7 = Math_fround(f19 * f6);
 f20 = Math_fround(HEAPF32[67507]);
 f13 = Math_fround(HEAPF32[i33 >> 2]);
 f7 = Math_fround(f7 - Math_fround(f20 * f13));
 f13 = Math_fround(Math_fround(f6 * f20) + Math_fround(f19 * f13));
 f19 = Math_fround(HEAPF32[67522]);
 f20 = Math_fround(f19 * f5);
 f6 = Math_fround(HEAPF32[67523]);
 f20 = Math_fround(f20 - Math_fround(f6 * f15));
 f15 = Math_fround(Math_fround(f5 * f6) + Math_fround(f19 * f15));
 f19 = Math_fround(HEAPF32[67514]);
 f6 = Math_fround(f19 * f11);
 f5 = Math_fround(HEAPF32[67515]);
 f6 = Math_fround(f6 - Math_fround(f5 * f3));
 f3 = Math_fround(Math_fround(f11 * f5) + Math_fround(f19 * f3));
 f19 = Math_fround(f12 + f7);
 f5 = Math_fround(f9 + f13);
 f7 = Math_fround(f12 - f7);
 f13 = Math_fround(f9 - f13);
 f9 = Math_fround(f20 + f6);
 f12 = Math_fround(f15 + f3);
 f6 = Math_fround(f20 - f6);
 f3 = Math_fround(f15 - f3);
 f15 = Math_fround(f5 + f12);
 HEAPF32[i36 >> 2] = Math_fround(f19 + f9);
 HEAPF32[i35 >> 2] = f15;
 f15 = Math_fround(f13 - f6);
 HEAPF32[i34 >> 2] = Math_fround(f7 + f3);
 HEAPF32[i33 >> 2] = f15;
 f12 = Math_fround(f5 - f12);
 HEAPF32[i32 >> 2] = Math_fround(f19 - f9);
 HEAPF32[i31 >> 2] = f12;
 f6 = Math_fround(f13 + f6);
 HEAPF32[i30 >> 2] = Math_fround(f7 - f3);
 HEAPF32[i29 >> 2] = f6;
 f6 = Math_fround(HEAPF32[i28 >> 2]);
 f3 = Math_fround(HEAPF32[i27 >> 2]);
 f7 = Math_fround(HEAPF32[67508]);
 f13 = Math_fround(HEAPF32[i26 >> 2]);
 f12 = Math_fround(f7 * f13);
 f9 = Math_fround(HEAPF32[67509]);
 f19 = Math_fround(HEAPF32[i25 >> 2]);
 f12 = Math_fround(f12 - Math_fround(f9 * f19));
 f19 = Math_fround(Math_fround(f13 * f9) + Math_fround(f7 * f19));
 f7 = Math_fround(HEAPF32[67524]);
 f9 = Math_fround(HEAPF32[i24 >> 2]);
 f13 = Math_fround(f7 * f9);
 f5 = Math_fround(HEAPF32[67525]);
 f15 = Math_fround(HEAPF32[i23 >> 2]);
 f13 = Math_fround(f13 - Math_fround(f5 * f15));
 f15 = Math_fround(Math_fround(f9 * f5) + Math_fround(f7 * f15));
 f7 = Math_fround(HEAPF32[67516]);
 f5 = Math_fround(HEAPF32[i22 >> 2]);
 f9 = Math_fround(f7 * f5);
 f20 = Math_fround(HEAPF32[67517]);
 f11 = Math_fround(HEAPF32[i21 >> 2]);
 f9 = Math_fround(f9 - Math_fround(f20 * f11));
 f11 = Math_fround(Math_fround(f5 * f20) + Math_fround(f7 * f11));
 f7 = Math_fround(f6 + f12);
 f20 = Math_fround(f3 + f19);
 f12 = Math_fround(f6 - f12);
 f19 = Math_fround(f3 - f19);
 f3 = Math_fround(f13 + f9);
 f6 = Math_fround(f15 + f11);
 f9 = Math_fround(f13 - f9);
 f11 = Math_fround(f15 - f11);
 f15 = Math_fround(f20 + f6);
 HEAPF32[i28 >> 2] = Math_fround(f7 + f3);
 HEAPF32[i27 >> 2] = f15;
 f15 = Math_fround(f19 - f9);
 HEAPF32[i26 >> 2] = Math_fround(f12 + f11);
 HEAPF32[i25 >> 2] = f15;
 f6 = Math_fround(f20 - f6);
 HEAPF32[i24 >> 2] = Math_fround(f7 - f3);
 HEAPF32[i23 >> 2] = f6;
 f9 = Math_fround(f19 + f9);
 HEAPF32[i22 >> 2] = Math_fround(f12 - f11);
 HEAPF32[i21 >> 2] = f9;
 f9 = Math_fround(HEAPF32[i18 >> 2]);
 f11 = Math_fround(HEAPF32[i17 >> 2]);
 f12 = Math_fround(HEAPF32[67510]);
 f19 = Math_fround(HEAPF32[i16 >> 2]);
 f6 = Math_fround(f12 * f19);
 f3 = Math_fround(HEAPF32[67511]);
 f7 = Math_fround(HEAPF32[i14 >> 2]);
 f6 = Math_fround(f6 - Math_fround(f3 * f7));
 f7 = Math_fround(Math_fround(f19 * f3) + Math_fround(f12 * f7));
 f12 = Math_fround(HEAPF32[67526]);
 f3 = Math_fround(HEAPF32[i10 >> 2]);
 f19 = Math_fround(f12 * f3);
 f20 = Math_fround(HEAPF32[67527]);
 f15 = Math_fround(HEAPF32[i8 >> 2]);
 f19 = Math_fround(f19 - Math_fround(f20 * f15));
 f15 = Math_fround(Math_fround(f3 * f20) + Math_fround(f12 * f15));
 f12 = Math_fround(HEAPF32[67518]);
 f20 = Math_fround(HEAPF32[i4 >> 2]);
 f3 = Math_fround(f12 * f20);
 f13 = Math_fround(HEAPF32[67519]);
 f5 = Math_fround(HEAPF32[i2 >> 2]);
 f3 = Math_fround(f3 - Math_fround(f13 * f5));
 f5 = Math_fround(Math_fround(f20 * f13) + Math_fround(f12 * f5));
 f12 = Math_fround(f9 + f6);
 f13 = Math_fround(f11 + f7);
 f6 = Math_fround(f9 - f6);
 f7 = Math_fround(f11 - f7);
 f11 = Math_fround(f19 + f3);
 f9 = Math_fround(f15 + f5);
 f3 = Math_fround(f19 - f3);
 f5 = Math_fround(f15 - f5);
 f15 = Math_fround(f13 + f9);
 HEAPF32[i18 >> 2] = Math_fround(f12 + f11);
 HEAPF32[i17 >> 2] = f15;
 f15 = Math_fround(f7 - f3);
 HEAPF32[i16 >> 2] = Math_fround(f6 + f5);
 HEAPF32[i14 >> 2] = f15;
 f9 = Math_fround(f13 - f9);
 HEAPF32[i10 >> 2] = Math_fround(f12 - f11);
 HEAPF32[i8 >> 2] = f9;
 f3 = Math_fround(f7 + f3);
 HEAPF32[i4 >> 2] = Math_fround(f6 - f5);
 HEAPF32[i2 >> 2] = f3;
 return;
}

function _free(i1) {
 i1 = i1 | 0;
 var i2 = 0, i3 = 0, i4 = 0, i5 = 0, i6 = 0, i7 = 0, i8 = 0, i9 = 0;
 if (!i1) return;
 i3 = i1 + -8 | 0;
 i5 = HEAP32[440708] | 0;
 i1 = HEAP32[i1 + -4 >> 2] | 0;
 i2 = i1 & -8;
 i9 = i3 + i2 | 0;
 do if (!(i1 & 1)) {
  i4 = HEAP32[i3 >> 2] | 0;
  if (!(i1 & 3)) return;
  i7 = i3 + (0 - i4) | 0;
  i6 = i4 + i2 | 0;
  if (i7 >>> 0 < i5 >>> 0) return;
  if ((HEAP32[440709] | 0) == (i7 | 0)) {
   i1 = i9 + 4 | 0;
   i2 = HEAP32[i1 >> 2] | 0;
   if ((i2 & 3 | 0) != 3) {
    i8 = i7;
    i2 = i6;
    break;
   }
   HEAP32[440706] = i6;
   HEAP32[i1 >> 2] = i2 & -2;
   HEAP32[i7 + 4 >> 2] = i6 | 1;
   HEAP32[i7 + i6 >> 2] = i6;
   return;
  }
  i3 = i4 >>> 3;
  if (i4 >>> 0 < 256) {
   i1 = HEAP32[i7 + 8 >> 2] | 0;
   i2 = HEAP32[i7 + 12 >> 2] | 0;
   if ((i2 | 0) == (i1 | 0)) {
    HEAP32[440704] = HEAP32[440704] & ~(1 << i3);
    i8 = i7;
    i2 = i6;
    break;
   } else {
    HEAP32[i1 + 12 >> 2] = i2;
    HEAP32[i2 + 8 >> 2] = i1;
    i8 = i7;
    i2 = i6;
    break;
   }
  }
  i5 = HEAP32[i7 + 24 >> 2] | 0;
  i1 = HEAP32[i7 + 12 >> 2] | 0;
  do if ((i1 | 0) == (i7 | 0)) {
   i2 = i7 + 16 | 0;
   i3 = i2 + 4 | 0;
   i1 = HEAP32[i3 >> 2] | 0;
   if (!i1) {
    i1 = HEAP32[i2 >> 2] | 0;
    if (!i1) {
     i1 = 0;
     break;
    }
   } else i2 = i3;
   while (1) {
    i4 = i1 + 20 | 0;
    i3 = HEAP32[i4 >> 2] | 0;
    if (!i3) {
     i4 = i1 + 16 | 0;
     i3 = HEAP32[i4 >> 2] | 0;
     if (!i3) break; else {
      i1 = i3;
      i2 = i4;
     }
    } else {
     i1 = i3;
     i2 = i4;
    }
   }
   HEAP32[i2 >> 2] = 0;
  } else {
   i8 = HEAP32[i7 + 8 >> 2] | 0;
   HEAP32[i8 + 12 >> 2] = i1;
   HEAP32[i1 + 8 >> 2] = i8;
  } while (0);
  if (!i5) {
   i8 = i7;
   i2 = i6;
  } else {
   i2 = HEAP32[i7 + 28 >> 2] | 0;
   i3 = 1763120 + (i2 << 2) | 0;
   if ((HEAP32[i3 >> 2] | 0) == (i7 | 0)) {
    HEAP32[i3 >> 2] = i1;
    if (!i1) {
     HEAP32[440705] = HEAP32[440705] & ~(1 << i2);
     i8 = i7;
     i2 = i6;
     break;
    }
   } else {
    i8 = i5 + 16 | 0;
    HEAP32[((HEAP32[i8 >> 2] | 0) == (i7 | 0) ? i8 : i5 + 20 | 0) >> 2] = i1;
    if (!i1) {
     i8 = i7;
     i2 = i6;
     break;
    }
   }
   HEAP32[i1 + 24 >> 2] = i5;
   i2 = i7 + 16 | 0;
   i3 = HEAP32[i2 >> 2] | 0;
   if (i3 | 0) {
    HEAP32[i1 + 16 >> 2] = i3;
    HEAP32[i3 + 24 >> 2] = i1;
   }
   i2 = HEAP32[i2 + 4 >> 2] | 0;
   if (!i2) {
    i8 = i7;
    i2 = i6;
   } else {
    HEAP32[i1 + 20 >> 2] = i2;
    HEAP32[i2 + 24 >> 2] = i1;
    i8 = i7;
    i2 = i6;
   }
  }
 } else {
  i8 = i3;
  i7 = i3;
 } while (0);
 if (i7 >>> 0 >= i9 >>> 0) return;
 i1 = i9 + 4 | 0;
 i4 = HEAP32[i1 >> 2] | 0;
 if (!(i4 & 1)) return;
 if (!(i4 & 2)) {
  if ((HEAP32[440710] | 0) == (i9 | 0)) {
   i9 = (HEAP32[440707] | 0) + i2 | 0;
   HEAP32[440707] = i9;
   HEAP32[440710] = i8;
   HEAP32[i8 + 4 >> 2] = i9 | 1;
   if ((i8 | 0) != (HEAP32[440709] | 0)) return;
   HEAP32[440709] = 0;
   HEAP32[440706] = 0;
   return;
  }
  if ((HEAP32[440709] | 0) == (i9 | 0)) {
   i9 = (HEAP32[440706] | 0) + i2 | 0;
   HEAP32[440706] = i9;
   HEAP32[440709] = i7;
   HEAP32[i8 + 4 >> 2] = i9 | 1;
   HEAP32[i7 + i9 >> 2] = i9;
   return;
  }
  i5 = (i4 & -8) + i2 | 0;
  i3 = i4 >>> 3;
  do if (i4 >>> 0 < 256) {
   i2 = HEAP32[i9 + 8 >> 2] | 0;
   i1 = HEAP32[i9 + 12 >> 2] | 0;
   if ((i1 | 0) == (i2 | 0)) {
    HEAP32[440704] = HEAP32[440704] & ~(1 << i3);
    break;
   } else {
    HEAP32[i2 + 12 >> 2] = i1;
    HEAP32[i1 + 8 >> 2] = i2;
    break;
   }
  } else {
   i6 = HEAP32[i9 + 24 >> 2] | 0;
   i1 = HEAP32[i9 + 12 >> 2] | 0;
   do if ((i1 | 0) == (i9 | 0)) {
    i2 = i9 + 16 | 0;
    i3 = i2 + 4 | 0;
    i1 = HEAP32[i3 >> 2] | 0;
    if (!i1) {
     i1 = HEAP32[i2 >> 2] | 0;
     if (!i1) {
      i3 = 0;
      break;
     }
    } else i2 = i3;
    while (1) {
     i4 = i1 + 20 | 0;
     i3 = HEAP32[i4 >> 2] | 0;
     if (!i3) {
      i4 = i1 + 16 | 0;
      i3 = HEAP32[i4 >> 2] | 0;
      if (!i3) break; else {
       i1 = i3;
       i2 = i4;
      }
     } else {
      i1 = i3;
      i2 = i4;
     }
    }
    HEAP32[i2 >> 2] = 0;
    i3 = i1;
   } else {
    i3 = HEAP32[i9 + 8 >> 2] | 0;
    HEAP32[i3 + 12 >> 2] = i1;
    HEAP32[i1 + 8 >> 2] = i3;
    i3 = i1;
   } while (0);
   if (i6 | 0) {
    i1 = HEAP32[i9 + 28 >> 2] | 0;
    i2 = 1763120 + (i1 << 2) | 0;
    if ((HEAP32[i2 >> 2] | 0) == (i9 | 0)) {
     HEAP32[i2 >> 2] = i3;
     if (!i3) {
      HEAP32[440705] = HEAP32[440705] & ~(1 << i1);
      break;
     }
    } else {
     i4 = i6 + 16 | 0;
     HEAP32[((HEAP32[i4 >> 2] | 0) == (i9 | 0) ? i4 : i6 + 20 | 0) >> 2] = i3;
     if (!i3) break;
    }
    HEAP32[i3 + 24 >> 2] = i6;
    i1 = i9 + 16 | 0;
    i2 = HEAP32[i1 >> 2] | 0;
    if (i2 | 0) {
     HEAP32[i3 + 16 >> 2] = i2;
     HEAP32[i2 + 24 >> 2] = i3;
    }
    i1 = HEAP32[i1 + 4 >> 2] | 0;
    if (i1 | 0) {
     HEAP32[i3 + 20 >> 2] = i1;
     HEAP32[i1 + 24 >> 2] = i3;
    }
   }
  } while (0);
  HEAP32[i8 + 4 >> 2] = i5 | 1;
  HEAP32[i7 + i5 >> 2] = i5;
  if ((i8 | 0) == (HEAP32[440709] | 0)) {
   HEAP32[440706] = i5;
   return;
  }
 } else {
  HEAP32[i1 >> 2] = i4 & -2;
  HEAP32[i8 + 4 >> 2] = i2 | 1;
  HEAP32[i7 + i2 >> 2] = i2;
  i5 = i2;
 }
 i1 = i5 >>> 3;
 if (i5 >>> 0 < 256) {
  i3 = 1762856 + (i1 << 1 << 2) | 0;
  i2 = HEAP32[440704] | 0;
  i1 = 1 << i1;
  if (!(i2 & i1)) {
   HEAP32[440704] = i2 | i1;
   i1 = i3;
   i2 = i3 + 8 | 0;
  } else {
   i2 = i3 + 8 | 0;
   i1 = HEAP32[i2 >> 2] | 0;
  }
  HEAP32[i2 >> 2] = i8;
  HEAP32[i1 + 12 >> 2] = i8;
  HEAP32[i8 + 8 >> 2] = i1;
  HEAP32[i8 + 12 >> 2] = i3;
  return;
 }
 i1 = i5 >>> 8;
 if (!i1) i4 = 0; else if (i5 >>> 0 > 16777215) i4 = 31; else {
  i7 = (i1 + 1048320 | 0) >>> 16 & 8;
  i9 = i1 << i7;
  i6 = (i9 + 520192 | 0) >>> 16 & 4;
  i9 = i9 << i6;
  i4 = (i9 + 245760 | 0) >>> 16 & 2;
  i4 = 14 - (i6 | i7 | i4) + (i9 << i4 >>> 15) | 0;
  i4 = i5 >>> (i4 + 7 | 0) & 1 | i4 << 1;
 }
 i1 = 1763120 + (i4 << 2) | 0;
 HEAP32[i8 + 28 >> 2] = i4;
 HEAP32[i8 + 20 >> 2] = 0;
 HEAP32[i8 + 16 >> 2] = 0;
 i2 = HEAP32[440705] | 0;
 i3 = 1 << i4;
 L112 : do if (!(i2 & i3)) {
  HEAP32[440705] = i2 | i3;
  HEAP32[i1 >> 2] = i8;
  HEAP32[i8 + 24 >> 2] = i1;
  HEAP32[i8 + 12 >> 2] = i8;
  HEAP32[i8 + 8 >> 2] = i8;
 } else {
  i1 = HEAP32[i1 >> 2] | 0;
  L115 : do if ((HEAP32[i1 + 4 >> 2] & -8 | 0) != (i5 | 0)) {
   i4 = i5 << ((i4 | 0) == 31 ? 0 : 25 - (i4 >>> 1) | 0);
   while (1) {
    i3 = i1 + 16 + (i4 >>> 31 << 2) | 0;
    i2 = HEAP32[i3 >> 2] | 0;
    if (!i2) break;
    if ((HEAP32[i2 + 4 >> 2] & -8 | 0) == (i5 | 0)) {
     i1 = i2;
     break L115;
    } else {
     i4 = i4 << 1;
     i1 = i2;
    }
   }
   HEAP32[i3 >> 2] = i8;
   HEAP32[i8 + 24 >> 2] = i1;
   HEAP32[i8 + 12 >> 2] = i8;
   HEAP32[i8 + 8 >> 2] = i8;
   break L112;
  } while (0);
  i7 = i1 + 8 | 0;
  i9 = HEAP32[i7 >> 2] | 0;
  HEAP32[i9 + 12 >> 2] = i8;
  HEAP32[i7 >> 2] = i8;
  HEAP32[i8 + 8 >> 2] = i9;
  HEAP32[i8 + 12 >> 2] = i1;
  HEAP32[i8 + 24 >> 2] = 0;
 } while (0);
 i9 = (HEAP32[440712] | 0) + -1 | 0;
 HEAP32[440712] = i9;
 if (i9 | 0) return;
 i1 = 1763272;
 while (1) {
  i1 = HEAP32[i1 >> 2] | 0;
  if (!i1) break; else i1 = i1 + 8 | 0;
 }
 HEAP32[440712] = -1;
 return;
}

function _init(i1, i2, i4, f5, f6, i11) {
 i1 = i1 | 0;
 i2 = i2 | 0;
 i4 = i4 | 0;
 f5 = Math_fround(f5);
 f6 = Math_fround(f6);
 i11 = i11 | 0;
 var d3 = 0.0, i7 = 0, d8 = 0.0, d9 = 0.0, i10 = 0, i12 = 0, d13 = 0.0, d14 = 0.0, d15 = 0.0, d16 = 0.0, d17 = 0.0, i18 = 0, d19 = 0.0;
 if ((i2 + -1 | 0) >>> 0 > 1919 | (i4 + -1 | 0) >>> 0 > 1079) {
  i18 = 0;
  return i18 | 0;
 }
 HEAP32[240672] = i2;
 HEAP32[240673] = i4;
 i18 = f5 > Math_fround(100.0);
 i12 = f5 > Math_fround(1.0);
 f5 = i12 ? f5 : Math_fround(1.0);
 HEAPF32[240678] = i18 ? Math_fround(100.0) : f5;
 i18 = f6 > Math_fround(100.0);
 i12 = f6 > Math_fround(1.0);
 f6 = i12 ? f6 : Math_fround(1.0);
 HEAPF32[240677] = i18 ? Math_fround(100.0) : f6;
 if ((i1 + -8e3 | 0) >>> 0 > 92e3) {
  i18 = 0;
  return i18 | 0;
 }
 d19 = +(i1 | 0);
 i1 = ~~+Math_ceil(+(+Math_log(+(d19 * .33)) / .6931471805599453));
 if ((i1 + -10 | 0) >>> 0 > 10) {
  i18 = 0;
  return i18 | 0;
 }
 i10 = 1 << i1;
 HEAP32[240674] = i10;
 if ((i10 | 0) > 32768) {
  i18 = 0;
  return i18 | 0;
 }
 i7 = 1 << i1 + -2;
 i2 = 34 - i1 | 0;
 i4 = i7 + 65535 | 0;
 i1 = 0;
 do {
  i18 = i1 << 1 & -1431655766 | i1 >>> 1 & 357913941;
  i18 = i18 << 2 & -858993460 | i18 >>> 2 & 590558003;
  i18 = i18 << 4 & -252645136 | i18 >>> 4 & 235867919;
  i18 = i18 << 8 & -16711936 | i18 >>> 8 & 16646399;
  HEAP16[597632 + (i1 << 1) >> 1] = (i18 << 16 | i18 >>> 16) >>> i2 & i4;
  i1 = i1 + 1 | 0;
 } while ((i1 | 0) < (i7 | 0));
 if ((i10 | 0) > 2) {
  i4 = 2;
  do {
   d3 = +(i4 | 0);
   d8 = 6.283185307179586 / d3;
   i7 = i4 >>> 1;
   if (i4 | 0) {
    i1 = 0;
    do {
     i18 = i1 + i4 | 0;
     d17 = d8 * +(i1 | 0);
     f6 = Math_fround(-Math_fround(+Math_sin(+d17)));
     HEAPF32[269952 + (i18 << 3) >> 2] = Math_fround(+Math_cos(+d17));
     HEAPF32[269952 + (i18 << 3) + 4 >> 2] = f6;
     i1 = i1 + 1 | 0;
    } while (i1 >>> 0 < i7 >>> 0);
    d3 = 9.42477796076938 / d3;
    i2 = i7 + i4 | 0;
    i1 = 0;
    do {
     i18 = i2 + i1 | 0;
     d17 = d3 * +(i1 | 0);
     f6 = Math_fround(-Math_fround(+Math_sin(+d17)));
     HEAPF32[269952 + (i18 << 3) >> 2] = Math_fround(+Math_cos(+d17));
     HEAPF32[269952 + (i18 << 3) + 4 >> 2] = f6;
     i1 = i1 + 1 | 0;
    } while (i1 >>> 0 < i7 >>> 0);
   }
   i4 = i4 << 1;
  } while ((i4 | 0) < (i10 | 0));
  d3 = 6.283185307179586 / +(i10 | 0);
  i2 = (i10 | 0) / 4 | 0;
  if ((i10 | 0) > 3) {
   i1 = 0;
   do {
    i18 = i1 + i10 | 0;
    d17 = d3 * +(i1 | 0);
    f6 = Math_fround(-Math_fround(+Math_sin(+d17)));
    HEAPF32[269952 + (i18 << 3) >> 2] = Math_fround(+Math_cos(+d17));
    HEAPF32[269952 + (i18 << 3) + 4 >> 2] = f6;
    i1 = i1 + 1 | 0;
   } while ((i1 | 0) != (i2 | 0));
  }
 }
 d3 = d19 * .033;
 i2 = ~~+Math_ceil(+d3);
 HEAP32[240676] = i2;
 if ((i2 | 0) > 0) {
  i1 = 0;
  do {
   d17 = +(i1 | 0) * 3.141592653589793 / d3;
   HEAPF32[614016 + (i1 << 2) >> 2] = Math_fround(+Math_cos(+(d17 * 3.0)) * .012604 + (+Math_cos(+d17) * .487396 + .355768 + +Math_cos(+(d17 * 2.0)) * .144232));
   i1 = i1 + 1 | 0;
  } while ((i1 | 0) != (i2 | 0));
 }
 i12 = Math_imul(HEAP32[240672] | 0, (i11 | 0) == 0 ? 1 : 2) | 0;
 HEAP32[240675] = i12;
 if ((i12 | 0) <= 0) {
  i18 = HEAP32[240674] | 0;
  return i18 | 0;
 }
 d13 = 1.0 / +(i12 | 0);
 d14 = d19 * .5;
 i1 = HEAP32[240674] | 0;
 d15 = +(i1 | 0);
 d16 = d15 * 8.0;
 d17 = 1.0 / d15;
 i11 = 0;
 i18 = 0;
 while (1) {
  d3 = +Math_exp(+(d13 * ((+(i11 | 0) + .5) * 6.931471805599452) + 2.9964935469158838));
  if (d3 >= d14) {
   i2 = 25;
   break;
  }
  d8 = d3 * .33;
  d8 = d16 / ((126.72 / (d8 / .83 + 2258.8235294117644) + 126.72 / (d8 / .17 + 462.65060240963857)) * d19);
  d9 = d3 * d15 / d19;
  d3 = d8 * .5;
  i2 = ~~+Math_ceil(+(d9 - d3));
  i7 = ~~+Math_floor(+(d9 + d3));
  i10 = i7 - i2 | 0;
  i4 = i10 + 1 | 0;
  if ((i4 + i18 | 0) > 199e3) {
   i1 = 0;
   i2 = 31;
   break;
  }
  HEAP32[962716 + (i18 << 2) >> 2] = i4;
  HEAP32[962716 + (i18 + 1 << 2) >> 2] = i2;
  if ((i7 | 0) >= (i2 | 0)) {
   d3 = 1.0 / d8;
   i4 = i18 + 2 - i2 | 0;
   while (1) {
    d8 = d3 * ((+(i2 | 0) - d9) * 6.283185307179586);
    HEAPF32[962716 + (i4 + i2 << 2) >> 2] = Math_fround(d17 * +((i2 << 1 & 2 ^ 2) + -1 | 0) * (+Math_cos(+(d8 * 3.0)) * .012604 + (+Math_cos(+d8) * .487396 + .355768 + +Math_cos(+(d8 * 2.0)) * .144232)));
    if ((i2 | 0) < (i7 | 0)) i2 = i2 + 1 | 0; else break;
   }
  }
  i11 = i11 + 1 | 0;
  if ((i11 | 0) >= (i12 | 0)) {
   i2 = 31;
   break;
  } else i18 = i18 + 3 + i10 | 0;
 }
 if ((i2 | 0) == 25) {
  HEAP32[962716 + (i18 << 2) >> 2] = 0;
  i18 = i1;
  return i18 | 0;
 } else if ((i2 | 0) == 31) return i1 | 0;
 return 0;
}

function _fft_calc_8(i1) {
 i1 = i1 | 0;
 var i2 = 0, f3 = f0, i4 = 0, f5 = f0, f6 = f0, f7 = f0, i8 = 0, f9 = f0, i10 = 0, f11 = f0, f12 = f0, f13 = f0, i14 = 0, f15 = f0, i16 = 0, i17 = 0, i18 = 0, f19 = f0, f20 = f0, i21 = 0, i22 = 0, f23 = f0, i24 = 0, f25 = f0, i26 = 0, f27 = f0, f28 = f0, f29 = f0, i30 = 0, f31 = f0, i32 = 0, i33 = 0, f34 = f0;
 f28 = Math_fround(HEAPF32[i1 >> 2]);
 i33 = i1 + 4 | 0;
 f29 = Math_fround(HEAPF32[i33 >> 2]);
 i18 = i1 + 8 | 0;
 f9 = Math_fround(HEAPF32[i18 >> 2]);
 i17 = i1 + 12 | 0;
 f11 = Math_fround(HEAPF32[i17 >> 2]);
 f25 = Math_fround(f28 + f9);
 f27 = Math_fround(f29 + f11);
 f9 = Math_fround(f28 - f9);
 f11 = Math_fround(f29 - f11);
 HEAPF32[i18 >> 2] = f9;
 HEAPF32[i17 >> 2] = f11;
 i32 = i1 + 16 | 0;
 f29 = Math_fround(HEAPF32[i32 >> 2]);
 i30 = i1 + 20 | 0;
 f28 = Math_fround(HEAPF32[i30 >> 2]);
 i16 = i1 + 24 | 0;
 f3 = Math_fround(HEAPF32[i16 >> 2]);
 i14 = i1 + 28 | 0;
 f7 = Math_fround(HEAPF32[i14 >> 2]);
 f19 = Math_fround(f29 + f3);
 f23 = Math_fround(f28 + f7);
 f3 = Math_fround(f29 - f3);
 f7 = Math_fround(f28 - f7);
 i26 = i1 + 32 | 0;
 f28 = Math_fround(HEAPF32[i26 >> 2]);
 i24 = i1 + 36 | 0;
 f29 = Math_fround(HEAPF32[i24 >> 2]);
 i10 = i1 + 40 | 0;
 f13 = Math_fround(HEAPF32[i10 >> 2]);
 i8 = i1 + 44 | 0;
 f15 = Math_fround(HEAPF32[i8 >> 2]);
 f34 = Math_fround(f28 + f13);
 f31 = Math_fround(f29 + f15);
 f13 = Math_fround(f28 - f13);
 f15 = Math_fround(f29 - f15);
 i22 = i1 + 48 | 0;
 f29 = Math_fround(HEAPF32[i22 >> 2]);
 i21 = i1 + 52 | 0;
 f28 = Math_fround(HEAPF32[i21 >> 2]);
 i4 = i1 + 56 | 0;
 f20 = Math_fround(HEAPF32[i4 >> 2]);
 i2 = i1 + 60 | 0;
 f5 = Math_fround(HEAPF32[i2 >> 2]);
 f12 = Math_fround(f29 + f20);
 f6 = Math_fround(f28 + f5);
 f20 = Math_fround(f29 - f20);
 f5 = Math_fround(f28 - f5);
 f28 = Math_fround(f25 + f19);
 f29 = Math_fround(f27 + f23);
 f19 = Math_fround(f25 - f19);
 f23 = Math_fround(f27 - f23);
 f27 = Math_fround(f34 + f12);
 f25 = Math_fround(f31 + f6);
 f12 = Math_fround(f34 - f12);
 f6 = Math_fround(f31 - f6);
 f31 = Math_fround(f29 + f25);
 HEAPF32[i1 >> 2] = Math_fround(f28 + f27);
 HEAPF32[i33 >> 2] = f31;
 f31 = Math_fround(f23 - f12);
 HEAPF32[i32 >> 2] = Math_fround(f19 + f6);
 HEAPF32[i30 >> 2] = f31;
 f25 = Math_fround(f29 - f25);
 HEAPF32[i26 >> 2] = Math_fround(f28 - f27);
 HEAPF32[i24 >> 2] = f25;
 f12 = Math_fround(f23 + f12);
 HEAPF32[i22 >> 2] = Math_fround(f19 - f6);
 HEAPF32[i21 >> 2] = f12;
 f12 = Math_fround(HEAPF32[67498]);
 f6 = Math_fround(f12 * f3);
 f19 = Math_fround(HEAPF32[67499]);
 f6 = Math_fround(f6 - Math_fround(f19 * f7));
 f7 = Math_fround(Math_fround(f3 * f19) + Math_fround(f12 * f7));
 f12 = Math_fround(HEAPF32[67506]);
 f19 = Math_fround(f12 * f13);
 f3 = Math_fround(HEAPF32[67507]);
 f19 = Math_fround(f19 - Math_fround(f3 * f15));
 f15 = Math_fround(Math_fround(f13 * f3) + Math_fround(f12 * f15));
 f12 = Math_fround(HEAPF32[67502]);
 f3 = Math_fround(f12 * f20);
 f13 = Math_fround(HEAPF32[67503]);
 f3 = Math_fround(f3 - Math_fround(f13 * f5));
 f5 = Math_fround(Math_fround(f20 * f13) + Math_fround(f12 * f5));
 f12 = Math_fround(f9 + f6);
 f13 = Math_fround(f11 + f7);
 f6 = Math_fround(f9 - f6);
 f7 = Math_fround(f11 - f7);
 f11 = Math_fround(f19 + f3);
 f9 = Math_fround(f15 + f5);
 f3 = Math_fround(f19 - f3);
 f5 = Math_fround(f15 - f5);
 f15 = Math_fround(f13 + f9);
 HEAPF32[i18 >> 2] = Math_fround(f12 + f11);
 HEAPF32[i17 >> 2] = f15;
 f15 = Math_fround(f7 - f3);
 HEAPF32[i16 >> 2] = Math_fround(f6 + f5);
 HEAPF32[i14 >> 2] = f15;
 f9 = Math_fround(f13 - f9);
 HEAPF32[i10 >> 2] = Math_fround(f12 - f11);
 HEAPF32[i8 >> 2] = f9;
 f3 = Math_fround(f7 + f3);
 HEAPF32[i4 >> 2] = Math_fround(f6 - f5);
 HEAPF32[i2 >> 2] = f3;
 return;
}

function _fft_calc_8192(i2) {
 i2 = i2 | 0;
 var i1 = 0, f3 = f0, i4 = 0, f5 = f0, f6 = f0, f7 = f0, i8 = 0, f9 = f0, i10 = 0, f11 = f0, f12 = f0, f13 = f0, i14 = 0, f15 = f0, i16 = 0, i17 = 0, f18 = f0, i19 = 0, i20 = 0, f21 = f0;
 _fft_calc_2048(i2);
 _fft_calc_2048(i2 + 16384 | 0);
 _fft_calc_2048(i2 + 32768 | 0);
 _fft_calc_2048(i2 + 49152 | 0);
 f9 = Math_fround(HEAPF32[i2 >> 2]);
 i17 = i2 + 4 | 0;
 f11 = Math_fround(HEAPF32[i17 >> 2]);
 i16 = i2 + 16384 | 0;
 f6 = Math_fround(HEAPF32[i16 >> 2]);
 i14 = i2 + 16388 | 0;
 f7 = Math_fround(HEAPF32[i14 >> 2]);
 i10 = i2 + 32768 | 0;
 f18 = Math_fround(HEAPF32[i10 >> 2]);
 i8 = i2 + 32772 | 0;
 f15 = Math_fround(HEAPF32[i8 >> 2]);
 i4 = i2 + 49152 | 0;
 f3 = Math_fround(HEAPF32[i4 >> 2]);
 i1 = i2 + 49156 | 0;
 f5 = Math_fround(HEAPF32[i1 >> 2]);
 f12 = Math_fround(f9 + f6);
 f13 = Math_fround(f11 + f7);
 f6 = Math_fround(f9 - f6);
 f7 = Math_fround(f11 - f7);
 f11 = Math_fround(f18 + f3);
 f9 = Math_fround(f15 + f5);
 f3 = Math_fround(f18 - f3);
 f5 = Math_fround(f15 - f5);
 f15 = Math_fround(f13 + f9);
 HEAPF32[i2 >> 2] = Math_fround(f12 + f11);
 HEAPF32[i17 >> 2] = f15;
 f15 = Math_fround(f7 - f3);
 HEAPF32[i16 >> 2] = Math_fround(f6 + f5);
 HEAPF32[i14 >> 2] = f15;
 f9 = Math_fround(f13 - f9);
 HEAPF32[i10 >> 2] = Math_fround(f12 - f11);
 HEAPF32[i8 >> 2] = f9;
 f3 = Math_fround(f7 + f3);
 HEAPF32[i4 >> 2] = Math_fround(f6 - f5);
 HEAPF32[i1 >> 2] = f3;
 i1 = 1;
 do {
  i20 = i2 + (i1 << 3) | 0;
  f11 = Math_fround(HEAPF32[i20 >> 2]);
  i19 = i2 + (i1 << 3) + 4 | 0;
  f9 = Math_fround(HEAPF32[i19 >> 2]);
  f7 = Math_fround(HEAPF32[302720 + (i1 << 3) >> 2]);
  i8 = i1 + 2048 | 0;
  i4 = i2 + (i8 << 3) | 0;
  f3 = Math_fround(HEAPF32[i4 >> 2]);
  f13 = Math_fround(f7 * f3);
  f18 = Math_fround(HEAPF32[302720 + (i1 << 3) + 4 >> 2]);
  i8 = i2 + (i8 << 3) + 4 | 0;
  f12 = Math_fround(HEAPF32[i8 >> 2]);
  f13 = Math_fround(f13 - Math_fround(f18 * f12));
  f12 = Math_fround(Math_fround(f3 * f18) + Math_fround(f7 * f12));
  f7 = Math_fround(HEAPF32[335488 + (i1 << 3) >> 2]);
  i14 = i1 + 4096 | 0;
  i10 = i2 + (i14 << 3) | 0;
  f18 = Math_fround(HEAPF32[i10 >> 2]);
  f3 = Math_fround(f7 * f18);
  f21 = Math_fround(HEAPF32[335488 + (i1 << 3) + 4 >> 2]);
  i14 = i2 + (i14 << 3) + 4 | 0;
  f5 = Math_fround(HEAPF32[i14 >> 2]);
  f3 = Math_fround(f3 - Math_fround(f21 * f5));
  f5 = Math_fround(Math_fround(f18 * f21) + Math_fround(f7 * f5));
  f7 = Math_fround(HEAPF32[319104 + (i1 << 3) >> 2]);
  i17 = i1 + 6144 | 0;
  i16 = i2 + (i17 << 3) | 0;
  f21 = Math_fround(HEAPF32[i16 >> 2]);
  f18 = Math_fround(f7 * f21);
  f6 = Math_fround(HEAPF32[319104 + (i1 << 3) + 4 >> 2]);
  i17 = i2 + (i17 << 3) + 4 | 0;
  f15 = Math_fround(HEAPF32[i17 >> 2]);
  f18 = Math_fround(f18 - Math_fround(f6 * f15));
  f15 = Math_fround(Math_fround(f21 * f6) + Math_fround(f7 * f15));
  f7 = Math_fround(f11 + f13);
  f6 = Math_fround(f9 + f12);
  f13 = Math_fround(f11 - f13);
  f12 = Math_fround(f9 - f12);
  f9 = Math_fround(f3 + f18);
  f11 = Math_fround(f5 + f15);
  f18 = Math_fround(f3 - f18);
  f15 = Math_fround(f5 - f15);
  f5 = Math_fround(f6 + f11);
  HEAPF32[i20 >> 2] = Math_fround(f7 + f9);
  HEAPF32[i19 >> 2] = f5;
  f5 = Math_fround(f12 - f18);
  HEAPF32[i4 >> 2] = Math_fround(f13 + f15);
  HEAPF32[i8 >> 2] = f5;
  f11 = Math_fround(f6 - f11);
  HEAPF32[i10 >> 2] = Math_fround(f7 - f9);
  HEAPF32[i14 >> 2] = f11;
  f18 = Math_fround(f12 + f18);
  HEAPF32[i16 >> 2] = Math_fround(f13 - f15);
  HEAPF32[i17 >> 2] = f18;
  i1 = i1 + 1 | 0;
 } while ((i1 | 0) != 2048);
 return;
}

function _fft_calc_4096(i2) {
 i2 = i2 | 0;
 var i1 = 0, f3 = f0, i4 = 0, f5 = f0, f6 = f0, f7 = f0, i8 = 0, f9 = f0, i10 = 0, f11 = f0, f12 = f0, f13 = f0, i14 = 0, f15 = f0, i16 = 0, i17 = 0, f18 = f0, i19 = 0, i20 = 0, f21 = f0;
 _fft_calc_1024(i2);
 _fft_calc_1024(i2 + 8192 | 0);
 _fft_calc_1024(i2 + 16384 | 0);
 _fft_calc_1024(i2 + 24576 | 0);
 f9 = Math_fround(HEAPF32[i2 >> 2]);
 i17 = i2 + 4 | 0;
 f11 = Math_fround(HEAPF32[i17 >> 2]);
 i16 = i2 + 8192 | 0;
 f6 = Math_fround(HEAPF32[i16 >> 2]);
 i14 = i2 + 8196 | 0;
 f7 = Math_fround(HEAPF32[i14 >> 2]);
 i10 = i2 + 16384 | 0;
 f18 = Math_fround(HEAPF32[i10 >> 2]);
 i8 = i2 + 16388 | 0;
 f15 = Math_fround(HEAPF32[i8 >> 2]);
 i4 = i2 + 24576 | 0;
 f3 = Math_fround(HEAPF32[i4 >> 2]);
 i1 = i2 + 24580 | 0;
 f5 = Math_fround(HEAPF32[i1 >> 2]);
 f12 = Math_fround(f9 + f6);
 f13 = Math_fround(f11 + f7);
 f6 = Math_fround(f9 - f6);
 f7 = Math_fround(f11 - f7);
 f11 = Math_fround(f18 + f3);
 f9 = Math_fround(f15 + f5);
 f3 = Math_fround(f18 - f3);
 f5 = Math_fround(f15 - f5);
 f15 = Math_fround(f13 + f9);
 HEAPF32[i2 >> 2] = Math_fround(f12 + f11);
 HEAPF32[i17 >> 2] = f15;
 f15 = Math_fround(f7 - f3);
 HEAPF32[i16 >> 2] = Math_fround(f6 + f5);
 HEAPF32[i14 >> 2] = f15;
 f9 = Math_fround(f13 - f9);
 HEAPF32[i10 >> 2] = Math_fround(f12 - f11);
 HEAPF32[i8 >> 2] = f9;
 f3 = Math_fround(f7 + f3);
 HEAPF32[i4 >> 2] = Math_fround(f6 - f5);
 HEAPF32[i1 >> 2] = f3;
 i1 = 1;
 do {
  i20 = i2 + (i1 << 3) | 0;
  f11 = Math_fround(HEAPF32[i20 >> 2]);
  i19 = i2 + (i1 << 3) + 4 | 0;
  f9 = Math_fround(HEAPF32[i19 >> 2]);
  f7 = Math_fround(HEAPF32[286336 + (i1 << 3) >> 2]);
  i8 = i1 + 1024 | 0;
  i4 = i2 + (i8 << 3) | 0;
  f3 = Math_fround(HEAPF32[i4 >> 2]);
  f13 = Math_fround(f7 * f3);
  f18 = Math_fround(HEAPF32[286336 + (i1 << 3) + 4 >> 2]);
  i8 = i2 + (i8 << 3) + 4 | 0;
  f12 = Math_fround(HEAPF32[i8 >> 2]);
  f13 = Math_fround(f13 - Math_fround(f18 * f12));
  f12 = Math_fround(Math_fround(f3 * f18) + Math_fround(f7 * f12));
  f7 = Math_fround(HEAPF32[302720 + (i1 << 3) >> 2]);
  i14 = i1 + 2048 | 0;
  i10 = i2 + (i14 << 3) | 0;
  f18 = Math_fround(HEAPF32[i10 >> 2]);
  f3 = Math_fround(f7 * f18);
  f21 = Math_fround(HEAPF32[302720 + (i1 << 3) + 4 >> 2]);
  i14 = i2 + (i14 << 3) + 4 | 0;
  f5 = Math_fround(HEAPF32[i14 >> 2]);
  f3 = Math_fround(f3 - Math_fround(f21 * f5));
  f5 = Math_fround(Math_fround(f18 * f21) + Math_fround(f7 * f5));
  f7 = Math_fround(HEAPF32[294528 + (i1 << 3) >> 2]);
  i17 = i1 + 3072 | 0;
  i16 = i2 + (i17 << 3) | 0;
  f21 = Math_fround(HEAPF32[i16 >> 2]);
  f18 = Math_fround(f7 * f21);
  f6 = Math_fround(HEAPF32[294528 + (i1 << 3) + 4 >> 2]);
  i17 = i2 + (i17 << 3) + 4 | 0;
  f15 = Math_fround(HEAPF32[i17 >> 2]);
  f18 = Math_fround(f18 - Math_fround(f6 * f15));
  f15 = Math_fround(Math_fround(f21 * f6) + Math_fround(f7 * f15));
  f7 = Math_fround(f11 + f13);
  f6 = Math_fround(f9 + f12);
  f13 = Math_fround(f11 - f13);
  f12 = Math_fround(f9 - f12);
  f9 = Math_fround(f3 + f18);
  f11 = Math_fround(f5 + f15);
  f18 = Math_fround(f3 - f18);
  f15 = Math_fround(f5 - f15);
  f5 = Math_fround(f6 + f11);
  HEAPF32[i20 >> 2] = Math_fround(f7 + f9);
  HEAPF32[i19 >> 2] = f5;
  f5 = Math_fround(f12 - f18);
  HEAPF32[i4 >> 2] = Math_fround(f13 + f15);
  HEAPF32[i8 >> 2] = f5;
  f11 = Math_fround(f6 - f11);
  HEAPF32[i10 >> 2] = Math_fround(f7 - f9);
  HEAPF32[i14 >> 2] = f11;
  f18 = Math_fround(f12 + f18);
  HEAPF32[i16 >> 2] = Math_fround(f13 - f15);
  HEAPF32[i17 >> 2] = f18;
  i1 = i1 + 1 | 0;
 } while ((i1 | 0) != 1024);
 return;
}

function _fft_calc_2048(i2) {
 i2 = i2 | 0;
 var i1 = 0, f3 = f0, i4 = 0, f5 = f0, f6 = f0, f7 = f0, i8 = 0, f9 = f0, i10 = 0, f11 = f0, f12 = f0, f13 = f0, i14 = 0, f15 = f0, i16 = 0, i17 = 0, f18 = f0, i19 = 0, i20 = 0, f21 = f0;
 _fft_calc_512(i2);
 _fft_calc_512(i2 + 4096 | 0);
 _fft_calc_512(i2 + 8192 | 0);
 _fft_calc_512(i2 + 12288 | 0);
 f9 = Math_fround(HEAPF32[i2 >> 2]);
 i17 = i2 + 4 | 0;
 f11 = Math_fround(HEAPF32[i17 >> 2]);
 i16 = i2 + 4096 | 0;
 f6 = Math_fround(HEAPF32[i16 >> 2]);
 i14 = i2 + 4100 | 0;
 f7 = Math_fround(HEAPF32[i14 >> 2]);
 i10 = i2 + 8192 | 0;
 f18 = Math_fround(HEAPF32[i10 >> 2]);
 i8 = i2 + 8196 | 0;
 f15 = Math_fround(HEAPF32[i8 >> 2]);
 i4 = i2 + 12288 | 0;
 f3 = Math_fround(HEAPF32[i4 >> 2]);
 i1 = i2 + 12292 | 0;
 f5 = Math_fround(HEAPF32[i1 >> 2]);
 f12 = Math_fround(f9 + f6);
 f13 = Math_fround(f11 + f7);
 f6 = Math_fround(f9 - f6);
 f7 = Math_fround(f11 - f7);
 f11 = Math_fround(f18 + f3);
 f9 = Math_fround(f15 + f5);
 f3 = Math_fround(f18 - f3);
 f5 = Math_fround(f15 - f5);
 f15 = Math_fround(f13 + f9);
 HEAPF32[i2 >> 2] = Math_fround(f12 + f11);
 HEAPF32[i17 >> 2] = f15;
 f15 = Math_fround(f7 - f3);
 HEAPF32[i16 >> 2] = Math_fround(f6 + f5);
 HEAPF32[i14 >> 2] = f15;
 f9 = Math_fround(f13 - f9);
 HEAPF32[i10 >> 2] = Math_fround(f12 - f11);
 HEAPF32[i8 >> 2] = f9;
 f3 = Math_fround(f7 + f3);
 HEAPF32[i4 >> 2] = Math_fround(f6 - f5);
 HEAPF32[i1 >> 2] = f3;
 i1 = 1;
 do {
  i20 = i2 + (i1 << 3) | 0;
  f11 = Math_fround(HEAPF32[i20 >> 2]);
  i19 = i2 + (i1 << 3) + 4 | 0;
  f9 = Math_fround(HEAPF32[i19 >> 2]);
  f7 = Math_fround(HEAPF32[278144 + (i1 << 3) >> 2]);
  i8 = i1 + 512 | 0;
  i4 = i2 + (i8 << 3) | 0;
  f3 = Math_fround(HEAPF32[i4 >> 2]);
  f13 = Math_fround(f7 * f3);
  f18 = Math_fround(HEAPF32[278144 + (i1 << 3) + 4 >> 2]);
  i8 = i2 + (i8 << 3) + 4 | 0;
  f12 = Math_fround(HEAPF32[i8 >> 2]);
  f13 = Math_fround(f13 - Math_fround(f18 * f12));
  f12 = Math_fround(Math_fround(f3 * f18) + Math_fround(f7 * f12));
  f7 = Math_fround(HEAPF32[286336 + (i1 << 3) >> 2]);
  i14 = i1 + 1024 | 0;
  i10 = i2 + (i14 << 3) | 0;
  f18 = Math_fround(HEAPF32[i10 >> 2]);
  f3 = Math_fround(f7 * f18);
  f21 = Math_fround(HEAPF32[286336 + (i1 << 3) + 4 >> 2]);
  i14 = i2 + (i14 << 3) + 4 | 0;
  f5 = Math_fround(HEAPF32[i14 >> 2]);
  f3 = Math_fround(f3 - Math_fround(f21 * f5));
  f5 = Math_fround(Math_fround(f18 * f21) + Math_fround(f7 * f5));
  f7 = Math_fround(HEAPF32[282240 + (i1 << 3) >> 2]);
  i17 = i1 + 1536 | 0;
  i16 = i2 + (i17 << 3) | 0;
  f21 = Math_fround(HEAPF32[i16 >> 2]);
  f18 = Math_fround(f7 * f21);
  f6 = Math_fround(HEAPF32[282240 + (i1 << 3) + 4 >> 2]);
  i17 = i2 + (i17 << 3) + 4 | 0;
  f15 = Math_fround(HEAPF32[i17 >> 2]);
  f18 = Math_fround(f18 - Math_fround(f6 * f15));
  f15 = Math_fround(Math_fround(f21 * f6) + Math_fround(f7 * f15));
  f7 = Math_fround(f11 + f13);
  f6 = Math_fround(f9 + f12);
  f13 = Math_fround(f11 - f13);
  f12 = Math_fround(f9 - f12);
  f9 = Math_fround(f3 + f18);
  f11 = Math_fround(f5 + f15);
  f18 = Math_fround(f3 - f18);
  f15 = Math_fround(f5 - f15);
  f5 = Math_fround(f6 + f11);
  HEAPF32[i20 >> 2] = Math_fround(f7 + f9);
  HEAPF32[i19 >> 2] = f5;
  f5 = Math_fround(f12 - f18);
  HEAPF32[i4 >> 2] = Math_fround(f13 + f15);
  HEAPF32[i8 >> 2] = f5;
  f11 = Math_fround(f6 - f11);
  HEAPF32[i10 >> 2] = Math_fround(f7 - f9);
  HEAPF32[i14 >> 2] = f11;
  f18 = Math_fround(f12 + f18);
  HEAPF32[i16 >> 2] = Math_fround(f13 - f15);
  HEAPF32[i17 >> 2] = f18;
  i1 = i1 + 1 | 0;
 } while ((i1 | 0) != 512);
 return;
}

function _fft_calc_1024(i2) {
 i2 = i2 | 0;
 var i1 = 0, f3 = f0, i4 = 0, f5 = f0, f6 = f0, f7 = f0, i8 = 0, f9 = f0, i10 = 0, f11 = f0, f12 = f0, f13 = f0, i14 = 0, f15 = f0, i16 = 0, i17 = 0, f18 = f0, i19 = 0, i20 = 0, f21 = f0;
 _fft_calc_256(i2);
 _fft_calc_256(i2 + 2048 | 0);
 _fft_calc_256(i2 + 4096 | 0);
 _fft_calc_256(i2 + 6144 | 0);
 f9 = Math_fround(HEAPF32[i2 >> 2]);
 i17 = i2 + 4 | 0;
 f11 = Math_fround(HEAPF32[i17 >> 2]);
 i16 = i2 + 2048 | 0;
 f6 = Math_fround(HEAPF32[i16 >> 2]);
 i14 = i2 + 2052 | 0;
 f7 = Math_fround(HEAPF32[i14 >> 2]);
 i10 = i2 + 4096 | 0;
 f18 = Math_fround(HEAPF32[i10 >> 2]);
 i8 = i2 + 4100 | 0;
 f15 = Math_fround(HEAPF32[i8 >> 2]);
 i4 = i2 + 6144 | 0;
 f3 = Math_fround(HEAPF32[i4 >> 2]);
 i1 = i2 + 6148 | 0;
 f5 = Math_fround(HEAPF32[i1 >> 2]);
 f12 = Math_fround(f9 + f6);
 f13 = Math_fround(f11 + f7);
 f6 = Math_fround(f9 - f6);
 f7 = Math_fround(f11 - f7);
 f11 = Math_fround(f18 + f3);
 f9 = Math_fround(f15 + f5);
 f3 = Math_fround(f18 - f3);
 f5 = Math_fround(f15 - f5);
 f15 = Math_fround(f13 + f9);
 HEAPF32[i2 >> 2] = Math_fround(f12 + f11);
 HEAPF32[i17 >> 2] = f15;
 f15 = Math_fround(f7 - f3);
 HEAPF32[i16 >> 2] = Math_fround(f6 + f5);
 HEAPF32[i14 >> 2] = f15;
 f9 = Math_fround(f13 - f9);
 HEAPF32[i10 >> 2] = Math_fround(f12 - f11);
 HEAPF32[i8 >> 2] = f9;
 f3 = Math_fround(f7 + f3);
 HEAPF32[i4 >> 2] = Math_fround(f6 - f5);
 HEAPF32[i1 >> 2] = f3;
 i1 = 1;
 do {
  i20 = i2 + (i1 << 3) | 0;
  f11 = Math_fround(HEAPF32[i20 >> 2]);
  i19 = i2 + (i1 << 3) + 4 | 0;
  f9 = Math_fround(HEAPF32[i19 >> 2]);
  f7 = Math_fround(HEAPF32[274048 + (i1 << 3) >> 2]);
  i8 = i1 + 256 | 0;
  i4 = i2 + (i8 << 3) | 0;
  f3 = Math_fround(HEAPF32[i4 >> 2]);
  f13 = Math_fround(f7 * f3);
  f18 = Math_fround(HEAPF32[274048 + (i1 << 3) + 4 >> 2]);
  i8 = i2 + (i8 << 3) + 4 | 0;
  f12 = Math_fround(HEAPF32[i8 >> 2]);
  f13 = Math_fround(f13 - Math_fround(f18 * f12));
  f12 = Math_fround(Math_fround(f3 * f18) + Math_fround(f7 * f12));
  f7 = Math_fround(HEAPF32[278144 + (i1 << 3) >> 2]);
  i14 = i1 + 512 | 0;
  i10 = i2 + (i14 << 3) | 0;
  f18 = Math_fround(HEAPF32[i10 >> 2]);
  f3 = Math_fround(f7 * f18);
  f21 = Math_fround(HEAPF32[278144 + (i1 << 3) + 4 >> 2]);
  i14 = i2 + (i14 << 3) + 4 | 0;
  f5 = Math_fround(HEAPF32[i14 >> 2]);
  f3 = Math_fround(f3 - Math_fround(f21 * f5));
  f5 = Math_fround(Math_fround(f18 * f21) + Math_fround(f7 * f5));
  f7 = Math_fround(HEAPF32[276096 + (i1 << 3) >> 2]);
  i17 = i1 + 768 | 0;
  i16 = i2 + (i17 << 3) | 0;
  f21 = Math_fround(HEAPF32[i16 >> 2]);
  f18 = Math_fround(f7 * f21);
  f6 = Math_fround(HEAPF32[276096 + (i1 << 3) + 4 >> 2]);
  i17 = i2 + (i17 << 3) + 4 | 0;
  f15 = Math_fround(HEAPF32[i17 >> 2]);
  f18 = Math_fround(f18 - Math_fround(f6 * f15));
  f15 = Math_fround(Math_fround(f21 * f6) + Math_fround(f7 * f15));
  f7 = Math_fround(f11 + f13);
  f6 = Math_fround(f9 + f12);
  f13 = Math_fround(f11 - f13);
  f12 = Math_fround(f9 - f12);
  f9 = Math_fround(f3 + f18);
  f11 = Math_fround(f5 + f15);
  f18 = Math_fround(f3 - f18);
  f15 = Math_fround(f5 - f15);
  f5 = Math_fround(f6 + f11);
  HEAPF32[i20 >> 2] = Math_fround(f7 + f9);
  HEAPF32[i19 >> 2] = f5;
  f5 = Math_fround(f12 - f18);
  HEAPF32[i4 >> 2] = Math_fround(f13 + f15);
  HEAPF32[i8 >> 2] = f5;
  f11 = Math_fround(f6 - f11);
  HEAPF32[i10 >> 2] = Math_fround(f7 - f9);
  HEAPF32[i14 >> 2] = f11;
  f18 = Math_fround(f12 + f18);
  HEAPF32[i16 >> 2] = Math_fround(f13 - f15);
  HEAPF32[i17 >> 2] = f18;
  i1 = i1 + 1 | 0;
 } while ((i1 | 0) != 256);
 return;
}

function _fft_calc_512(i2) {
 i2 = i2 | 0;
 var i1 = 0, f3 = f0, i4 = 0, f5 = f0, f6 = f0, f7 = f0, i8 = 0, f9 = f0, i10 = 0, f11 = f0, f12 = f0, f13 = f0, i14 = 0, f15 = f0, i16 = 0, i17 = 0, f18 = f0, i19 = 0, i20 = 0, f21 = f0;
 _fft_calc_128(i2);
 _fft_calc_128(i2 + 1024 | 0);
 _fft_calc_128(i2 + 2048 | 0);
 _fft_calc_128(i2 + 3072 | 0);
 f9 = Math_fround(HEAPF32[i2 >> 2]);
 i17 = i2 + 4 | 0;
 f11 = Math_fround(HEAPF32[i17 >> 2]);
 i16 = i2 + 1024 | 0;
 f6 = Math_fround(HEAPF32[i16 >> 2]);
 i14 = i2 + 1028 | 0;
 f7 = Math_fround(HEAPF32[i14 >> 2]);
 i10 = i2 + 2048 | 0;
 f18 = Math_fround(HEAPF32[i10 >> 2]);
 i8 = i2 + 2052 | 0;
 f15 = Math_fround(HEAPF32[i8 >> 2]);
 i4 = i2 + 3072 | 0;
 f3 = Math_fround(HEAPF32[i4 >> 2]);
 i1 = i2 + 3076 | 0;
 f5 = Math_fround(HEAPF32[i1 >> 2]);
 f12 = Math_fround(f9 + f6);
 f13 = Math_fround(f11 + f7);
 f6 = Math_fround(f9 - f6);
 f7 = Math_fround(f11 - f7);
 f11 = Math_fround(f18 + f3);
 f9 = Math_fround(f15 + f5);
 f3 = Math_fround(f18 - f3);
 f5 = Math_fround(f15 - f5);
 f15 = Math_fround(f13 + f9);
 HEAPF32[i2 >> 2] = Math_fround(f12 + f11);
 HEAPF32[i17 >> 2] = f15;
 f15 = Math_fround(f7 - f3);
 HEAPF32[i16 >> 2] = Math_fround(f6 + f5);
 HEAPF32[i14 >> 2] = f15;
 f9 = Math_fround(f13 - f9);
 HEAPF32[i10 >> 2] = Math_fround(f12 - f11);
 HEAPF32[i8 >> 2] = f9;
 f3 = Math_fround(f7 + f3);
 HEAPF32[i4 >> 2] = Math_fround(f6 - f5);
 HEAPF32[i1 >> 2] = f3;
 i1 = 1;
 do {
  i20 = i2 + (i1 << 3) | 0;
  f11 = Math_fround(HEAPF32[i20 >> 2]);
  i19 = i2 + (i1 << 3) + 4 | 0;
  f9 = Math_fround(HEAPF32[i19 >> 2]);
  f7 = Math_fround(HEAPF32[272e3 + (i1 << 3) >> 2]);
  i8 = i1 + 128 | 0;
  i4 = i2 + (i8 << 3) | 0;
  f3 = Math_fround(HEAPF32[i4 >> 2]);
  f13 = Math_fround(f7 * f3);
  f18 = Math_fround(HEAPF32[272e3 + (i1 << 3) + 4 >> 2]);
  i8 = i2 + (i8 << 3) + 4 | 0;
  f12 = Math_fround(HEAPF32[i8 >> 2]);
  f13 = Math_fround(f13 - Math_fround(f18 * f12));
  f12 = Math_fround(Math_fround(f3 * f18) + Math_fround(f7 * f12));
  f7 = Math_fround(HEAPF32[274048 + (i1 << 3) >> 2]);
  i14 = i1 + 256 | 0;
  i10 = i2 + (i14 << 3) | 0;
  f18 = Math_fround(HEAPF32[i10 >> 2]);
  f3 = Math_fround(f7 * f18);
  f21 = Math_fround(HEAPF32[274048 + (i1 << 3) + 4 >> 2]);
  i14 = i2 + (i14 << 3) + 4 | 0;
  f5 = Math_fround(HEAPF32[i14 >> 2]);
  f3 = Math_fround(f3 - Math_fround(f21 * f5));
  f5 = Math_fround(Math_fround(f18 * f21) + Math_fround(f7 * f5));
  f7 = Math_fround(HEAPF32[273024 + (i1 << 3) >> 2]);
  i17 = i1 + 384 | 0;
  i16 = i2 + (i17 << 3) | 0;
  f21 = Math_fround(HEAPF32[i16 >> 2]);
  f18 = Math_fround(f7 * f21);
  f6 = Math_fround(HEAPF32[273024 + (i1 << 3) + 4 >> 2]);
  i17 = i2 + (i17 << 3) + 4 | 0;
  f15 = Math_fround(HEAPF32[i17 >> 2]);
  f18 = Math_fround(f18 - Math_fround(f6 * f15));
  f15 = Math_fround(Math_fround(f21 * f6) + Math_fround(f7 * f15));
  f7 = Math_fround(f11 + f13);
  f6 = Math_fround(f9 + f12);
  f13 = Math_fround(f11 - f13);
  f12 = Math_fround(f9 - f12);
  f9 = Math_fround(f3 + f18);
  f11 = Math_fround(f5 + f15);
  f18 = Math_fround(f3 - f18);
  f15 = Math_fround(f5 - f15);
  f5 = Math_fround(f6 + f11);
  HEAPF32[i20 >> 2] = Math_fround(f7 + f9);
  HEAPF32[i19 >> 2] = f5;
  f5 = Math_fround(f12 - f18);
  HEAPF32[i4 >> 2] = Math_fround(f13 + f15);
  HEAPF32[i8 >> 2] = f5;
  f11 = Math_fround(f6 - f11);
  HEAPF32[i10 >> 2] = Math_fround(f7 - f9);
  HEAPF32[i14 >> 2] = f11;
  f18 = Math_fround(f12 + f18);
  HEAPF32[i16 >> 2] = Math_fround(f13 - f15);
  HEAPF32[i17 >> 2] = f18;
  i1 = i1 + 1 | 0;
 } while ((i1 | 0) != 128);
 return;
}

function _fft_calc_256(i2) {
 i2 = i2 | 0;
 var i1 = 0, f3 = f0, i4 = 0, f5 = f0, f6 = f0, f7 = f0, i8 = 0, f9 = f0, i10 = 0, f11 = f0, f12 = f0, f13 = f0, i14 = 0, f15 = f0, i16 = 0, i17 = 0, f18 = f0, i19 = 0, i20 = 0, f21 = f0;
 _fft_calc_64(i2);
 _fft_calc_64(i2 + 512 | 0);
 _fft_calc_64(i2 + 1024 | 0);
 _fft_calc_64(i2 + 1536 | 0);
 f9 = Math_fround(HEAPF32[i2 >> 2]);
 i17 = i2 + 4 | 0;
 f11 = Math_fround(HEAPF32[i17 >> 2]);
 i16 = i2 + 512 | 0;
 f6 = Math_fround(HEAPF32[i16 >> 2]);
 i14 = i2 + 516 | 0;
 f7 = Math_fround(HEAPF32[i14 >> 2]);
 i10 = i2 + 1024 | 0;
 f18 = Math_fround(HEAPF32[i10 >> 2]);
 i8 = i2 + 1028 | 0;
 f15 = Math_fround(HEAPF32[i8 >> 2]);
 i4 = i2 + 1536 | 0;
 f3 = Math_fround(HEAPF32[i4 >> 2]);
 i1 = i2 + 1540 | 0;
 f5 = Math_fround(HEAPF32[i1 >> 2]);
 f12 = Math_fround(f9 + f6);
 f13 = Math_fround(f11 + f7);
 f6 = Math_fround(f9 - f6);
 f7 = Math_fround(f11 - f7);
 f11 = Math_fround(f18 + f3);
 f9 = Math_fround(f15 + f5);
 f3 = Math_fround(f18 - f3);
 f5 = Math_fround(f15 - f5);
 f15 = Math_fround(f13 + f9);
 HEAPF32[i2 >> 2] = Math_fround(f12 + f11);
 HEAPF32[i17 >> 2] = f15;
 f15 = Math_fround(f7 - f3);
 HEAPF32[i16 >> 2] = Math_fround(f6 + f5);
 HEAPF32[i14 >> 2] = f15;
 f9 = Math_fround(f13 - f9);
 HEAPF32[i10 >> 2] = Math_fround(f12 - f11);
 HEAPF32[i8 >> 2] = f9;
 f3 = Math_fround(f7 + f3);
 HEAPF32[i4 >> 2] = Math_fround(f6 - f5);
 HEAPF32[i1 >> 2] = f3;
 i1 = 1;
 do {
  i20 = i2 + (i1 << 3) | 0;
  f11 = Math_fround(HEAPF32[i20 >> 2]);
  i19 = i2 + (i1 << 3) + 4 | 0;
  f9 = Math_fround(HEAPF32[i19 >> 2]);
  f7 = Math_fround(HEAPF32[270976 + (i1 << 3) >> 2]);
  i8 = i1 + 64 | 0;
  i4 = i2 + (i8 << 3) | 0;
  f3 = Math_fround(HEAPF32[i4 >> 2]);
  f13 = Math_fround(f7 * f3);
  f18 = Math_fround(HEAPF32[270976 + (i1 << 3) + 4 >> 2]);
  i8 = i2 + (i8 << 3) + 4 | 0;
  f12 = Math_fround(HEAPF32[i8 >> 2]);
  f13 = Math_fround(f13 - Math_fround(f18 * f12));
  f12 = Math_fround(Math_fround(f3 * f18) + Math_fround(f7 * f12));
  f7 = Math_fround(HEAPF32[272e3 + (i1 << 3) >> 2]);
  i14 = i1 + 128 | 0;
  i10 = i2 + (i14 << 3) | 0;
  f18 = Math_fround(HEAPF32[i10 >> 2]);
  f3 = Math_fround(f7 * f18);
  f21 = Math_fround(HEAPF32[272e3 + (i1 << 3) + 4 >> 2]);
  i14 = i2 + (i14 << 3) + 4 | 0;
  f5 = Math_fround(HEAPF32[i14 >> 2]);
  f3 = Math_fround(f3 - Math_fround(f21 * f5));
  f5 = Math_fround(Math_fround(f18 * f21) + Math_fround(f7 * f5));
  f7 = Math_fround(HEAPF32[271488 + (i1 << 3) >> 2]);
  i17 = i1 + 192 | 0;
  i16 = i2 + (i17 << 3) | 0;
  f21 = Math_fround(HEAPF32[i16 >> 2]);
  f18 = Math_fround(f7 * f21);
  f6 = Math_fround(HEAPF32[271488 + (i1 << 3) + 4 >> 2]);
  i17 = i2 + (i17 << 3) + 4 | 0;
  f15 = Math_fround(HEAPF32[i17 >> 2]);
  f18 = Math_fround(f18 - Math_fround(f6 * f15));
  f15 = Math_fround(Math_fround(f21 * f6) + Math_fround(f7 * f15));
  f7 = Math_fround(f11 + f13);
  f6 = Math_fround(f9 + f12);
  f13 = Math_fround(f11 - f13);
  f12 = Math_fround(f9 - f12);
  f9 = Math_fround(f3 + f18);
  f11 = Math_fround(f5 + f15);
  f18 = Math_fround(f3 - f18);
  f15 = Math_fround(f5 - f15);
  f5 = Math_fround(f6 + f11);
  HEAPF32[i20 >> 2] = Math_fround(f7 + f9);
  HEAPF32[i19 >> 2] = f5;
  f5 = Math_fround(f12 - f18);
  HEAPF32[i4 >> 2] = Math_fround(f13 + f15);
  HEAPF32[i8 >> 2] = f5;
  f11 = Math_fround(f6 - f11);
  HEAPF32[i10 >> 2] = Math_fround(f7 - f9);
  HEAPF32[i14 >> 2] = f11;
  f18 = Math_fround(f12 + f18);
  HEAPF32[i16 >> 2] = Math_fround(f13 - f15);
  HEAPF32[i17 >> 2] = f18;
  i1 = i1 + 1 | 0;
 } while ((i1 | 0) != 64);
 return;
}

function _fft_calc_128(i2) {
 i2 = i2 | 0;
 var i1 = 0, f3 = f0, i4 = 0, f5 = f0, f6 = f0, f7 = f0, i8 = 0, f9 = f0, i10 = 0, f11 = f0, f12 = f0, f13 = f0, i14 = 0, f15 = f0, i16 = 0, i17 = 0, f18 = f0, i19 = 0, i20 = 0, f21 = f0;
 _fft_calc_32(i2);
 _fft_calc_32(i2 + 256 | 0);
 _fft_calc_32(i2 + 512 | 0);
 _fft_calc_32(i2 + 768 | 0);
 f9 = Math_fround(HEAPF32[i2 >> 2]);
 i17 = i2 + 4 | 0;
 f11 = Math_fround(HEAPF32[i17 >> 2]);
 i16 = i2 + 256 | 0;
 f6 = Math_fround(HEAPF32[i16 >> 2]);
 i14 = i2 + 260 | 0;
 f7 = Math_fround(HEAPF32[i14 >> 2]);
 i10 = i2 + 512 | 0;
 f18 = Math_fround(HEAPF32[i10 >> 2]);
 i8 = i2 + 516 | 0;
 f15 = Math_fround(HEAPF32[i8 >> 2]);
 i4 = i2 + 768 | 0;
 f3 = Math_fround(HEAPF32[i4 >> 2]);
 i1 = i2 + 772 | 0;
 f5 = Math_fround(HEAPF32[i1 >> 2]);
 f12 = Math_fround(f9 + f6);
 f13 = Math_fround(f11 + f7);
 f6 = Math_fround(f9 - f6);
 f7 = Math_fround(f11 - f7);
 f11 = Math_fround(f18 + f3);
 f9 = Math_fround(f15 + f5);
 f3 = Math_fround(f18 - f3);
 f5 = Math_fround(f15 - f5);
 f15 = Math_fround(f13 + f9);
 HEAPF32[i2 >> 2] = Math_fround(f12 + f11);
 HEAPF32[i17 >> 2] = f15;
 f15 = Math_fround(f7 - f3);
 HEAPF32[i16 >> 2] = Math_fround(f6 + f5);
 HEAPF32[i14 >> 2] = f15;
 f9 = Math_fround(f13 - f9);
 HEAPF32[i10 >> 2] = Math_fround(f12 - f11);
 HEAPF32[i8 >> 2] = f9;
 f3 = Math_fround(f7 + f3);
 HEAPF32[i4 >> 2] = Math_fround(f6 - f5);
 HEAPF32[i1 >> 2] = f3;
 i1 = 1;
 do {
  i20 = i2 + (i1 << 3) | 0;
  f11 = Math_fround(HEAPF32[i20 >> 2]);
  i19 = i2 + (i1 << 3) + 4 | 0;
  f9 = Math_fround(HEAPF32[i19 >> 2]);
  f7 = Math_fround(HEAPF32[270464 + (i1 << 3) >> 2]);
  i8 = i1 + 32 | 0;
  i4 = i2 + (i8 << 3) | 0;
  f3 = Math_fround(HEAPF32[i4 >> 2]);
  f13 = Math_fround(f7 * f3);
  f18 = Math_fround(HEAPF32[270464 + (i1 << 3) + 4 >> 2]);
  i8 = i2 + (i8 << 3) + 4 | 0;
  f12 = Math_fround(HEAPF32[i8 >> 2]);
  f13 = Math_fround(f13 - Math_fround(f18 * f12));
  f12 = Math_fround(Math_fround(f3 * f18) + Math_fround(f7 * f12));
  f7 = Math_fround(HEAPF32[270976 + (i1 << 3) >> 2]);
  i14 = i1 + 64 | 0;
  i10 = i2 + (i14 << 3) | 0;
  f18 = Math_fround(HEAPF32[i10 >> 2]);
  f3 = Math_fround(f7 * f18);
  f21 = Math_fround(HEAPF32[270976 + (i1 << 3) + 4 >> 2]);
  i14 = i2 + (i14 << 3) + 4 | 0;
  f5 = Math_fround(HEAPF32[i14 >> 2]);
  f3 = Math_fround(f3 - Math_fround(f21 * f5));
  f5 = Math_fround(Math_fround(f18 * f21) + Math_fround(f7 * f5));
  f7 = Math_fround(HEAPF32[270720 + (i1 << 3) >> 2]);
  i17 = i1 + 96 | 0;
  i16 = i2 + (i17 << 3) | 0;
  f21 = Math_fround(HEAPF32[i16 >> 2]);
  f18 = Math_fround(f7 * f21);
  f6 = Math_fround(HEAPF32[270720 + (i1 << 3) + 4 >> 2]);
  i17 = i2 + (i17 << 3) + 4 | 0;
  f15 = Math_fround(HEAPF32[i17 >> 2]);
  f18 = Math_fround(f18 - Math_fround(f6 * f15));
  f15 = Math_fround(Math_fround(f21 * f6) + Math_fround(f7 * f15));
  f7 = Math_fround(f11 + f13);
  f6 = Math_fround(f9 + f12);
  f13 = Math_fround(f11 - f13);
  f12 = Math_fround(f9 - f12);
  f9 = Math_fround(f3 + f18);
  f11 = Math_fround(f5 + f15);
  f18 = Math_fround(f3 - f18);
  f15 = Math_fround(f5 - f15);
  f5 = Math_fround(f6 + f11);
  HEAPF32[i20 >> 2] = Math_fround(f7 + f9);
  HEAPF32[i19 >> 2] = f5;
  f5 = Math_fround(f12 - f18);
  HEAPF32[i4 >> 2] = Math_fround(f13 + f15);
  HEAPF32[i8 >> 2] = f5;
  f11 = Math_fround(f6 - f11);
  HEAPF32[i10 >> 2] = Math_fround(f7 - f9);
  HEAPF32[i14 >> 2] = f11;
  f18 = Math_fround(f12 + f18);
  HEAPF32[i16 >> 2] = Math_fround(f13 - f15);
  HEAPF32[i17 >> 2] = f18;
  i1 = i1 + 1 | 0;
 } while ((i1 | 0) != 32);
 return;
}

function _fft_calc_64(i2) {
 i2 = i2 | 0;
 var i1 = 0, f3 = f0, i4 = 0, f5 = f0, f6 = f0, f7 = f0, i8 = 0, f9 = f0, i10 = 0, f11 = f0, f12 = f0, f13 = f0, i14 = 0, f15 = f0, i16 = 0, i17 = 0, f18 = f0, i19 = 0, i20 = 0, f21 = f0;
 _fft_calc_16(i2);
 _fft_calc_16(i2 + 128 | 0);
 _fft_calc_16(i2 + 256 | 0);
 _fft_calc_16(i2 + 384 | 0);
 f9 = Math_fround(HEAPF32[i2 >> 2]);
 i17 = i2 + 4 | 0;
 f11 = Math_fround(HEAPF32[i17 >> 2]);
 i16 = i2 + 128 | 0;
 f6 = Math_fround(HEAPF32[i16 >> 2]);
 i14 = i2 + 132 | 0;
 f7 = Math_fround(HEAPF32[i14 >> 2]);
 i10 = i2 + 256 | 0;
 f18 = Math_fround(HEAPF32[i10 >> 2]);
 i8 = i2 + 260 | 0;
 f15 = Math_fround(HEAPF32[i8 >> 2]);
 i4 = i2 + 384 | 0;
 f3 = Math_fround(HEAPF32[i4 >> 2]);
 i1 = i2 + 388 | 0;
 f5 = Math_fround(HEAPF32[i1 >> 2]);
 f12 = Math_fround(f9 + f6);
 f13 = Math_fround(f11 + f7);
 f6 = Math_fround(f9 - f6);
 f7 = Math_fround(f11 - f7);
 f11 = Math_fround(f18 + f3);
 f9 = Math_fround(f15 + f5);
 f3 = Math_fround(f18 - f3);
 f5 = Math_fround(f15 - f5);
 f15 = Math_fround(f13 + f9);
 HEAPF32[i2 >> 2] = Math_fround(f12 + f11);
 HEAPF32[i17 >> 2] = f15;
 f15 = Math_fround(f7 - f3);
 HEAPF32[i16 >> 2] = Math_fround(f6 + f5);
 HEAPF32[i14 >> 2] = f15;
 f9 = Math_fround(f13 - f9);
 HEAPF32[i10 >> 2] = Math_fround(f12 - f11);
 HEAPF32[i8 >> 2] = f9;
 f3 = Math_fround(f7 + f3);
 HEAPF32[i4 >> 2] = Math_fround(f6 - f5);
 HEAPF32[i1 >> 2] = f3;
 i1 = 1;
 do {
  i20 = i2 + (i1 << 3) | 0;
  f11 = Math_fround(HEAPF32[i20 >> 2]);
  i19 = i2 + (i1 << 3) + 4 | 0;
  f9 = Math_fround(HEAPF32[i19 >> 2]);
  f7 = Math_fround(HEAPF32[270208 + (i1 << 3) >> 2]);
  i8 = i1 + 16 | 0;
  i4 = i2 + (i8 << 3) | 0;
  f3 = Math_fround(HEAPF32[i4 >> 2]);
  f13 = Math_fround(f7 * f3);
  f18 = Math_fround(HEAPF32[270208 + (i1 << 3) + 4 >> 2]);
  i8 = i2 + (i8 << 3) + 4 | 0;
  f12 = Math_fround(HEAPF32[i8 >> 2]);
  f13 = Math_fround(f13 - Math_fround(f18 * f12));
  f12 = Math_fround(Math_fround(f3 * f18) + Math_fround(f7 * f12));
  f7 = Math_fround(HEAPF32[270464 + (i1 << 3) >> 2]);
  i14 = i1 + 32 | 0;
  i10 = i2 + (i14 << 3) | 0;
  f18 = Math_fround(HEAPF32[i10 >> 2]);
  f3 = Math_fround(f7 * f18);
  f21 = Math_fround(HEAPF32[270464 + (i1 << 3) + 4 >> 2]);
  i14 = i2 + (i14 << 3) + 4 | 0;
  f5 = Math_fround(HEAPF32[i14 >> 2]);
  f3 = Math_fround(f3 - Math_fround(f21 * f5));
  f5 = Math_fround(Math_fround(f18 * f21) + Math_fround(f7 * f5));
  f7 = Math_fround(HEAPF32[270336 + (i1 << 3) >> 2]);
  i17 = i1 + 48 | 0;
  i16 = i2 + (i17 << 3) | 0;
  f21 = Math_fround(HEAPF32[i16 >> 2]);
  f18 = Math_fround(f7 * f21);
  f6 = Math_fround(HEAPF32[270336 + (i1 << 3) + 4 >> 2]);
  i17 = i2 + (i17 << 3) + 4 | 0;
  f15 = Math_fround(HEAPF32[i17 >> 2]);
  f18 = Math_fround(f18 - Math_fround(f6 * f15));
  f15 = Math_fround(Math_fround(f21 * f6) + Math_fround(f7 * f15));
  f7 = Math_fround(f11 + f13);
  f6 = Math_fround(f9 + f12);
  f13 = Math_fround(f11 - f13);
  f12 = Math_fround(f9 - f12);
  f9 = Math_fround(f3 + f18);
  f11 = Math_fround(f5 + f15);
  f18 = Math_fround(f3 - f18);
  f15 = Math_fround(f5 - f15);
  f5 = Math_fround(f6 + f11);
  HEAPF32[i20 >> 2] = Math_fround(f7 + f9);
  HEAPF32[i19 >> 2] = f5;
  f5 = Math_fround(f12 - f18);
  HEAPF32[i4 >> 2] = Math_fround(f13 + f15);
  HEAPF32[i8 >> 2] = f5;
  f11 = Math_fround(f6 - f11);
  HEAPF32[i10 >> 2] = Math_fround(f7 - f9);
  HEAPF32[i14 >> 2] = f11;
  f18 = Math_fround(f12 + f18);
  HEAPF32[i16 >> 2] = Math_fround(f13 - f15);
  HEAPF32[i17 >> 2] = f18;
  i1 = i1 + 1 | 0;
 } while ((i1 | 0) != 16);
 return;
}

function _fft_calc_32(i2) {
 i2 = i2 | 0;
 var i1 = 0, f3 = f0, i4 = 0, f5 = f0, f6 = f0, f7 = f0, i8 = 0, f9 = f0, i10 = 0, f11 = f0, f12 = f0, f13 = f0, i14 = 0, f15 = f0, i16 = 0, i17 = 0, f18 = f0, i19 = 0, i20 = 0, f21 = f0;
 _fft_calc_8(i2);
 _fft_calc_8(i2 + 64 | 0);
 _fft_calc_8(i2 + 128 | 0);
 _fft_calc_8(i2 + 192 | 0);
 f9 = Math_fround(HEAPF32[i2 >> 2]);
 i17 = i2 + 4 | 0;
 f11 = Math_fround(HEAPF32[i17 >> 2]);
 i16 = i2 + 64 | 0;
 f6 = Math_fround(HEAPF32[i16 >> 2]);
 i14 = i2 + 68 | 0;
 f7 = Math_fround(HEAPF32[i14 >> 2]);
 i10 = i2 + 128 | 0;
 f18 = Math_fround(HEAPF32[i10 >> 2]);
 i8 = i2 + 132 | 0;
 f15 = Math_fround(HEAPF32[i8 >> 2]);
 i4 = i2 + 192 | 0;
 f3 = Math_fround(HEAPF32[i4 >> 2]);
 i1 = i2 + 196 | 0;
 f5 = Math_fround(HEAPF32[i1 >> 2]);
 f12 = Math_fround(f9 + f6);
 f13 = Math_fround(f11 + f7);
 f6 = Math_fround(f9 - f6);
 f7 = Math_fround(f11 - f7);
 f11 = Math_fround(f18 + f3);
 f9 = Math_fround(f15 + f5);
 f3 = Math_fround(f18 - f3);
 f5 = Math_fround(f15 - f5);
 f15 = Math_fround(f13 + f9);
 HEAPF32[i2 >> 2] = Math_fround(f12 + f11);
 HEAPF32[i17 >> 2] = f15;
 f15 = Math_fround(f7 - f3);
 HEAPF32[i16 >> 2] = Math_fround(f6 + f5);
 HEAPF32[i14 >> 2] = f15;
 f9 = Math_fround(f13 - f9);
 HEAPF32[i10 >> 2] = Math_fround(f12 - f11);
 HEAPF32[i8 >> 2] = f9;
 f3 = Math_fround(f7 + f3);
 HEAPF32[i4 >> 2] = Math_fround(f6 - f5);
 HEAPF32[i1 >> 2] = f3;
 i1 = 1;
 do {
  i20 = i2 + (i1 << 3) | 0;
  f11 = Math_fround(HEAPF32[i20 >> 2]);
  i19 = i2 + (i1 << 3) + 4 | 0;
  f9 = Math_fround(HEAPF32[i19 >> 2]);
  f7 = Math_fround(HEAPF32[270080 + (i1 << 3) >> 2]);
  i8 = i1 + 8 | 0;
  i4 = i2 + (i8 << 3) | 0;
  f3 = Math_fround(HEAPF32[i4 >> 2]);
  f13 = Math_fround(f7 * f3);
  f18 = Math_fround(HEAPF32[270080 + (i1 << 3) + 4 >> 2]);
  i8 = i2 + (i8 << 3) + 4 | 0;
  f12 = Math_fround(HEAPF32[i8 >> 2]);
  f13 = Math_fround(f13 - Math_fround(f18 * f12));
  f12 = Math_fround(Math_fround(f3 * f18) + Math_fround(f7 * f12));
  f7 = Math_fround(HEAPF32[270208 + (i1 << 3) >> 2]);
  i14 = i1 + 16 | 0;
  i10 = i2 + (i14 << 3) | 0;
  f18 = Math_fround(HEAPF32[i10 >> 2]);
  f3 = Math_fround(f7 * f18);
  f21 = Math_fround(HEAPF32[270208 + (i1 << 3) + 4 >> 2]);
  i14 = i2 + (i14 << 3) + 4 | 0;
  f5 = Math_fround(HEAPF32[i14 >> 2]);
  f3 = Math_fround(f3 - Math_fround(f21 * f5));
  f5 = Math_fround(Math_fround(f18 * f21) + Math_fround(f7 * f5));
  f7 = Math_fround(HEAPF32[270144 + (i1 << 3) >> 2]);
  i17 = i1 + 24 | 0;
  i16 = i2 + (i17 << 3) | 0;
  f21 = Math_fround(HEAPF32[i16 >> 2]);
  f18 = Math_fround(f7 * f21);
  f6 = Math_fround(HEAPF32[270144 + (i1 << 3) + 4 >> 2]);
  i17 = i2 + (i17 << 3) + 4 | 0;
  f15 = Math_fround(HEAPF32[i17 >> 2]);
  f18 = Math_fround(f18 - Math_fround(f6 * f15));
  f15 = Math_fround(Math_fround(f21 * f6) + Math_fround(f7 * f15));
  f7 = Math_fround(f11 + f13);
  f6 = Math_fround(f9 + f12);
  f13 = Math_fround(f11 - f13);
  f12 = Math_fround(f9 - f12);
  f9 = Math_fround(f3 + f18);
  f11 = Math_fround(f5 + f15);
  f18 = Math_fround(f3 - f18);
  f15 = Math_fround(f5 - f15);
  f5 = Math_fround(f6 + f11);
  HEAPF32[i20 >> 2] = Math_fround(f7 + f9);
  HEAPF32[i19 >> 2] = f5;
  f5 = Math_fround(f12 - f18);
  HEAPF32[i4 >> 2] = Math_fround(f13 + f15);
  HEAPF32[i8 >> 2] = f5;
  f11 = Math_fround(f6 - f11);
  HEAPF32[i10 >> 2] = Math_fround(f7 - f9);
  HEAPF32[i14 >> 2] = f11;
  f18 = Math_fround(f12 + f18);
  HEAPF32[i16 >> 2] = Math_fround(f13 - f15);
  HEAPF32[i17 >> 2] = f18;
  i1 = i1 + 1 | 0;
 } while ((i1 | 0) != 8);
 return;
}

function _memcpy(i3, i6, i1) {
 i3 = i3 | 0;
 i6 = i6 | 0;
 i1 = i1 | 0;
 var i2 = 0, i4 = 0, i5 = 0;
 if ((i1 | 0) >= 8192) {
  _emscripten_memcpy_big(i3 | 0, i6 | 0, i1 | 0) | 0;
  return i3 | 0;
 }
 i5 = i3 | 0;
 i4 = i3 + i1 | 0;
 if ((i3 & 3) == (i6 & 3)) {
  while (i3 & 3) {
   if (!i1) return i5 | 0;
   HEAP8[i3 >> 0] = HEAP8[i6 >> 0] | 0;
   i3 = i3 + 1 | 0;
   i6 = i6 + 1 | 0;
   i1 = i1 - 1 | 0;
  }
  i1 = i4 & -4 | 0;
  i2 = i1 - 64 | 0;
  while ((i3 | 0) <= (i2 | 0)) {
   HEAP32[i3 >> 2] = HEAP32[i6 >> 2];
   HEAP32[i3 + 4 >> 2] = HEAP32[i6 + 4 >> 2];
   HEAP32[i3 + 8 >> 2] = HEAP32[i6 + 8 >> 2];
   HEAP32[i3 + 12 >> 2] = HEAP32[i6 + 12 >> 2];
   HEAP32[i3 + 16 >> 2] = HEAP32[i6 + 16 >> 2];
   HEAP32[i3 + 20 >> 2] = HEAP32[i6 + 20 >> 2];
   HEAP32[i3 + 24 >> 2] = HEAP32[i6 + 24 >> 2];
   HEAP32[i3 + 28 >> 2] = HEAP32[i6 + 28 >> 2];
   HEAP32[i3 + 32 >> 2] = HEAP32[i6 + 32 >> 2];
   HEAP32[i3 + 36 >> 2] = HEAP32[i6 + 36 >> 2];
   HEAP32[i3 + 40 >> 2] = HEAP32[i6 + 40 >> 2];
   HEAP32[i3 + 44 >> 2] = HEAP32[i6 + 44 >> 2];
   HEAP32[i3 + 48 >> 2] = HEAP32[i6 + 48 >> 2];
   HEAP32[i3 + 52 >> 2] = HEAP32[i6 + 52 >> 2];
   HEAP32[i3 + 56 >> 2] = HEAP32[i6 + 56 >> 2];
   HEAP32[i3 + 60 >> 2] = HEAP32[i6 + 60 >> 2];
   i3 = i3 + 64 | 0;
   i6 = i6 + 64 | 0;
  }
  while ((i3 | 0) < (i1 | 0)) {
   HEAP32[i3 >> 2] = HEAP32[i6 >> 2];
   i3 = i3 + 4 | 0;
   i6 = i6 + 4 | 0;
  }
 } else {
  i1 = i4 - 4 | 0;
  while ((i3 | 0) < (i1 | 0)) {
   HEAP8[i3 >> 0] = HEAP8[i6 >> 0] | 0;
   HEAP8[i3 + 1 >> 0] = HEAP8[i6 + 1 >> 0] | 0;
   HEAP8[i3 + 2 >> 0] = HEAP8[i6 + 2 >> 0] | 0;
   HEAP8[i3 + 3 >> 0] = HEAP8[i6 + 3 >> 0] | 0;
   i3 = i3 + 4 | 0;
   i6 = i6 + 4 | 0;
  }
 }
 while ((i3 | 0) < (i4 | 0)) {
  HEAP8[i3 >> 0] = HEAP8[i6 >> 0] | 0;
  i3 = i3 + 1 | 0;
  i6 = i6 + 1 | 0;
 }
 return i5 | 0;
}

function _render_line(i2, i1) {
 i2 = i2 | 0;
 i1 = i1 | 0;
 var f3 = f0, i4 = 0, i5 = 0, f6 = f0, i7 = 0;
 i7 = (i1 | 0) < 255 ? i1 : 255;
 i7 = ((i7 | 0) > 0 ? i7 : 0) & 255;
 if ((i2 | 0) > -1) {
  i1 = HEAP32[240673] | 0;
  if ((i1 | 0) > (i2 | 0)) {
   f6 = Math_fround(Math_fround(i1 - i2 | 0) / Math_fround(i1 | 0));
   if ((HEAP32[240672] | 0) <= 0) return;
   i5 = 0;
   do {
    f3 = Math_fround(HEAPF32[893568 + (i5 << 4) + 12 >> 2]);
    if (!(f3 <= f6)) {
     f3 = Math_fround(f3 - f6);
     f3 = Math_fround(f3 * Math_fround(HEAPF32[955008 + (i5 << 2) >> 2]));
     i4 = ~~Math_fround(Math_fround(f3 * Math_fround(HEAPF32[893568 + (i5 << 4) >> 2])) + Math_fround(.5)) & 255;
     i2 = ~~Math_fround(Math_fround(f3 * Math_fround(HEAPF32[893568 + (i5 << 4) + 4 >> 2])) + Math_fround(.5)) & 255;
     i1 = ~~(+Math_fround(f3 * Math_fround(HEAPF32[893568 + (i5 << 4) + 8 >> 2])) + .5) & 255;
    } else {
     i1 = 0;
     i2 = 0;
     i4 = 0;
    }
    HEAP8[262272 + (i5 << 2) >> 0] = i4;
    HEAP8[262272 + (i5 << 2) + 1 >> 0] = i2;
    HEAP8[262272 + (i5 << 2) + 2 >> 0] = i1;
    HEAP8[262272 + (i5 << 2) + 3 >> 0] = i7;
    i5 = i5 + 1 | 0;
   } while ((i5 | 0) < (HEAP32[240672] | 0));
   return;
  }
 }
 if ((HEAP32[240672] | 0) <= 0) return;
 i1 = 0;
 do {
  i2 = ~~Math_fround(Math_fround(HEAPF32[893568 + (i1 << 4) >> 2]) + Math_fround(.5)) & 255;
  i4 = ~~Math_fround(Math_fround(HEAPF32[893568 + (i1 << 4) + 4 >> 2]) + Math_fround(.5)) & 255;
  i5 = ~~Math_fround(Math_fround(HEAPF32[893568 + (i1 << 4) + 8 >> 2]) + Math_fround(.5)) & 255;
  HEAP8[262272 + (i1 << 2) >> 0] = i2;
  HEAP8[262272 + (i1 << 2) + 1 >> 0] = i4;
  HEAP8[262272 + (i1 << 2) + 2 >> 0] = i5;
  HEAP8[262272 + (i1 << 2) + 3 >> 0] = i7;
  i1 = i1 + 1 | 0;
 } while ((i1 | 0) < (HEAP32[240672] | 0));
 return;
}

function _memset(i5, i6, i4) {
 i5 = i5 | 0;
 i6 = i6 | 0;
 i4 = i4 | 0;
 var i1 = 0, i2 = 0, i3 = 0, i7 = 0;
 i3 = i5 + i4 | 0;
 i6 = i6 & 255;
 if ((i4 | 0) >= 67) {
  while (i5 & 3) {
   HEAP8[i5 >> 0] = i6;
   i5 = i5 + 1 | 0;
  }
  i1 = i3 & -4 | 0;
  i7 = i6 | i6 << 8 | i6 << 16 | i6 << 24;
  i2 = i1 - 64 | 0;
  while ((i5 | 0) <= (i2 | 0)) {
   HEAP32[i5 >> 2] = i7;
   HEAP32[i5 + 4 >> 2] = i7;
   HEAP32[i5 + 8 >> 2] = i7;
   HEAP32[i5 + 12 >> 2] = i7;
   HEAP32[i5 + 16 >> 2] = i7;
   HEAP32[i5 + 20 >> 2] = i7;
   HEAP32[i5 + 24 >> 2] = i7;
   HEAP32[i5 + 28 >> 2] = i7;
   HEAP32[i5 + 32 >> 2] = i7;
   HEAP32[i5 + 36 >> 2] = i7;
   HEAP32[i5 + 40 >> 2] = i7;
   HEAP32[i5 + 44 >> 2] = i7;
   HEAP32[i5 + 48 >> 2] = i7;
   HEAP32[i5 + 52 >> 2] = i7;
   HEAP32[i5 + 56 >> 2] = i7;
   HEAP32[i5 + 60 >> 2] = i7;
   i5 = i5 + 64 | 0;
  }
  while ((i5 | 0) < (i1 | 0)) {
   HEAP32[i5 >> 2] = i7;
   i5 = i5 + 4 | 0;
  }
 }
 while ((i5 | 0) < (i3 | 0)) {
  HEAP8[i5 >> 0] = i6;
  i5 = i5 + 1 | 0;
 }
 return i3 - i4 | 0;
}

function _sbrk(i1) {
 i1 = i1 | 0;
 var i2 = 0, i3 = 0;
 i3 = HEAP32[DYNAMICTOP_PTR >> 2] | 0;
 i2 = i3 + i1 | 0;
 if ((i1 | 0) > 0 & (i2 | 0) < (i3 | 0) | (i2 | 0) < 0) {
  abortOnCannotGrowMemory(i2 | 0) | 0;
  ___setErrNo(12);
  return -1;
 }
 if ((i2 | 0) <= (_emscripten_get_heap_size() | 0)) HEAP32[DYNAMICTOP_PTR >> 2] = i2; else if (!(_emscripten_resize_heap(i2 | 0) | 0)) {
  ___setErrNo(12);
  return -1;
 }
 return i3 | 0;
}

function _set_volume(f1, f2) {
 f1 = Math_fround(f1);
 f2 = Math_fround(f2);
 var i3 = 0, i4 = 0;
 i3 = f1 > Math_fround(100.0);
 i4 = f1 > Math_fround(1.0);
 f1 = i4 ? f1 : Math_fround(1.0);
 HEAPF32[240678] = i3 ? Math_fround(100.0) : f1;
 i3 = f2 > Math_fround(100.0);
 i4 = f2 > Math_fround(1.0);
 f2 = i4 ? f2 : Math_fround(1.0);
 HEAPF32[240677] = i3 ? Math_fround(100.0) : f2;
 return;
}
function stackAlloc(i1) {
 i1 = i1 | 0;
 var i2 = 0;
 i2 = STACKTOP;
 STACKTOP = STACKTOP + i1 | 0;
 STACKTOP = STACKTOP + 15 & -16;
 return i2 | 0;
}

function _set_height(i1) {
 i1 = i1 | 0;
 i1 = (i1 | 0) > 1 ? i1 : 1;
 HEAP32[240673] = (i1 | 0) < 1080 ? i1 : 1080;
 return;
}

function establishStackSpace(i1, i2) {
 i1 = i1 | 0;
 i2 = i2 | 0;
 STACKTOP = i1;
 STACK_MAX = i2;
}

function _get_input_array(i1) {
 i1 = i1 | 0;
 return 128 + (((i1 | 0) != 0 & 1) << 17) | 0;
}

function stackRestore(i1) {
 i1 = i1 | 0;
 STACKTOP = i1;
}

function ___errno_location() {
 return 1763312;
}

function _get_output_array() {
 return 262272;
}

function stackSave() {
 return STACKTOP | 0;
}


// EMSCRIPTEN_END_FUNCS
  return { _render_line: _render_line, _init: _init, _get_input_array: _get_input_array, _calc: _calc, _get_output_array: _get_output_array, _set_height: _set_height, _set_volume: _set_volume };
}
