// https://github.com/mfcc64/html5-showcqtbar
// - simplified SO MUDAH DIMENGERTI -log day1

function start_showcqtbar(width, height, bar_h, stream) {
    var audio_ctx = new(window.AudioContext || window.webkitAudioContext)();
    function resume_audio_ctx() {
        if (audio_ctx.state === "suspended") {
            audio_ctx.resume();
            window.setTimeout(resume_audio_ctx, 100);
        }
    }
    resume_audio_ctx();
    var analyser_l = audio_ctx.createAnalyser();
    var analyser_r = audio_ctx.createAnalyser();
    var splitter = audio_ctx.createChannelSplitter(2);
    var source = audio_ctx.createMediaStreamSource(stream);

    var canvas = document.getElementById("my-canvas").getContext("2d", {alpha:true});
    var bar_knob_value = 19;
    var brightness_knob_value = 25;
    var showcqtbar = new ShowCQTBar(audio_ctx.sampleRate, width, bar_h,
                                    Math.pow(10, bar_knob_value/20),
                                    Math.pow(10, brightness_knob_value/20), 1);

    analyser_l.fftSize = showcqtbar.fft_size;
    analyser_r.fftSize = showcqtbar.fft_size;
    source.connect(splitter);
    splitter.connect(analyser_l, 0);
    splitter.connect(analyser_r, 1);
    if (!stream)
        splitter.connect(audio_ctx.destination);
    var audio_data_l = showcqtbar.get_input_array(0);
    var audio_data_r = showcqtbar.get_input_array(1);
    var line_buffer_tmp = null;
    var line_buffer = showcqtbar.get_output_array();
    var img_buffer = canvas.createImageData(width, height);

    var octaves = 10;
    var twelve = 12;
    var p_len = line_buffer.length / twelve / octaves;
    var threshold = 0.61;
    var pitch = ['e', 'f', 'f#', 'g', 'ab', 'a', 'bb', 'b', 'c', 'c#', 'd', 'eb'];

    var z = 0;
    var stack = [];

    function draw() {
        requestAnimationFrame(draw);
        analyser_l.getFloatTimeDomainData(audio_data_l);
        analyser_r.getFloatTimeDomainData(audio_data_r);
        showcqtbar.calc();

        for (var y = 0; y < height; y++) {
            showcqtbar.render_line(y);
            img_buffer.data.set(line_buffer, 4*width*y);
        }

        var pitchgram = [];
        for (var i = 0; i < line_buffer.length; i+=p_len) {
          var sum = line_buffer.slice(i, i+p_len).reduce(function(a, b){return a+b;});
          var r = sum/1000.0;
          pitchgram.push((r > threshold) ? r : 0);
        }

        //filt/
        for (var i = pitchgram.length - 1; i > 36; i--) {
          pitchgram[i] = 0;
        }

        var pmax = Math.max(...pitchgram);
        var oct = parseInt(pitchgram.indexOf(pmax)/octaves);
        var p = pitchgram.indexOf(pmax) % twelve;
        //console.log(pitch[p] + " " + oct);

        stack.push(pitch[p] + oct);

        if (stack.length == 4) {
          if ((stack[0] == stack[1]) && (stack[1] == stack[2]) && stack[2] == stack[3])
            if (pmax/10 > 0.3) 
              console.log(audio_ctx.currentTime.toFixed(4) + " : " + stack[0] + " : (" + (pmax/10).toFixed(4) + ")"); 
        }

        z++;

        if (stack.length > 4) {
          stack = [];
          z = 0;
        }

        /*
        for (var i = 0; i < img_buffer.data.length / 2; i += 4) {
          img_buffer.data[i + 0] = img_buffer.data[i + 0];
          img_buffer.data[i + 1] = img_buffer.data[i + 1] - 180;
          img_buffer.data[i + 2] = img_buffer.data[i + 2] - 180;
          img_buffer.data[i + 3] = img_buffer.data[i + 3];
        }
        */

        canvas.putImageData(img_buffer, 0, 0);

    }
    requestAnimationFrame(draw);
}

window.addEventListener("load", function(event) {
    if (navigator.mediaDevices) {
        navigator.mediaDevices.getUserMedia({audio: true, video: false})
        .then(function(stream) {
            var bar_h = 1;
            start_showcqtbar(1290, 1080, bar_h, stream);
        })
        .catch(function(err) {
            alert("Error on navigator.mediaDevices.getUserMedia(): " + err.name + ".");
        });
    } else {
        alert("navigator.mediaDevices is not supported on your browser.");
    }
});
