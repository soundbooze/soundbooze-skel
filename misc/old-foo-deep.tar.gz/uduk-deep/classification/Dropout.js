/*

o   o o-o   o   o o  o 
|   | |  \  |   | | /  
|   | |   O |   | OO   
|   | |  /  |   | | \  
 o-o  o-o    o-o  o  o Dropout

*/

'use strict';

function Dropout (numInput, numHidden, numOutput) {
  this.numInput = numInput;
  this.numHidden = numHidden;
  this.numOutput = numOutput;

  this.inputs = new Float32Array(numInput);
  this.ihWeights = this._MakeMatrix(numInput, numHidden);
  this.hBiases = new Float32Array(numHidden);
  this.hOutputs = new Float32Array(numHidden);
  this.hoWeights = this._MakeMatrix(numHidden, numOutput);
  this.oBiases = new Float32Array(numOutput);
  this.outputs = new Float32Array(numOutput);

  this._InitializeWeights();
}

Dropout.prototype._MakeMatrix = function (rows, cols) {
  var result = new Array();
  for (var r = 0; r < rows; ++r) {
    result[r] = new Array();
    for (var j = 0; j < cols; ++j) {
      result[r][j] = Math.random();
    }
  }
  return result;
}

Dropout.prototype._InitializeWeights = function () {
  var numWeights = (this.numInput * this.numHidden) + 
                   (this.numHidden * this.numOutput) + 
                    this.numHidden + this.numOutput;

  var initialWeights = new Float32Array(numWeights);
  var lo = -0.01;
  var hi = 0.01;
  for (var i = 0; i < initialWeights.length; ++i)
    initialWeights[i] = (hi - lo) * Math.random() + lo;

  this._SetWeights(initialWeights);
}

Dropout.prototype._SetWeights = function (weights) {
  var numWeights = (this.numInput * this.numHidden) + 
                   (this.numHidden * this.numOutput) + 
                    this.numHidden + this.numOutput;

  if (weights.length != numWeights)
    console.log("Bad weights array length: ");

  var k = 0;

  for (var i = 0; i < this.numInput; ++i) {
    for (var j = 0; j < this.numHidden; ++j) {
      this.ihWeights[i][j] = weights[k++];
    }
  }

  for (var i = 0; i < this.numHidden; ++i) {
    this.hBiases[i] = weights[k++];
  }

  for (var i = 0; i < this.numHidden; ++i) {
    for (var j = 0; j < this.numOutput; ++j) {
      this.hoWeights[i][j] = weights[k++];
    }
  }

  for (var i = 0; i < this.numOutput; ++i) {
    this.oBiases[i] = weights[k++];
  }
}

Dropout.prototype.GetWeights = function (weights) {
  var numWeights = (this.numInput * this.numHidden) + 
                   (this.numHidden * this.numOutput) + 
                    this.numHidden + this.numOutput;

  var result = new Float32Array(numWeights);

  var k = 0;

  for (var i = 0; i < this.numInput; ++i)
    for (var j = 0; j < this.numHidden; ++j)
      result[k++] = this.ihWeights[i][j];
  for (var i = 0; i < this.numHidden; ++i)
    result[k++] = this.hBiases[i];
  for (var i = 0; i < this.numHidden; ++i)
    for (var j = 0; j < this.numOutput; ++j)
      result[k++] = this.hoWeights[i][j];
  for (var i = 0; i < this.numOutput; ++i)
    result[k++] = this.oBiases[i];

  return result;
}

Dropout.prototype._MakeDropNodes = function () {
  var resultList = [];

  for (var i = 0; i < this.numHidden; ++i) {
    var p = Math.random();
    if (p < 0.50)
      resultList.push(i);
  }

  var rndIndex = Math.floor(Math.random() * (this.numHidden - 0)) + 0;

  if (resultList.length == 0)
    resultList.push(rndIndex);
  else if (resultList.length == this.numHidden)
    resultList.pop(rndIndex);

  return resultList;
}

Dropout.prototype._IsDropNode = function (node, dropNodes) {
  if (dropNodes === null || dropNodes === undefined || dropNodes.length == 0)
    return false;

  if (dropNodes.indexOf(node) >= 0)
    return true;
  else
    return false;
}

Dropout.prototype._ComputeOutputs = function (xValues, dropNodes) {
  if (xValues.length != this.numInput)
    console.log("Bad xValues array length");

  var hSums = new Float32Array(numHidden);
  var oSums = new Float32Array(numOutput);

  for (var i = 0; i < xValues.length; ++i)
    this.inputs[i] = xValues[i];

  for (var j = 0; j < this.numHidden; ++j) {
    if (this._IsDropNode(j, dropNodes) == true) continue;
    for (var i = 0; i < this.numInput; ++i) {
      hSums[j] += this.inputs[i] * this.ihWeights[i][j];
    }
    hSums[j] += this.hBiases[j];
    this.hOutputs[j] = this._HyperTanFunction(hSums[j]);
  }

  for (var k = 0; k < this.numOutput; ++k) {
    for (var j = 0; j < this.numHidden; ++j) {
      if (this._IsDropNode(j, dropNodes) == true) continue; 
      oSums[k] += this.hOutputs[j] * this.hoWeights[j][k];
    }

    oSums[k] += this.oBiases[k];

    var softOut = this._Softmax(oSums);
    this.outputs = softOut.slice(0);
  }

  var retResult = new Float32Array(numOutput);
  retResult = this.outputs.slice(0);
  return retResult;
}

Dropout.prototype._HyperTanFunction = function (x) {
  if (x < -20.0) 
    return -1.0;
  else if (x > 20.0) 
    return 1.0;
  else 
    return Math.tanh(x);
}

Dropout.prototype._Softmax = function (oSums) {
  var max = oSums[0];
  for (var i = 0; i < oSums.length; ++i)
    if (oSums[i] > max) max = oSums[i];

  var scale = 0.0;
  for (var i = 0; i < oSums.length; ++i)
    scale += Math.exp(oSums[i] - max);

  var result = new Float32Array(oSums.length);
  for (var i = 0; i < oSums.length; ++i)
    result[i] = Math.exp(oSums[i] - max) / scale;

  return result; 
}

Dropout.prototype._UpdateWeights = function (tValues, dropNodes, learningRate) {
  if (tValues.length != this.numOutput)
    console.log("target values not same Length as output in UpdateWeights");

  var hGrads = new Float32Array(numHidden);
  var oGrads = new Float32Array(numOutput);

  for (var k = 0; k < this.numOutput; ++k) {
    var derivative = (1 - this.outputs[k]) * this.outputs[k];
    oGrads[k] = derivative * (tValues[k] - this.outputs[k]);
  }

  for (var j = 0; j < this.numHidden; ++j) {
    if (this._IsDropNode(j, dropNodes) == true) continue;
    var derivative = (1 - this.hOutputs[j]) * (1 + this.hOutputs[j]);
    var sum = 0.0;
    for (var k = 0; k < this.numOutput; ++k) {
      var x = oGrads[k] * this.hoWeights[j][k];
      sum += x;
    }
    hGrads[j] = derivative * sum;
  }

  for (var j = 0; j < this.numHidden; ++j) {
    if (this._IsDropNode(j, dropNodes) == true) continue;
    for (var i = 0; i < this.numInput; ++i) {
      var delta = learningRate * hGrads[j] * this.inputs[i];
      this.ihWeights[i][j] += delta;
    }
    var biasDelta = learningRate * hGrads[j] * 1.0;
    this.hBiases[j] += biasDelta;
  }

  for (var k = 0; k < this.numOutput; ++k) {
    for (var j = 0; j < this.numHidden; ++j) {
      if (this._IsDropNode(j, dropNodes) == true) continue;
      var delta = learningRate * oGrads[k] * this.hOutputs[j];
      this.hoWeights[j][k] += delta;
    }
    var biasDelta = learningRate * oGrads[k] * 1.0;
    this.oBiases[k] += biasDelta;
  }
}

Dropout.prototype.Train = function (trainData, maxEpochs, learnRate) {
  var epoch = 0;
  var xValues = new Float32Array(numInput);
  var tValues = new Float32Array(numOutput);

  var sequence = new Float32Array(trainData.length);
  for (var i = 0; i < sequence.length; ++i)
    sequence[i] = i;

  while (epoch < maxEpochs) {

    this._Shuffle(sequence);
    for (var i = 0; i < trainData.length; ++i) {
      var idx = sequence[i];

      for (var z = 0; z < this.numInput; z++) {
        xValues[z] = trainData[idx][z];
      }

      for (var z = 0; z < this.numOutput; z++) {
        tValues[z] = trainData[idx][z+this.numInput];
      }

      var dropNodes = this._MakeDropNodes();
      this._ComputeOutputs(xValues, dropNodes);
      this._UpdateWeights(tValues, dropNodes, learnRate);
    } 
    epoch++;
  }

  for (var j = 0; j < this.numHidden; ++j)
    for (var k = 0; k < this.numOutput; ++k)
      this.hoWeights[j][k] /= 2.0;
}

Dropout.prototype._Shuffle= function (sequence) {
  for (var i = 0; i < sequence.length; ++i) {
    var r = Math.floor(Math.random() * (sequence.length - i)) + i;
    var tmp = sequence[r];
    sequence[r] = sequence[i];
    sequence[i] = tmp;
  }
}

Dropout.prototype._MeanSquaredError = function (trainData) {
  var sumSquaredError = 0.0;
  var xValues = new Float32Array(numInput);
  var tValues = new Float32Array(numOutput);

  for (var i = 0; i < trainData.length; ++i)
  {
    for (var z = 0; z < this.numInput; z++) {
      xValues[z] = trainData[i][z];
    }

    for (var z = 0; z < this.numOutput; z++) {
      tValues[z] = trainData[i][z+this.numInput];
    }

    var yValues = this._ComputeOutputs(xValues, null);
    for (var j = 0; j < this.numOutput; ++j) {
      var err = tValues[j] - yValues[j];
      sumSquaredError += err * err;
    }
  }

  return sumSquaredError / trainData.length;
}

Dropout.prototype.Accuracy = function (testData) {
  var numCorrect = 0;
  var numWrong = 0;
  var xValues = new Float32Array(numInput);
  var tValues = new Float32Array(numOutput);
  var yValues;

  for (var i = 0; i < testData.length; ++i) {
    for (var z = 0; z < this.numInput; z++) {
      xValues[z] = testData[i][z];
    }

    for (var z = 0; z < this.numOutput; z++) {
      tValues[z] = testData[i][z+this.numInput];
    }

    yValues = this._ComputeOutputs(xValues, null);
    var maxIndex = this._MaxIndex(yValues);

    if (tValues[maxIndex] == 1.0)
      ++numCorrect;
    else
      ++numWrong;
  }
  return (numCorrect * 1.0) / (numCorrect + numWrong);
}

Dropout.prototype._MaxIndex = function (vector) {
  var bigIndex = 0;
  var biggestVal = vector[0];
  for (var i = 0; i < vector.length; ++i) {
    if (vector[i] > biggestVal) {
      biggestVal = vector[i]; bigIndex = i;
    }
  }
  return bigIndex;
}

