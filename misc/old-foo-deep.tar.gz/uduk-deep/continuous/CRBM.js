'use strict';

var CRBM = function (settings) {
    RBM.call(this,settings);
};

CRBM.prototype = new RBM({});

CRBM.prototype.propdown = function(h) {
    var self = this;
    var preSigmoidActivation = addMatVec(mulMat(h,transpose(self.W)),self.vbias);
    return preSigmoidActivation;
};

CRBM.prototype.sampleVgivenH = function(h0_sample) {
    var self = this;
    var a_h = self.propdown(h0_sample);
    var a = activateMat(a_h,function(x) { return 1. / (1-Math.exp(-x)) ; });
    var b = activateMat(a_h,function(x){ return 1./x ;});
    var v1_mean = minusMat(a,b);
    var U = randMat(shape(v1_mean)[0],shape(v1_mean)[1],0,1);
    var c = activateMat(a_h,function(x) { return 1 - Math.exp(x);});
    var d = activateMat(mulMatElementWise(U,c),function(x) {return 1-x;});
    var v1_sample = activateTwoMat(activateMat(d,Math.log),a_h,function(x,y) {
        if(y==0) y += 1e-14;
        return x/y;
    })
    return [v1_mean,v1_sample];
};
CRBM.prototype.getReconstructionCrossEntropy = function() {
    var self = this;
    var reconstructedV = self.reconstruct(self.input);
    var a = activateTwoMat(self.input,reconstructedV,function(x,y){
        return x*Math.log(y);
    });

    var b = activateTwoMat(self.input,reconstructedV,function(x,y){
        return (1-x)*Math.log(1-y);
    });

    var crossEntropy = -meanVec(sumMatAxis(addMat(a,b),1));
    return crossEntropy;

};

CRBM.prototype.reconstruct = function(v) {
    var self = this;
    var reconstructedV = self.sampleVgivenH(self.sampleHgivenV(v)[0])[0];
    return reconstructedV;
};
