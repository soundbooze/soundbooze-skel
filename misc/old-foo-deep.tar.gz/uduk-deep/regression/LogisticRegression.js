/*

o   o o-o   o   o o  o 
|   | |  \  |   | | /  
|   | |   O |   | OO   
|   | |  /  |   | | \  
 o-o  o-o    o-o  o  o Logistic Regression

*/

'use strict';

function LogisticRegression (learningRate) {
  this.N = 0;
  this.n_in = 0;
  this.n_out = 0;
  this.W = new Array();
  this.b;
  this.learningRate = learningRate;
}

LogisticRegression.prototype.construct = function (N, n_in, n_out) {
  this.N = N;
  this.n_in = n_in;
  this.n_out = n_out;

  this.b = new Float32Array(n_out);

  for (var i = 0; i < n_out; i++) {
    this.W[i] = new Array();
    for (var j = 0; j < n_in; j++) {
      this.W[i][j] = 0;
    }
    this.b[i] = 0;
  }
}

LogisticRegression.prototype.train = function (x, y) {
  var p_y_given_x = new Float32Array(this.n_out);
  var dy = new Float32Array(this.n_out);

  for (var i = 0; i < this.n_out; i++) {
    p_y_given_x[i] = 0;
    for (var j = 0; j < this.n_in; j++) {
      p_y_given_x[i] += this.W[i][j] * x[j];
    }
    p_y_given_x[i] += this.b[i];
  }

  var pyx = this._softmax(p_y_given_x);

  for (var i = 0; i < this.n_out; i++) {
    dy[i] = y[i] - pyx[i];

    for (var j = 0; j < this.n_in; j++) {
      this.W[i][j] += this.learningRate * dy[i] * x[j] / this.N;
    }

    this.b[i] += this.learningRate * dy[i] / this.N;
  }
}

LogisticRegression.prototype.predict = function (x) {
  var y = new Float32Array(this.n_in);

  for (var i = 0; i < this.n_out; i++) {
    y[i] = 0;
    for (var j = 0; j < this.n_in; j++) {
      y[i] += this.W[i][j] * x[j];
    }
    y[i] += this.b[i];
  }

  return this._softmax(y);
}

LogisticRegression.prototype._softmax = function (x) {
  var max = 0.0;
  var sum = 0.0;
  var result = new Float32Array(this.n_out);

  for (var i = 0; i < this.n_out; i++) {
    if (max < x[i]) {
      max = x[i];
    }
  }

  for (var i = 0; i < this.n_out; i++) {
    x[i] = Math.exp(x[i] - max);
    sum += x[i];
  }

  for (var i = 0; i < this.n_out; i++) {
    result[i] = x[i] / sum;
  }

  return result;
}

LogisticRegression.prototype.getWeight = function () {
  return this.W;
}

LogisticRegression.prototype.getBias = function () {
  return this.b;
}
