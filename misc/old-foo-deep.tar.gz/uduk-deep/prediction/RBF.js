/*

o   o o-o   o   o o  o 
|   | |  \  |   | | /  
|   | |   O |   | OO   
|   | |  /  |   | | \  
 o-o  o-o    o-o  o  o Radial Basis Function

*/

'use strict';

function RBF (numInput, numHidden, numOutput) {
  this.numInput = numInput;
  this.numHidden = numHidden;
  this.numOutput = numOutput;
  this.inputs = new Array(numInput);

  this.centroids = new Array();
  for (var i = 0; i < numHidden; i++) {
    this.centroids[i] = new Array();
    for (var j = 0; j < numInput; j++) {
      this.centroids[i][j] = 0;
    }
  }

  this.stdDevs = new Array(numHidden);

  this.hoWeights = new Array();
  for (var i = 0; i < numHidden; i++) {
    this.hoWeights[i] = new Array();
    for (var j = 0; j < numOutput; j++) {
      this.hoWeights[i][j] = 0;
    }
  }

  this.oBiases = new Array(numOutput);
  this.outputs = new Array(numOutput);
}

RBF.prototype.SetCentroids = function (centroids) {
  if (centroids.length != this.numHidden)
    return;
  if (centroids[0].length != this.numInput)
    return;

  for (var i = 0; i < this.numHidden; ++i)
    for (var j = 0; j < this.numInput; ++j)
      this.centroids[i][j] = centroids[i][j]; 
}

RBF.prototype.SetStdDevs = function (stdDevs) {
  if (stdDevs.length != this.numHidden)
    return;
  this.stdDevs = stdDevs.slice(0, stdDevs.length);
}

RBF.prototype.SetWeights = function (hoWeights) {
  if (hoWeights.length != this.numHidden)
    return;
  if (hoWeights[0].length != this.numOutput)
    return;
  for (var i = 0; i < this.numHidden; ++i)
    for (var j = 0; j < this.numOutput; ++j)
      this.hoWeights[i][j] = hoWeights[i][j]; 
}

RBF.prototype.SetBiases = function (oBiases) {
  if (oBiases.length != this.numOutput)
    return;
  this.oBiases = oBiases.slice(0, oBiases.length);
}

RBF.prototype.ComputeOutputs = function (xValues) {
  this.inputs = xValues.slice(0, xValues.length);

  var hOutputs = new Array(this.numHidden);
  for (var j = 0; j < this.numHidden; ++j) {
    var d = this.Distance(this.inputs, this.centroids[j]);
    var r = -1.0 * (d * d) / (2 * this.stdDevs[j] * this.stdDevs[j]);
    var g = Math.exp(r);
    hOutputs[j] = g;
  }

  for (var k = 0; k < this.numOutput; ++k)
    this.outputs[k] = 0.0;

  for (var k = 0; k < this.numOutput; ++k)
    for (var j = 0; j < this.numHidden; ++j)
      this.outputs[k] += (hOutputs[j] * this.hoWeights[j][k]);

  for (var k = 0; k < this.numOutput; ++k)
    this.outputs[k] += this.oBiases[k];

  var result = new Array(numOutput);
  result = this.outputs.slice(0, this.outputs.length);

  return result;
}

RBF.prototype.Distance = function (x, c) {
  var sum = 0.0;
  for (var i = 0; i < x.length; ++i)
    sum += (x[i] - c[i]) * (x[i] - c[i]);
  return Math.sqrt(sum);
}
