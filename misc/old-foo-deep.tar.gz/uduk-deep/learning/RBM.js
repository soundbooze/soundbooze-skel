/*

o   o o-o   o   o o  o 
|   | |  \  |   | | /  
|   | |   O |   | OO   
|   | |  /  |   | | \  
 o-o  o-o    o-o  o  o Restricted Boltzmann Machine

*/

'use strict';

function RBM (learningRate, k) {
  this.learningRate = learningRate;
  this.k = k;

  this.N = 0;
  this.n_visible = 0;
  this.n_hidden = 0;
  this.W = new Array();
  this.hbias;
  this.vbias;
}

RBM.prototype.construct = function (N, n_visible, n_hidden) {
  var a = 1.0 / n_visible;

  this.N = N;
  this.n_visible = n_visible;
  this.n_hidden = n_hidden;

  for (var i = 0; i < n_hidden; ++i) {
    this.W[i] = new Array();
    for (var j = 0; j < n_visible; ++j) {
      this.W[i][j] = this._uniform(-a, a);
    }
  }

  this.hbias = new Float32Array(n_hidden);
  for (var i = 0; i < n_hidden; ++i) {
    this.hbias[i] = 0;
  }

  this.vbias = new Float32Array(n_visible);
  for (var i = 0; i < n_visible; ++i) {
    this.vbias[i] = 0;
  }
}

RBM.prototype.reconstruct = function (v) {
  var h = new Float32Array(this.n_hidden);
  var reconstructed_v = new Float32Array(this.n_visible);
  var pre_sigmoid_activation;

  for (var i = 0; i < this.n_hidden; i++) {
    h[i] = this._propup(v, this.W[i], this.hbias[i]);
  }

  for (var i = 0; i < this.n_visible; i++) {
    pre_sigmoid_activation = 0.0;
    for (var j = 0; j < this.n_hidden; j++) {
      pre_sigmoid_activation += this.W[j][i] * h[j];
    }
    pre_sigmoid_activation += this.vbias[i];
    reconstructed_v[i] = this._sigmoid(pre_sigmoid_activation);
  }

  return reconstructed_v;
}

RBM.prototype.contrastiveDivergence = function (input) {
  var hv = this.sample_h_given_v(input);
  var ph_means = hv.mean;
  var ph_samples = hv.sample;

  var nv_means;
  var nv_samples;
  var nh_means;
  var nh_samples;

  for (var step = 0; step < this.k; step++) {
    if (step == 0) {
      var vh = this.sample_v_given_h(ph_samples);
      nv_means = vh.mean;
      nv_samples = vh.sample;

      var hv = this.sample_h_given_v(nv_samples);
      nh_means = hv.mean;
      nh_samples = hv.sample;
    }
    else {
      var vh = this.sample_v_given_h(nh_samples);
      nv_means = vh.mean;
      nv_samples = vh.sample;

      var hv = this.sample_h_given_v(nv_samples);
      nh_means = hv.mean;
      nh_samples = hv.sample;

    }
  }

  for (var i = 0; i < this.n_hidden; i++) {
    for (var j = 0; j < this.n_visible; j++) {
      this.W[i][j] += this.learningRate * (ph_means[i] * input[j] - nh_means[i] * nv_samples[j]) / this.N;
    }   
    this.hbias[i] += this.learningRate * (ph_samples[i] - nh_means[i]) / this.N;
  }

  for (var i = 0; i < this.n_visible; i++) {
    this.vbias[i] += this.learningRate * (input[i] - nv_samples[i]) / this.N;
  }

}

RBM.prototype.sample_h_given_v = function (v0_sample) {
  var mean = new Float32Array(this.n_hidden);
  var sample = new Float32Array(this.n_hidden);

  for (var i = 0; i < this.n_hidden; i++) {
    mean[i] = this._propup(v0_sample, this.W[i], this.hbias[i]);
    sample[i] = this._binomial(1, mean[i]);
  }

  var result = {mean: mean, sample: sample};
  return result;
}

RBM.prototype.sample_v_given_h = function (h0_sample) {
  var mean = new Float32Array(this.n_visible);
  var sample = new Float32Array(this.n_visible);

  for (var i = 0; i < this.n_visible; i++) {
    mean[i] = this._propdown(h0_sample, i, this.vbias[i]);
    sample[i] = this._binomial(1, mean[i]);
  }

  var result = {mean: mean, sample: sample};
  return result;
}

RBM.prototype._propup = function (v, w, b) {
  var pre_sigmoid_activation = 0.0;
  for (var j = 0; j < this.n_visible; j++) {
    pre_sigmoid_activation += w[j] * v[j];
  }
  pre_sigmoid_activation += b;
  return this._sigmoid(pre_sigmoid_activation);
}

RBM.prototype._propdown = function (h, i, b) {
  var pre_sigmoid_activation = 0.0;

  for (var j = 0; j < this.n_hidden; j++) {
    pre_sigmoid_activation += this.W[j][i] * h[j];
  }
  pre_sigmoid_activation += b;
  return this._sigmoid(pre_sigmoid_activation);
}

RBM.prototype._uniform = function (min, max) {
  return Math.random() * (max - min) + min;
}

RBM.prototype._binomial = function (n, p) {
  var c = 0, r;

  if (p < 0 || p > 1) {
    return 0;
  }

  for (var i = 0; i < n; ++i) {
    r = Math.random();
    if (r < p) {
      c++;
    }
  }
  return c;
}

RBM.prototype._sigmoid = function (e) {
  return 1.0 / (1.0 + Math.exp(-e));
}

RBM.prototype.getWeight = function () {
  return this.W;
}

RBM.prototype.getBias = function () {
  var bias = {v:this.vbias, h:this.hbias};
  return bias;
}
