/*

o   o o-o   o   o o  o 
|   | |  \  |   | | /  
|   | |   O |   | OO   
|   | |  /  |   | | \  
 o-o  o-o    o-o  o  o Denoising Autoencoder

*/

'use strict';

function DA (learningRate, corruptionLevel) {
  this.learningRate = learningRate;
  this.corruptionLevel = corruptionLevel;
  this.N = 0;
  this.n_visible = 0;
  this.n_hidden = 0;
  this.W = new Array();
  this.hbias;
  this.vbias;
}

DA.prototype.construct = function (N, n_visible, n_hidden) {
  var a = 1.0 / n_visible;

  this.N = N;
  this.n_visible = n_visible;
  this.n_hidden = n_hidden;

  for (var i = 0; i < n_hidden; ++i) {
    this.W[i] = new Array();
    for (var j = 0; j < n_visible; ++j) {
      this.W[i][j] = this._uniform(-a, a);
    }
  }

  this.hbias = new Float32Array(n_hidden);
  for (var i = 0; i < n_hidden; ++i) {
    this.hbias[i] = 0;
  }

  this.vbias = new Float32Array(n_visible);
  for (var i = 0; i < n_visible; ++i) {
    this.vbias[i] = 0;
  }
}

DA.prototype.train = function (x) {
  var L_vbias = new Float32Array(this.n_visible);
  var L_hbias = new Float32Array(this.n_hidden);

  var p = 1 - this.corruptionLevel;

  var tilde_x = this._get_corrupted_input(x, p);
  var y = this._get_hidden_values(tilde_x);
  var z = this._get_reconstructed_input(y);

  for (var i = 0; i < this.n_visible; i++) {
    L_vbias[i] = x[i] - z[i];
    this.vbias[i] += this.learningRate * L_vbias[i] / this.N;
  }

  for (var i = 0; i < this.n_hidden; i++) {
    L_hbias[i] = 0;
    for (var j = 0; j < this.n_visible; j++) {
      L_hbias[i] += this.W[i][j] * L_vbias[j];
    }
    L_hbias[i] *= y[i] * (1 - y[i]);

    this.hbias[i] += this.learningRate * L_hbias[i] / this.N;
  }

  for (var i = 0; i < this.n_hidden; i++) {
    for (var j = 0; j < this.n_visible; j++) {
      this.W[i][j] += this.learningRate * (L_hbias[i] * tilde_x[j] + L_vbias[j] * y[i]) / this.N;
    }
  }
}

DA.prototype.reconstruct = function (x) {
  var y = this._get_hidden_values(x);
  var z = this._get_reconstructed_input(y);
  return z;
}

DA.prototype._get_reconstructed_input = function (y) {
  var z = new Float32Array(this.n_visible);
  for (var i = 0; i < this.n_visible; i++) {
    z[i] = 0;
    for (var j = 0; j < this.n_hidden; j++) {
      z[i] += this.W[j][i] * y[j];
    }
    z[i] += this.vbias[i];
    z[i] = this._sigmoid(z[i]);
  }
  return z;
}

DA.prototype._get_corrupted_input = function (x, p) {
  var tilde_x = new Float32Array(this.n_visible);
  for (var i = 0; i < this.n_visible; i++) {
    if(x[i] == 0) {
      tilde_x[i] = 0;
    } else {
      tilde_x[i] = this._binomial(1, p);
    }
  }
  return tilde_x;
}

DA.prototype._get_hidden_values = function (x) {
  var y = new Float32Array(this.n_hidden);
  for (var i = 0; i < this.n_hidden; i++) {
    y[i] = 0;
    for (var j = 0; j < this.n_visible; j++) {
      y[i] += this.W[i][j] * x[j];
    }
    y[i] += this.hbias[i];
    y[i] = this._sigmoid(y[i]);
  }
  return y;
}

DA.prototype._uniform = function (min, max) {
  return Math.random() * (max - min) + min;
}

DA.prototype._binomial = function (n, p) {
  var c = 0, r;

  if (p < 0 || p > 1) {
    return 0;
  }

  for (var i = 0; i < n; ++i) {
    r = Math.random();
    if (r < p) {
      c++;
    }
  }
  return c;
}

DA.prototype._sigmoid = function (e) {
  return 1.0 / (1.0 + Math.exp(-e));
}

DA.prototype.getWeight = function () {
  return this.W;
}

DA.prototype.getBias = function () {
  var bias = {v:this.vbias, h:this.hbias};
  return bias;
}
