'use strict';

function UdukSIMD () { } 

UdukSIMD.prototype._ArrayToSIMD = function (input) {
  return SIMD.Float32x4.load(input, 0);
}

UdukSIMD.prototype.scalarMultiply = function (input, x) {
  var scalar = SIMD.Float32x4.splat(x);

  var tmp = new Array();
  var index = 0;

  for (var i = 0; i < input.length; i += 4) {
    tmp[index++] = this._ArrayToSIMD(input.slice(i, i + 4));
  }

  for (var i = 0; i < tmp.length; i++) {
    tmp[i] = SIMD.Float32x4.mul(tmp[i], scalar);
  }

  var result = new Array();
  index = 0;
  for (var i = 0; i < tmp.length; i++) {
    for (var j = 0; j < tmp[i].s_.length; j++) {
      result[index++] = tmp[i].s_[j];
    }
  }

  return result;
}

UdukSIMD.prototype.scalarDivision = function (input, x, order) {
  var scalar = SIMD.Float32x4.splat(x);

  var tmp = new Array();
  var index = 0;

  for (var i = 0; i < input.length; i += 4) {
    tmp[index++] = this._ArrayToSIMD(input.slice(i, i + 4));
  }

  if (order) {
    for (var i = 0; i < tmp.length; i++) {
      tmp[i] = SIMD.Float32x4.div(tmp[i], scalar);
    }
  }
  else {
    for (var i = 0; i < tmp.length; i++) {
      tmp[i] = SIMD.Float32x4.div(scalar, tmp[i]);
    }
  }

  var result = new Array();
  index = 0;
  for (var i = 0; i < tmp.length; i++) {
    for (var j = 0; j < tmp[i].s_.length; j++) {
      result[index++] = tmp[i].s_[j];
    }
  }

  return result;
}

UdukSIMD.prototype.sqrt = function (input) {
  var tmp = new Array();
  var index = 0;

  for (var i = 0; i < input.length; i += 4) {
    tmp[index++] = this._ArrayToSIMD(input.slice(i, i + 4));
  }

  for (var i = 0; i < tmp.length; i++) {
    tmp[i] = SIMD.Float32x4.sqrt(tmp[i]);
  }

  var result = new Array();
  index = 0;
  for (var i = 0; i < tmp.length; i++) {
    for (var j = 0; j < tmp[i].s_.length; j++) {
      result[index++] = tmp[i].s_[j];
    }
  }

  return result;
}

UdukSIMD.prototype.abs = function (input) {
  var tmp = new Array();
  var index = 0;

  for (var i = 0; i < input.length; i += 4) {
    tmp[index++] = this._ArrayToSIMD(input.slice(i, i + 4));
  }

  for (var i = 0; i < tmp.length; i++) {
    tmp[i] = SIMD.Float32x4.abs(tmp[i]);
  }

  var result = new Array();
  index = 0;
  for (var i = 0; i < tmp.length; i++) {
    for (var j = 0; j < tmp[i].s_.length; j++) {
      result[index++] = tmp[i].s_[j];
    }
  }

  return result;
}

UdukSIMD.prototype.mul = function (one, two) {
  var s1 = new Array();
  var s2 = new Array();
  var tmp = new Array();
  var index = 0;

  for (var i = 0; i < one.length; i += 4, index++) {
    s1[index] = this._ArrayToSIMD(one.slice(i, i + 4));
    s2[index] = this._ArrayToSIMD(two.slice(i, i + 4));
  }

  for (var i = 0; i < s1.length; i++) {
    tmp[i] = SIMD.Float32x4.mul(s1[i], s2[i]);
  }

  var result = new Array();
  index = 0;
  for (var i = 0; i < tmp.length; i++) {
    for (var j = 0; j < tmp[i].s_.length; j++) {
      result[index++] = tmp[i].s_[j];
    }
  }

  return result;
}

UdukSIMD.prototype.div = function (one, two) {
  var s1 = new Array();
  var s2 = new Array();
  var tmp = new Array();
  var index = 0;

  for (var i = 0; i < one.length; i += 4, index++) {
    s1[index] = this._ArrayToSIMD(one.slice(i, i + 4));
    s2[index] = this._ArrayToSIMD(two.slice(i, i + 4));
  }

  for (var i = 0; i < s1.length; i++) {
    tmp[i] = SIMD.Float32x4.div(s1[i], s2[i]);
  }

  var result = new Array();
  index = 0;
  for (var i = 0; i < tmp.length; i++) {
    for (var j = 0; j < tmp[i].s_.length; j++) {
      result[index++] = tmp[i].s_[j];
    }
  }

  return result;
}

UdukSIMD.prototype.add = function (one, two) {
  var s1 = new Array();
  var s2 = new Array();
  var tmp = new Array();
  var index = 0;

  for (var i = 0; i < one.length; i += 4, index++) {
    s1[index] = this._ArrayToSIMD(one.slice(i, i + 4));
    s2[index] = this._ArrayToSIMD(two.slice(i, i + 4));
  }

  for (var i = 0; i < s1.length; i++) {
    tmp[i] = SIMD.Float32x4.add(s1[i], s2[i]);
  }

  var result = new Array();
  index = 0;
  for (var i = 0; i < tmp.length; i++) {
    for (var j = 0; j < tmp[i].s_.length; j++) {
      result[index++] = tmp[i].s_[j];
    }
  }

  return result;
}

UdukSIMD.prototype.sub = function (one, two) {
  var s1 = new Array();
  var s2 = new Array();
  var tmp = new Array();
  var index = 0;

  for (var i = 0; i < one.length; i += 4, index++) {
    s1[index] = this._ArrayToSIMD(one.slice(i, i + 4));
    s2[index] = this._ArrayToSIMD(two.slice(i, i + 4));
  }

  for (var i = 0; i < s1.length; i++) {
    tmp[i] = SIMD.Float32x4.sub(s1[i], s2[i]);
  }

  var result = new Array();
  index = 0;
  for (var i = 0; i < tmp.length; i++) {
    for (var j = 0; j < tmp[i].s_.length; j++) {
      result[index++] = tmp[i].s_[j];
    }
  }

  return result;
}
