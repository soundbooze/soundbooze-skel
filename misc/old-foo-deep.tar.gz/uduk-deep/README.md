![alt text](https://raw.githubusercontent.com/uduk/uduk-deep/master/logo.jpg "Logo")

Obstrusive Shred EnlightenMent (http://uduk.org/osem)

"The computer can't tell you the emotional story. It can give you the exact mathematical design, but what's missing is the eyebrows." - Frank Zappa
___

Most musicians will be familiar with the word 'Jamming', playing along together in order to produce a good music. When guitarist perform in a real-time jam, he / she does not know the exact musical tempo that is being played. However, there are many features that can be extracted, such as beat dynamic, chord progression and musical themes that enables musician to play by ear. This project aims to mimic the creative process of musicians rather than just generating sequence of melodies from fixed dataset (dictated supervised rule set). Therefore, the question:

"Given an arbitrary backing track (format: wav, mp3) can computer shred in perfect timing and dynamic ?"

## Backtrack Condition

 [1] Backtrack is a monophonic audio format (i.e: guitar strumming) (**) Current focus area<br>
 [2] Backtrack is a completed master track (i.e: free guitar competition backing track)

 (**[1] would fit for direct TO-DO-NG mic sensing, perfect condition for Live environment)

## UDUK™ Deep Shred

UDUK™ Deep Shred is a formless and shapeless real-time deep learning algorithm. As soon as the sequence has been dispatched, the task is to learn harmonic and timing dynamically, in order to produce a high-quality of shred sequences in real-time.

#### Zhred sequence generator

- Uniform N-gram
- Scattered N-gram
- Randomista-Z

#### Inference Engine

- Logistic Inference
- UDUK Deep Underground K

## Themes 
#### Music Inspired Algorithm

Machine creativity inference, emotional coefficient, stimulant feed and audio signal processing - aiming for clarity and realistic reproducible research.

## Audio Features

Mainly focus on beat dynamic and pitch chromagram.

| Time domain  | Frequency Domain | Effectiveness  |
| ------------ |:----------------:| --------------:|
| rms          | mfcc             |                |
| energy       | spectral slope   |                |
| zcr          | chromagram       |                |
| loudness     |                  |                |
| ...          | ...              |                |

## Constraint

The algorithm must perform well under limited resource, such as browser environment. Therefore, (ES6 - Destructuring and Deprogramming) Javascript will be used as the main scripting language - with SIMD. Multiple degree-of-freedom analogy; The algorithm must not mimic famous guitar players, exploratory and originality are the main focus for UDUK OSEM™.  Must be able to operate under both synthesizer types: hardware and software.

## References (original codes)

- (https://github.com/tc39/ecmascript_simd)
- (https://github.com/yusugomori/DeepLearning)
- (https://github.com/junku901/dnn)
- (https://sites.google.com/site/fesangharyweb/downloads)
- (http://mnemstudio.org/path-finding-q-learning-tutorial.htm)
- (https://github.com/hughrawlinson/meyda)
- (https://visualstudiomagazine.com/Articles/List/Neural-Network-Lab.aspx)
- (https://arxiv.org/pdf/1601.03642v1.pdf)
- (http://quod.lib.umich.edu/s/spobooks/bbv9810.0001.001/1:5/--algorithmic-composition-a-gentle-introduction-to-music?rgn=div1;view=fulltext)

## Status

Under continual development.

## License

UDUK™ Free as an AIR License

Free as an AIR License is a free of charge - unconditional grant; for any person to deal with the material without any restriction and/or limitation.

'Without music, life would be a mistake.'

<pre>
o   o o-o   o   o o  o 
|   | |  \  |   | | /  
|   | |   O |   | OO   
|   | |  /  |   | | \     uduk
 o-o  o-o    o-o  o  o     @uduk.org
</pre>
