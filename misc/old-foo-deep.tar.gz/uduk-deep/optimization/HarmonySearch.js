/*

o   o o-o   o   o o  o 
|   | |  \  |   | | /  
|   | |   O |   | OO   
|   | |  /  |   | | \  
 o-o  o-o    o-o  o  o Harmony Search

*/

'use strict';

function HarmonySearch (bw, nvar, hmcr, hms, par, epoch) {
  this.bw = bw;
  this.nvar = nvar;
  this.hmcr = hmcr;
  this.hms = hms;
  this.par = par;
  this.epoch = epoch;

  this.generation = 0;

  this.low = new Float32Array(nvar);
  this.high = new Float32Array(nvar);
  this.NCHV = new Float32Array(nvar);
  this.bestHarmony = new Float32Array(nvar + 1);
  this.bestFitHistory = new Float32Array(epoch + 1);
  this.worstFitHistory = new Float32Array(epoch + 1);

  this.HM = new Array();
  for (var i = 0; i < hms; i++) {
    this.HM[i] = new Array();
  }

  this.terminationCriteria = true;
}

HarmonySearch.prototype.setBounds = function (low, high) {
  for (var i = 0; i < low.length; i++) {
    this.low[i] = low[i];
  }

  for (var i = 0; i < high.length; i++) {
    this.high[i] = high[i];
  }
}

HarmonySearch.prototype.solve = function (func) {
  this._initiator(func);

  while (this._stopCondition()) {
    for (var i = 0; i < this.nvar; i++) {
      if (Math.random() < this.hmcr) {
        this._memoryConsideration(i);
        if (Math.random() < this.par)
          this._pitchAdjustment(i);
      }

      else {
        this._randomSelection(i);
      }
    }

    var currentFit;
    currentFit = func(this.NCHV);
    this._updateHarmonyMemory(currentFit);
    this.generation++;
  }
}

HarmonySearch.prototype._initiator = function (func) {
  var curFit;

  for (var i = 0; i < this.hms; i++) {
    for (var j = 0; j < this.nvar; j++) {
      this.HM[i][j] = this._random(this.low[j], this.high[j]);
      this.NCHV[j] = this.HM[i][j];
    }
    curFit = func(this.NCHV);
    this.HM[i][this.nvar] = curFit;
  }
}

HarmonySearch.prototype._memoryConsideration = function (index) {
  var r = Math.floor(Math.random() * ((this.hms - 1) - 0)) + 0;
  this.NCHV[index] = this.HM[r][index]; 
}

HarmonySearch.prototype._randomSelection = function (index) {
  this.NCHV[index] = this._random(this.low[index], this.high[index]);
}

HarmonySearch.prototype._stopCondition = function () {
  if (this.generation > epoch)
    this.terminationCriteria = false;

    return this.terminationCriteria;
}

HarmonySearch.prototype._pitchAdjustment = function (index) {
  var rand = Math.random();
  var temp = this.NCHV[index];

  if (rand < 0.5) {
    temp += rand * this.bw;
    if (temp < this.high[index])
      this.NCHV[index] = temp;
  }
  else {
    temp -= rand * this.bw;
    if (temp > this.low[index])
      this.NCHV[index] = temp;
  }
}

HarmonySearch.prototype._random = function (min, max) {
  return Math.random() * (max - min) + min;
}

HarmonySearch.prototype._updateHarmonyMemory = function (newFitness) {
  var worst = this.HM[0][this.nvar];
  var worstIndex = 0;

  for (var i = 0; i < this.hms; i++) {
    if (this.HM[i][this.nvar] > worst) {
      worst = this.HM[i][this.nvar];
      worstIndex = i;
    }
  }

  this.worstFitHistory[this.generation] = worst;

  if (newFitness < worst) {
    for (var k = 0; k < this.nvar; k++) {
      this.HM[worstIndex][k] = this.NCHV[k];
    }
    this.HM[worstIndex][this.nvar] = newFitness;
  }

  var best = this.HM[0][this.nvar];
  var bestIndex = 0;
  for (var i = 0; i < this.hms; i++) {
    if (this.HM[i, this.nvar] < best) {
      best = this.HM[i][this.nvar];
      bestIndex = i;
    }
  }

  this.bestFitHistory[this.generation] = best;

  if (this.generation > 0 && best != this.bestFitHistory[this.generation - 1]) {
    for (var k = 0; k < this.nvar; k++) {
      this.bestHarmony[k] = this.HM[bestIndex][k];
    }

    this.bestHarmony[this.nvar] = best;
  }
}
