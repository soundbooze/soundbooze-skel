/*

o   o o-o   o   o o  o 
|   | |  \  |   | | /  
|   | |   O |   | OO   
|   | |  /  |   | | \  
 o-o  o-o    o-o  o  o Particle Swarm

*/

'use strict';

function ParticleSwarm () {
  this.w = 0.729;
  this.c1 = 1.49445;
  this.c2 = 1.49445;
  this.r1
  this.r2;
  this.probDeath = 0.01;
  this.epoch = 0;
}

ParticleSwarm.prototype.solve = function (dim, numParticles, minX, maxX, maxEpochs, exitError) {
  var swarm = new Array();
  var bestGlobalPosition = new Float32Array(dim);
  var bestGlobalError = Number.MAX_VALUE;

  for (var i = 0; i < numParticles; i++) {

    var randomPosition = new Float32Array(dim);
    for (var j = 0; j < randomPosition.length; ++j)
      randomPosition[j] = (maxX - minX) * Math.random() + minX;

    var error = this._error(randomPosition);
    var randomVelocity = new Float32Array(dim);

    for (var j = 0; j < randomVelocity.length; ++j) {
      var lo = minX * 0.1; 
      var hi = maxX * 0.1;
      randomVelocity[j] = (hi - lo) * Math.random() + lo;
    }

    swarm[i] = new Particle(randomPosition, error, randomVelocity, randomPosition, error);

    if (swarm[i].error < bestGlobalError) {
      bestGlobalError = swarm[i].error;
      bestGlobalPosition = swarm[i].position.slice(0);
    }

  }

  var newVelocity = new Float32Array(dim);
  var newPosition = new Float32Array(dim);
  var newError;

  while (this.epoch < maxEpochs) {
    for (var i = 0; i < swarm.length; ++i) {
      var currP = swarm[i];

      for (var j = 0; j < currP.velocity.length; ++j) {
        this.r1 = Math.random();
        this.r2 = Math.random();

        newVelocity[j] = (this.w * currP.velocity[j]) +
          (this.c1 * this.r1 * (currP.bestPosition[j] - currP.position[j])) +
          (this.c2 * this.r2 * (bestGlobalPosition[j] - currP.position[j]));
      }

      currP.velocity = newVelocity.slice(0);

      for (var j = 0; j < currP.position.length; ++j) {
        newPosition[j] = currP.position[j] + newVelocity[j];
        if (newPosition[j] < minX)
          newPosition[j] = minX;
        else if (newPosition[j] > maxX)
          newPosition[j] = maxX;
      }

      currP.position = newPosition.slice(0);

      newError = this._error(newPosition);
      currP.error = newError;

      if (newError < currP.bestError) {
        currP.bestPosition = newPosition.slice(0);
        currP.bestError = newError;
      }

      if (newError < bestGlobalError) {
        bestGlobalPosition = newPosition.slice(0);
        bestGlobalError = newError;
      }

      var die = Math.random();
      if (die < this.probDeath) {
        for (var j = 0; j < currP.position.length; ++j)
          currP.position[j] = (maxX - minX) * Math.random() + minX;

        currP.error = this._error(currP.position);
        currP.bestPosition = currP.position.slice(0);
        currP.bestError = currP.error;

        if (currP.error < bestGlobalError) {
          bestGlobalError = currP.error;
          bestGlobalPosition = currP.position.slice(0);
        }
      }

    }

    this.epoch++;
  }

  var result = new Float32Array(dim);
  result = bestGlobalPosition.slice(0);
  return result;
}

ParticleSwarm.prototype._error = function (x) {
  var trueMin = -0.42888194; 
  var z = x[0] * Math.exp(-((x[0]*x[0]) + (x[1]*x[1])));
  return (z - trueMin) * (z - trueMin);
}

function Particle (pos, err, vel, bestPos, bestErr) {
  this.position = pos.slice(0);
  this.error = err;
  this.velocity = vel.slice(0);
  this.bestPosition = bestPos.slice(0);
  this.bestError = bestErr;
}
